import React, { useState, useEffect } from 'react';
import { Member, AttendanceRecord, SupportTicket, ServiceSession, Language, SupportStatus, AdminUser } from './types';
import {
  INITIAL_MEMBERS,
  INITIAL_ATTENDANCE,
  INITIAL_SUPPORT_TICKETS,
  INITIAL_SESSIONS,
  INITIAL_ADMINS,
  FITHAPOL_LOGO,
} from './data/initialData';
import { t } from './utils/translations';
import { MemberList } from './components/MemberList';
import { AttendanceScanner } from './components/AttendanceScanner';
import { SupportDesk } from './components/SupportDesk';
import { AnalyticsView } from './components/AnalyticsView';
import { TelegramSimulator } from './components/TelegramSimulator';
import { IdCardStudio } from './components/IdCardStudio';
import { ScheduleView } from './components/ScheduleView';
import { AdminManagement } from './components/AdminManagement';
import { ZipDownloadModal } from './components/ZipDownloadModal';
import {
  Calendar,
  Users,
  QrCode,
  HeartHandshake,
  BarChart3,
  Smartphone,
  Globe,
  Printer,
  ChevronRight,
  ShieldCheck,
  FolderArchive,
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('am');
  const [activeTab, setActiveTab] = useState<'schedule' | 'members' | 'attendance' | 'support' | 'admins' | 'analytics' | 'telegram'>('schedule');
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // DEMO ONLY: this frontend uses browser localStorage, not the SQLite backend.
  // Do not use this view for production student records.
  // Persistent state in LocalStorage
  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem('fithapol_members');
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('fithapol_attendance');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('fithapol_tickets');
    return saved ? JSON.parse(saved) : INITIAL_SUPPORT_TICKETS;
  });

  const [sessions] = useState<ServiceSession[]>(INITIAL_SESSIONS);
  const [activeSession, setActiveSession] = useState<ServiceSession>(INITIAL_SESSIONS[0]);

  // Role-Based Access Control: 1 Super Admin and Multiple Admins
  const [admins] = useState<AdminUser[]>(INITIAL_ADMINS);
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser>(INITIAL_ADMINS[0]);

  // Card Studio state
  const [isCardStudioOpen, setIsCardStudioOpen] = useState(false);
  const [studioTargetMember, setStudioTargetMember] = useState<Member | null>(null);

  // Sync with LocalStorage
  useEffect(() => {
    localStorage.setItem('fithapol_members', JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem('fithapol_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('fithapol_tickets', JSON.stringify(tickets));
  }, [tickets]);

  const dict = t[lang];

  // Actions
  const handleAddMember = (newMember: Member) => {
    setMembers((prev) => [newMember, ...prev]);
  };

  const handleApproveMember = (memberId: string, manualStudentId: string) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? {
              ...m,
              status: 'active',
              code: manualStudentId,
              approvedBy: currentAdmin.nameAm,
              approvedAt: new Date().toISOString(),
            }
          : m
      )
    );
  };

  const handleRejectMember = (memberId: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== memberId));
  };

  const handleCheckIn = (record: AttendanceRecord) => {
    setAttendance((prev) => [record, ...prev]);
  };

  const handleAddTicket = (ticket: SupportTicket) => {
    setTickets((prev) => [ticket, ...prev]);
  };

  const handleUpdateTicketStatus = (ticketId: string, status: SupportStatus) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, status, updatedAt: new Date().toISOString() } : t))
    );
  };

  const handleAddNote = (ticketId: string, author: string, text: string) => {
    setTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          return {
            ...t,
            notes: [
              ...t.notes,
              {
                id: `n-${Date.now()}`,
                author,
                text,
                date: new Date().toISOString().replace('T', ' ').slice(0, 16),
              },
            ],
          };
        }
        return t;
      })
    );
  };

  const handleOpenCardStudio = (member?: Member) => {
    setStudioTargetMember(member || members[0]);
    setIsCardStudioOpen(true);
  };

  const handleSelectSessionFromSchedule = (sessionName: string, grade: string) => {
    const matching = sessions.find((s) => s.gradeAm === grade || s.nameAm.includes(grade));
    if (matching) {
      setActiveSession(matching);
    }
    setActiveTab('attendance');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Bar Contract: Zone 1 (Wordmark) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Primary Action) */}
      <header className="no-print border-b border-slate-800/80 bg-slate-900/70 backdrop-blur-md sticky top-0 z-40 px-6 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <img
            src={FITHAPOL_LOGO}
            alt="Wold Wahid Logo"
            className="w-8 h-8 rounded-full border border-amber-400/50 object-cover shadow-sm"
            referrerPolicy="no-referrer"
          />
          <a href="#" className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            <span>የወልድ ዋሕድ</span>
            <span className="text-amber-400 ml-1.5 font-medium font-sans">ሰ/ት/ቤት</span>
          </a>
        </div>

        {/* Zone 2: 4-5 Concise Single-Line Nav Links */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-medium text-slate-300">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'schedule' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.schedule}
          </button>

          <button
            onClick={() => setActiveTab('members')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'members' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.members}
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'attendance' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.attendance}
          </button>

          <button
            onClick={() => setActiveTab('support')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'support' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.support}
          </button>

          <button
            onClick={() => setActiveTab('admins')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'admins' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.admins}
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'analytics' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.analytics}
          </button>

          <button
            onClick={() => setActiveTab('telegram')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'telegram' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.telegram}
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action (Admin Role Switcher, Language Switcher & ZIP Download) */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Admin Role Profile Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-800/90 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs">
            <span className="text-sm">
              {currentAdmin.role === 'super_admin' ? '👑' : '🛡️'}
            </span>
            <select
              value={currentAdmin.id}
              onChange={(e) => {
                const found = admins.find((a) => a.id === e.target.value);
                if (found) setCurrentAdmin(found);
              }}
              className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
              title="የአስተዳዳሪ ፕሮፋይል ይቀይሩ / Switch Admin Role"
            >
              {admins.map((admin) => (
                <option key={admin.id} value={admin.id} className="bg-slate-900 text-white">
                  {admin.nameAm} ({admin.role === 'super_admin' ? 'ዋና አስተዳዳሪ' : 'አስተዳዳሪ'})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20 transition-all whitespace-nowrap shrink-0 font-bold cursor-pointer"
            title="ሙሉውን የፕሮጀክት ኮድ በዚፕ ያውርዱ ወይም ፋይሎችን ይመልከቱ / Download Full Project ZIP"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>{lang === 'am' ? 'ሙሉ ኮድ (.ZIP)' : 'Download (.ZIP)'}</span>
          </button>

          <button
            onClick={() => setLang(lang === 'am' ? 'en' : 'am')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors whitespace-nowrap shrink-0"
            title="ቋንቋ ይቀይሩ / Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'am' ? 'English' : 'አማርኛ'}</span>
          </button>
        </div>
      </header>

      {/* Mobile Nav Bar for smaller viewports */}
      <div className="no-print lg:hidden border-b border-slate-800 bg-slate-900/50 px-4 py-2 flex items-center justify-between gap-1 overflow-x-auto">
        {[
          { id: 'schedule', label: lang === 'am' ? 'መርሐ ግብር' : 'Schedule', icon: Calendar },
          { id: 'members', label: lang === 'am' ? 'አባላት' : 'Members', icon: Users },
          { id: 'attendance', label: lang === 'am' ? 'QR ክትትል' : 'Attendance', icon: QrCode },
          { id: 'support', label: lang === 'am' ? 'ድጋፍ' : 'Support', icon: HeartHandshake },
          { id: 'admins', label: lang === 'am' ? 'አድሚኖች' : 'Admins', icon: ShieldCheck },
          { id: 'analytics', label: lang === 'am' ? 'ሪፖርት' : 'Analytics', icon: BarChart3 },
          { id: 'telegram', label: 'Telegram', icon: Smartphone },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'schedule' && (
          <ScheduleView
            onSelectSessionForAttendance={handleSelectSessionFromSchedule}
            lang={lang}
          />
        )}

        {activeTab === 'members' && (
          <MemberList
            members={members}
            onAddMember={handleAddMember}
            onApproveMember={handleApproveMember}
            onRejectMember={handleRejectMember}
            onOpenCardStudio={handleOpenCardStudio}
            currentAdminRole={currentAdmin.role}
            lang={lang}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceScanner
            members={members}
            attendance={attendance}
            sessions={sessions}
            activeSession={activeSession}
            onSelectSession={setActiveSession}
            onCheckIn={handleCheckIn}
            lang={lang}
          />
        )}

        {activeTab === 'support' && (
          <SupportDesk
            tickets={tickets}
            members={members}
            onAddTicket={handleAddTicket}
            onUpdateTicketStatus={handleUpdateTicketStatus}
            onAddNote={handleAddNote}
            lang={lang}
          />
        )}

        {activeTab === 'admins' && (
          <AdminManagement
            currentAdmin={currentAdmin}
            lang={lang}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            members={members}
            attendance={attendance}
            tickets={tickets}
            lang={lang}
          />
        )}

        {activeTab === 'telegram' && (
          <TelegramSimulator
            members={members}
            attendance={attendance}
            lang={lang}
          />
        )}
      </main>

      {/* Printable ID Card Studio Modal */}
      {isCardStudioOpen && (
        <IdCardStudio
          members={members}
          selectedMember={studioTargetMember}
          onClose={() => setIsCardStudioOpen(false)}
          lang={lang}
        />
      )}

      {/* Zip and Project Downloader Modal */}
      <ZipDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Quiet Footer */}
      <footer className="no-print border-t border-slate-900 py-6 px-6 text-center text-xs text-slate-500">
        <p>
          ፍትሐፖል ማህበር (FithaPol) · {new Date().getFullYear()} · የአባላት አስተዳደር፣ ክትትልና የአገልግሎት ሥርዓት
        </p>
      </footer>
    </div>
  );
}
