# የስርዓት ማስታወሻ

- እውነተኛ የTelegram Bot እና Flask Dashboard መረጃ በ SQLite ይቀመጣል።
- React (port 3000) የተለየ localStorage የሙከራ UI ነው፤ ከSQLite ጋር አልተገናኘም። እውነተኛ ተማሪ መረጃ በዚያ አታስተዳድር።
- Flask Dashboard: http://127.0.0.1:5001/ ፤ የSupport ጥያቄ ዝርዝር፣ 30 ሰከንድ ማደሻ፣ የAttendance ፍለጋ፣ PDF/Excel ሪፖርት አለው።
- Support status በDashboard መቀየር በራሱ ለተማሪው የTelegram ማሳወቂያ አይልክም።
- ከማስኬድ በፊት .env አዘጋጅ፤ የDatabase ቅጂ አስቀምጥ፤ በlocalhost ፈትን።
- እዚህ ያለው የSQLite ፋይል ከተላከው ZIP ነው። እውነተኛ መረጃ ካለ ለሌሎች አታጋራ።
