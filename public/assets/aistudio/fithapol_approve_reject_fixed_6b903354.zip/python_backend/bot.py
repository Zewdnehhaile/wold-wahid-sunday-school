"""
Wold Wahid Sunday School Telegram Bot (የወልድ ዋሕድ ሰንበት ት/ቤት ቦት)
Configured with User Settings:
- BOT_TOKEN: configured privately in python_backend/.env
- SUPER_ADMIN_ID: configured privately in .env
- BOT_USERNAME: attendanceforchurchbot
- ATTENDANCE_DAY: Sunday (08:00 - 12:00)
- ADMIN_DASHBOARD_URL: http://127.0.0.1:5001/
- GEOLOCATION VERIFICATION: 300m radius around school
- LEAVE OF ABSENCE REQUESTS (የተማሪ ፈቃድ መጠየቂያ): In Support Center
"""
import os
import re
import io
import math
import datetime
import qrcode
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler,
    MessageHandler,
    filters,
)
from config import (
    BOT_TOKEN,
    ORGANIZATION_NAME_AM,
    SCHOOL_NAME,
    ADMIN_IDS,
    SUPER_ADMIN_ID,
    ATTENDANCE_DAY,
    ATTENDANCE_OPEN_TIME,
    ATTENDANCE_CLOSE_TIME,
    ADMIN_DASHBOARD_URL,
    CHURCH_LATITUDE,
    CHURCH_LONGITUDE,
    MAX_ATTENDANCE_DISTANCE_METERS,
    DAILY_ATTENDANCE_PIN,
    TIMEZONE,
    validate_runtime_config,
)
from database import get_connection, init_db
from zoneinfo import ZoneInfo


def local_now():
    """Return the current datetime in the configured school timezone."""
    try:
        return datetime.datetime.now(ZoneInfo(TIMEZONE))
    except Exception:
        return datetime.datetime.now()


def attendance_window_error():
    """Return a user-facing explanation if attendance is outside configured day/time."""
    now = local_now()
    if now.strftime("%A").lower() != ATTENDANCE_DAY.lower():
        return f"የተገኝነት ምዝገባ የሚፈቀደው {ATTENDANCE_DAY} ብቻ ነው።"
    try:
        opens = datetime.datetime.strptime(ATTENDANCE_OPEN_TIME, "%H:%M").time()
        closes = datetime.datetime.strptime(ATTENDANCE_CLOSE_TIME, "%H:%M").time()
    except ValueError:
        return "የAttendance ሰዓት ቅንብር ትክክል አይደለም። አስተዳዳሪውን ያነጋግሩ።"
    if not (opens <= now.time().replace(tzinfo=None) <= closes):
        return f"የተገኝነት ምዝገባ የሚፈቀደው {ATTENDANCE_OPEN_TIME}–{ATTENDANCE_CLOSE_TIME} ብቻ ነው።"
    return None

# Grade Level Schedules
SCHEDULE_BY_GRADE = {
    "pre_kg": (
        "🧸 **የቅድመ አንደኛ መርሐ ግብር፦**\n\n"
        "📅 **እሁድ:**\n"
        "• ጸሎት መክፈቻ (3:30–3:40) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (3:40–4:00) | ኃላፊ: ትምህርት ክፍል\n"
        "• መዝሙር (4:00–4:15) | ኃላፊ: መዝሙር ክፍል\n"
        "• አብነት (4:15–4:30) | ኃላፊ: አብነት ክፍል\n"
        "• ኪነ ጥበብ (4:25–4:50) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "• ማስታወቂያ (4:55–5:00) | ኃላፊ: ስነ ስርዓት ክፍል\n"
    ),
    "grade_1_2": (
        "🎒 **የ 1ኛ እና 2ኛ ክፍል መርሐ ግብር፦**\n\n"
        "📅 **እሁድ:**\n"
        "• ጸሎት መክፈቻ (3:30–3:35) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (3:35–4:05) | ኃላፊ: ትምህርት ክፍል\n"
        "• ኪነ ጥበብ (4:05–4:25) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "• አብነት (4:25–4:50) | ኃላፊ: አብነት ክፍል\n"
        "• መዝሙር (4:50–5:20) | ኃላፊ: መዝሙር ክፍል\n"
        "• ማስታወቂያ (5:20–5:30) | ኃላፊ: ስነ ስርዓት ክፍል\n"
    ),
    "grade_3_5": (
        "📚 **የ 3ኛ–5ኛ ክፍል መርሐ ግብር፦**\n\n"
        "📅 **ቅዳሜ:**\n"
        "• መክፈቻ ጸሎት (8:00–8:05) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (8:05–9:00) | ኃላፊ: ትምህርት ክፍል\n"
        "• ኪነ ጥበብ (9:00–9:45) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "• ማስታወቂያ (9:50–10:00) | ኃላፊ: ስነ ስርዓት ክፍል\n\n"
        "📅 **እሁድ:**\n"
        "• መክፈቻ ጸሎት (5:00–5:20) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (5:20–6:10) | ኃላፊ: ትምህርት ክፍል\n"
        "• መዝሙር (6:10–7:00) | ኃላፊ: መዝሙር ክፍል\n"
        "• አብነት (7:00–7:20) | ኃላፊ: አብነት ክፍል\n"
        "• መዝጊያ ጸሎት (7:20–7:30) | ኃላፊ: ስነ ስርዓት ክፍል\n"
    ),
    "grade_6_9": (
        "🎓 **የ 6ኛ–9ኛ ክፍል መርሐ ግብር፦**\n\n"
        "📅 **አርብ:**\n"
        "• ጸሎት (11:30–11:50) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "• ኪነ ጥበብ (11:50–12:30) | ኃላፊ: ኪነ ጥበብ ክፍል\n\n"
        "📅 **ቅዳሜ:**\n"
        "• መክፈቻ ጸሎት (9:00–9:05) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (9:05–10:05) | ኃላፊ: ትምህርት ክፍል\n"
        "• አብነት (10:05–10:35) | ኃላፊ: አብነት ክፍል\n"
        "• መዝሙር እና ወረብ (10:35–11:50) | ኃላፊ: መዝሙር ክፍል\n"
        "• መዝጊያ ጸሎት (11:50–11:55) | ኃላፊ: ስነ ስርዓት ክፍል\n\n"
        "📅 **እሁድ:**\n"
        "• መክፈቻ ጸሎት (8:00–8:20) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "• ትምህርት (8:20–9:20) | ኃላፊ: ትምህርት ክፍል\n"
        "• አብነት (9:20–9:50) | ኃላፊ: አብነት ክፍል\n"
        "• መዝሙር እና ወረብ (9:50–10:55) | ኃላፊ: መዝሙር ክፍል\n"
        "• መዝጊያ ጸሎት (10:55–11:00) | ኃላፊ: ስነ ስርዓት ክፍል\n"
    ),
}

SCHEDULE_BY_DAY = {
    "friday": (
        "📅 **የአርብ መርሐ ግብር፦**\n\n"
        "• **6ኛ–9ኛ ክፍል:**\n"
        "  - ጸሎት (11:30–11:50) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "  - ኪነ ጥበብ (11:50–12:30) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
    ),
    "saturday": (
        "📅 **የቅዳሜ መርሐ ግብር፦**\n\n"
        "• **3ኛ–5ኛ ክፍል:**\n"
        "  - መክፈቻ ጸሎት (8:00–8:05) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "  - ትምህርት (8:05–9:00) | ኃላፊ: ትምህርት ክፍል\n"
        "  - ኪነ ጥበብ (9:00–9:45) | ኃላፊ: ኪነ ጥበብ ክፍል\n"
        "  - ማስታወቂያ (9:50–10:00) | ኃላፊ: ስነ ስርዓት ክፍል\n\n"
        "• **6ኛ–9ኛ ክፍል:**\n"
        "  - መክፈቻ ጸሎት (9:00–9:05) | ኃላፊ: ስነ ስርዓት ክፍል\n"
        "  - ትምህርት (9:05–10:05) | ኃላፊ: ትምህርት ክፍል\n"
        "  - አብነት (10:05–10:35) | ኃላፊ: አብነት ክፍል\n"
        "  - መዝሙር እና ወረብ (10:35–11:50) | ኃላፊ: መዝሙር ክፍል\n"
        "  - መዝጊያ ጸሎት (11:50–11:55) | ኃላፊ: ስነ ስርዓት ክፍል\n"
    ),
    "sunday": (
        "📅 **የእሁድ መርሐ ግብር፦**\n\n"
        "• **ቅድመ አንደኛ:** 3:30–5:00 (ትምህርት፣ መዝሙር፣ አብነት፣ ኪነ ጥበብ)\n"
        "• **1ኛ እና 2ኛ ክፍል:** 3:30–5:30 (ትምህርት፣ ኪነ ጥበብ፣ አብነት፣ መዝሙር)\n"
        "• **3ኛ–5ኛ ክፍል:** 5:00–7:30 (ትምህርት፣ መዝሙር፣ አብነት)\n"
        "• **6ኛ–9ኛ ክፍል:** 8:00–11:00 (ትምህርት፣ አብነት፣ መዝሙር እና ወረብ)\n"
    ),
}

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculates great-circle distance between two GPS coordinates in meters."""
    R = 6371000.0  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2) + math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2)
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R * c

def generate_qr_image(text: str) -> io.BytesIO:
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=2,
    )
    qr.add_data(text)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0F172A", back_color="#FFFFFF")
    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    return bio

def check_is_admin(user_id: int):
    """Return (is_admin, role), keeping Super Admin distinct from sub-admins."""
    if user_id == SUPER_ADMIN_ID and SUPER_ADMIN_ID > 0:
        return True, "super_admin"
    if user_id in ADMIN_IDS:
        return True, "sub_admin"
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT role FROM bot_admins WHERE telegram_id = ?", (user_id,))
        row = cursor.fetchone()
        if row:
            role = row["role"]
            if role == "super_admin" and user_id != SUPER_ADMIN_ID:
                return True, "sub_admin"
            return True, role
        return False, None
    finally:
        conn.close()

def get_member_by_telegram_id(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM members WHERE telegram_id = ? LIMIT 1", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row

def get_main_menu_keyboard(user_id: int):
    """
    Main menu:
    📝 የተማሪ ምዝገባ (Register Profile)
    📋 መገኘት መመዝገቢያ (Mark Attendance)
    👤 የእኔ መረጃ (My Profile & QR Card)
    📅 የተገኘሁባቸው ቀናት (My Attendance)
    🗓️ የክፍል መርሐ ግብር (Class Schedule)
    🆘 ድጋፍ እና የፈቃድ መጠየቂያ (Support & Leave)
    🔐 የአስተዳዳሪ ሰሌዳ (Admin Dashboard)
    """
    keyboard = [
        [InlineKeyboardButton("📝 የተማሪ ምዝገባ (Register Profile)", callback_data="btn_register")],
        [InlineKeyboardButton("📋 መገኘት መመዝገቢያ (Mark Attendance)", callback_data="btn_attendance")],
        [InlineKeyboardButton("👤 የእኔ መረጃና QR (My Profile)", callback_data="btn_profile")],
        [InlineKeyboardButton("📅 የተገኘሁባቸው ቀናት (My Attendance)", callback_data="btn_my_history")],
        [InlineKeyboardButton("🗓️ የክፍል መርሐ ግብር (Class Schedule)", callback_data="sched_menu")],
        [InlineKeyboardButton("🆘 ድጋፍ እና የፈቃድ መጠየቂያ (Support & Leave)", callback_data="btn_support")],
        [InlineKeyboardButton("🔐 የአስተዳዳሪ ሰሌዳ (Admin Dashboard)", callback_data="btn_admin")],
    ]
    return InlineKeyboardMarkup(keyboard)

# -------------------------------------------------------------
# COMMAND HANDLERS
# -------------------------------------------------------------

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    # Clear conversation states
    context.user_data.clear()

    welcome_text = (
        f"ሰላም {user.first_name}!\n\n"
        f"🙏 እንኳን ወደ **{SCHOOL_NAME}** የቴሌግራም ቦት በደህና መጡ።\n\n"
        "የሚፈልጉትን አገልግሎት ከታች ካሉት አማራጮች ይምረጡ፦"
    )
    reply_markup = get_main_menu_keyboard(user.id)

    if update.callback_query:
        await update.callback_query.edit_message_text(
            welcome_text,
            reply_markup=reply_markup,
            parse_mode="Markdown",
        )
    else:
        await update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup,
            parse_mode="Markdown",
        )

async def myid_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    is_admin, role = check_is_admin(user.id)
    msg = (
        f"👤 **የእርስዎ ቴሌግራም መለያ ቁጥር (Telegram User ID)፦**\n\n"
        f"👉 `{user.id}`\n\n"
        f"{'👑 **ዋና አስተዳዳሪ (Super Admin)** እንደሆኑ ተመዝግበዋል!' if is_admin else 'ይህ የእርስዎ መለያ ቁጥር ነው።'}"
    )
    await update.message.reply_text(msg, parse_mode="Markdown")

async def card_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show or generate QR card for approved student."""
    user = update.effective_user
    member = get_member_by_telegram_id(user.id)

    if not member:
        caption = (
            "⚠️ **እስካሁን አልተመዘገቡም! (Not Registered)**\n\n"
            "እባክዎ መጀመሪያ **📝 Register Profile** የሚለውን ተጭነው ይመዝገቡ።\n"
            "አስተዳዳሪው ሲያጸድቁዎት የዲጂታል QR መታወቂያዎ ወዲያውኑ ይላክልዎታል።"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("📝 Register Profile", callback_data="btn_register")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
        ])
        if update.callback_query:
            await update.callback_query.edit_message_text(caption, parse_mode="Markdown", reply_markup=markup)
        else:
            await update.message.reply_text(caption, parse_mode="Markdown", reply_markup=markup)
        return

    if member["status"] != "approved":
        caption = (
            "⏳ **ምዝገባዎ በአስተዳዳሪው (Super Admin) እየታየ ነው! (Pending Approval)**\n\n"
            f"👤 **ስም:** {member['full_name_am']}\n"
            f"🎒 **ክፍል:** {member['grade_level'] or 'አዲስ'}\n\n"
            "የሰንበት ት/ቤቱ ዋና አስተዳዳሪ **Student ID** ሰጥተው እንዳጸደቁት ዲጂታል የQR መታወቂያዎ ወዲያውኑ ይዘጋጅልዎታል።"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ", callback_data="back_start")]])
        if update.callback_query:
            await update.callback_query.edit_message_text(caption, parse_mode="Markdown", reply_markup=markup)
        else:
            await update.message.reply_text(caption, parse_mode="Markdown", reply_markup=markup)
        return

    member_code = member["code"] or f"WW-{member['id']:03d}"
    member_name = member["full_name_am"]
    dept = member["department"] or "የሰንበት ት/ቤት ተማሪ"
    grade = member["grade_level"] or "አጠቃላይ"

    qr_bio = generate_qr_image(member_code)
    caption = (
        f"🪪 **{ORGANIZATION_NAME_AM}**\n\n"
        f"👤 **ስም:** {member_name}\n"
        f"🏷️ **Student ID:** `{member_code}`\n"
        f"🎒 **ክፍል:** {grade}\n"
        f"🏛️ **ኃላፊነት:** {dept}\n\n"
        "ይህን QR ኮድ በሰንበት መግቢያ በር ላይ ለስካነሩ ያሳዩ።"
    )

    markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
    if update.callback_query:
        await update.callback_query.message.reply_photo(photo=qr_bio, caption=caption, parse_mode="Markdown", reply_markup=markup)
    else:
        await update.message.reply_photo(photo=qr_bio, caption=caption, parse_mode="Markdown", reply_markup=markup)


async def attendance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command entry point; callback handlers must only receive callback updates."""
    await update.message.reply_text(
        "📋 ተገኝነት ለመመዝገብ ከታች ያለውን አዝራር ይጫኑ።",
        reply_markup=get_main_menu_keyboard(update.effective_user.id),
    )

# -------------------------------------------------------------
# SCHEDULE MENU HANDLER
# -------------------------------------------------------------

async def schedule_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🗓️ **የወልድ ዋሕድ ሰንበት ት/ቤት መርሐ ግብር (Class Schedule)**\n\n"
        "መርሐ ግብሩን በምን መልክ ማየት ይፈልጋሉ?\n"
        "ከታች ካሉት የክፍል ደረጃዎች አንዱን ይምረጡ፦"
    )
    keyboard = [
        [
            InlineKeyboardButton("🧸 ቅድመ አንደኛ", callback_data="grade_pre_kg"),
            InlineKeyboardButton("🎒 1ኛ እና 2ኛ ክፍል", callback_data="grade_1_2"),
        ],
        [
            InlineKeyboardButton("📚 3ኛ–5ኛ ክፍል", callback_data="grade_3_5"),
            InlineKeyboardButton("🎓 6ኛ–9ኛ ክፍል", callback_data="grade_6_9"),
        ],
        [
            InlineKeyboardButton("📅 አርብ", callback_data="sched_friday"),
            InlineKeyboardButton("📅 ቅዳሜ", callback_data="sched_saturday"),
            InlineKeyboardButton("📅 እሁድ", callback_data="sched_sunday"),
        ],
        [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    if update.callback_query:
        await update.callback_query.edit_message_text(text, parse_mode="Markdown", reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, parse_mode="Markdown", reply_markup=reply_markup)

# -------------------------------------------------------------
# CALLBACK QUERY ROUTER
# -------------------------------------------------------------

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = update.effective_user

    # 1. 📝 REGISTER PROFILE
    if data == "btn_register":
        member = get_member_by_telegram_id(user.id)
        if member:
            if member["status"] == "approved":
                msg = (
                    "✅ **ቀደም ሲል ተመዝግበው ጸድቀዋል! (Already Registered & Approved)**\n\n"
                    f"👤 **ስም:** {member['full_name_am']}\n"
                    f"🏷️ **Student ID:** `{member['code']}`\n"
                    f"🎒 **ክፍል:** {member['grade_level']}\n\n"
                    "ዲጂታል መታወቂያ ካርድዎን በ **'👤 My Profile'** ማግኘት ይችላሉ።"
                )
                markup = InlineKeyboardMarkup([
                    [InlineKeyboardButton("👤 My Profile", callback_data="btn_profile")],
                    [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
                ])
                await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
                return
            else:
                msg = (
                    "⏳ **ምዝገባዎ በአስተዳዳሪው እየታየ ነው! (Pending Approval)**\n\n"
                    f"👤 **ስም:** {member['full_name_am']}\n"
                    f"📞 **ስልክ:** {member['phone']}\n"
                    f"🎒 **ክፍል:** {member['grade_level']}\n\n"
                    "ዋና አስተዳዳሪው (Super Admin) መርምረው የ **Student ID** ቁጥር በእጅ ሰጥተው እንዳጸደቁት ወዲያውኑ ማረጋገጫ ይደርስዎታል!"
                )
                markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
                await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
                return

        # Start registration conversation
        context.user_data["reg_state"] = "WAITING_NAME"
        prompt = (
            "📝 **የተማሪ ምዝገባ ቅጽ (Student Registration - ደረጃ 1/4)**\n\n"
            "እባክዎ **ሙሉ ስምዎን (ስም + የአባት ስም + የአያት ስም)** ይጻፉልን፦\n"
            "*(ለምሳሌ፦ ኪዱስ ያሬድ መኮንን)*\n\n"
            "ለመሰረዝ /start ይጫኑ።"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="back_start")]])
        await query.edit_message_text(prompt, parse_mode="Markdown", reply_markup=markup)

    # Registration grade choice
    elif data.startswith("reg_grade_"):
        grade_key = data.replace("reg_grade_", "")
        grade_map = {
            "pre_kg": "ቅድመ አንደኛ",
            "1_2": "1ኛ እና 2ኛ ክፍል",
            "3_5": "3ኛ–5ኛ ክፍል",
            "6_9": "6ኛ–9ኛ ክፍል",
        }
        chosen_grade = grade_map.get(grade_key, "ቅድመ አንደኛ")
        context.user_data["reg_grade"] = chosen_grade
        context.user_data["reg_state"] = "WAITING_GENDER"

        prompt = (
            "🚻 **ደረጃ 4/4፦ ጾታዎን ይምረጡ (Gender)**\n\n"
            f"👤 ስም: **{context.user_data.get('reg_name')}**\n"
            f"📞 ስልክ: **{context.user_data.get('reg_phone')}**\n"
            f"🎒 ክፍል: **{chosen_grade}**\n\n"
            "እባክዎ ከታች ጾታዎን ይምረጡ፦"
        )
        markup = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("👨 ወንድ (Male)", callback_data="reg_gender_M"),
                InlineKeyboardButton("👩 ሴት (Female)", callback_data="reg_gender_F"),
            ],
            [InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="back_start")]
        ])
        await query.edit_message_text(prompt, parse_mode="Markdown", reply_markup=markup)

    # Registration gender choice -> Submit to database
    elif data.startswith("reg_gender_"):
        if context.user_data.get("reg_state") != "WAITING_GENDER" or not context.user_data.get("reg_name") or not context.user_data.get("reg_phone"):
            await query.edit_message_text("የምዝገባ ሂደቱ ጊዜው አልፎበታል። እባክዎ /start ብለው እንደገና ይጀምሩ።")
            return
        gender_code = data.replace("reg_gender_", "")
        if gender_code not in ("M", "F"):
            await query.edit_message_text("የተመረጠው ምርጫ ትክክል አይደለም። /start ብለው እንደገና ይጀምሩ።")
            return
        gender_label = "ወንድ" if gender_code == "M" else "ሴት"

        name = context.user_data["reg_name"]
        phone = context.user_data["reg_phone"]
        grade = context.user_data.get("reg_grade", "ቅድመ አንደኛ")

        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO members (code, full_name_am, phone, gender, grade_level, department, role, telegram_id, telegram_username, status)
                VALUES (NULL, ?, ?, ?, ?, 'የሰንበት ት/ቤት ተማሪ', 'student', ?, ?, 'pending')
            """, (name, phone, gender_label, grade, user.id, user.username or ""))
            conn.commit()
            conn.close()
        except Exception as exc:
            try:
                conn.close()
            except Exception:
                pass
            print(f"Registration database error: {type(exc).__name__}: {exc}")
            await query.edit_message_text(
                "❌ ምዝገባው አልተቀመጠም። ይህ ስልክ ቁጥር ከዚህ በፊት ተመዝግቦ ሊሆን ይችላል፤ እባክዎ አስተዳዳሪውን ያነጋግሩ።",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ዋና ገጽ", callback_data="back_start")]])
            )
            return

        context.user_data.clear()

        success_msg = (
            "🎉 **ምዝገባዎ በተሳካ ሁኔታ ተልኳል! (Registration Submitted)**\n\n"
            f"👤 **ሙሉ ስም:** {name}\n"
            f"📞 **ስልክ ቁጥር:** {phone}\n"
            f"🎒 **የክፍል ደረጃ:** {grade}\n"
            f"🚻 **ጾታ:** {gender_label}\n"
            "📌 **ሁኔታ:** ⏳ ማጽደቅ የሚጠብቅ (Pending Approval)\n\n"
            "🔔 **ማስታወሻ፦**\n"
            "የሰንበት ት/ቤቱ ዋና አስተዳዳሪ (Super Admin) መርምረው የ **Student ID** ቁጥር በእጅ መድበው እንዳጸደቁት ማረጋገጫ ይደርስዎታል እና የ **Digital QR ID Card** ይዘጋጅልዎታ።"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
        await query.edit_message_text(success_msg, parse_mode="Markdown", reply_markup=markup)

        try:
            admin_alert = (
                "🔔 **አዲስ የተማሪ ምዝገባ ማጽደቂያ ጥያቄ ደርሷል! (New Pending Approval)**\n\n"
                f"👤 **ስም:** {name}\n"
                f"📞 **ስልክ:** {phone}\n"
                f"🎒 **ክፍል:** {grade}\n"
                f"🆔 **Telegram ID:** `{user.id}`\n\n"
                "ተማሪውን አጽድቀው Student ID ለመስጠት በዳሽቦርዱ ይጠቀሙ፦\n"
                f"👉 {ADMIN_DASHBOARD_URL}"
            )
            await context.bot.send_message(
                chat_id=SUPER_ADMIN_ID,
                text=admin_alert,
                parse_mode="Markdown",
            )
        except Exception:
            pass

    # 2. 📋 MARK ATTENDANCE (PRESENCE VERIFICATION CHECK)
    elif data == "btn_attendance":
        member = get_member_by_telegram_id(user.id)
        if not member:
            msg = (
                "⚠️ **እስካሁን አልተመዘገቡም! (Not Registered)**\n\n"
                "ተገኝነት ለመመዝገብ መጀመሪያ በቦቱ ላይ መመዝገብ አለብዎት።\n"
                "እባክዎ ከታች **'📝 Register Profile'** የሚለውን ይጫኑ።"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("📝 Register Profile", callback_data="btn_register")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
            ])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        if member["status"] != "approved":
            msg = (
                "⏳ **ምዝገባዎ ገና አልጸደቀም! (Pending Approval)**\n\n"
                f"👤 ስም: {member['full_name_am']}\n\n"
                "የሰንበት ት/ቤቱ አስተዳዳሪ የ Student ID ቁጥር ሰጥተው እንዳጸደቁዎት ተገኝነት መመዝገብ ይችላሉ። እባክዎ በትዕግስት ይጠብቁ።"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        # Check if attendance already marked today
        today_str = local_now().date().isoformat()
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM attendance WHERE member_id = ? AND date = ?", (member["id"], today_str))
        att_row = cursor.fetchone()
        conn.close()

        if att_row:
            msg = (
                "✅ **ዛሬ ተገኝተዋል ተብለው ተመዝግበዋል! (Attendance Already Marked)**\n\n"
                f"👤 **ስም:** {member['full_name_am']}\n"
                f"🏷️ **Student ID:** `{member['code']}`\n"
                f"🎒 **ክፍል:** {member['grade_level']}\n"
                f"📅 **ቀን:** {today_str}\n"
                f"⏰ **የተመዘገበበት ሰዓት:** {att_row['time']}\n"
                f"📌 **የተመዘገበበት መንገድ:** {att_row['method']}\n\n"
                "መልካም የሰንበት ት/ቤት ቆይታ ይሁንልዎት! 🙏"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("🪪 የQR መታወቂያ ካርድ (Show QR)", callback_data="get_card")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
            ])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        # STRICT VERIFICATION: Student CANNOT mark attendance blindly from home!
        # Prompt them with presence verification options:
        msg = (
            "📍 **የአካል መገኘት ማረጋገጫ (Presence Verification)**\n\n"
            f"ሰላም **{member['full_name_am']}**! ተገኝነትዎ እንዲመዘገብ በትምህርት ቤቱ ቅጥር ግቢ ውስጥ በአካል መገኘትዎን ማረጋገጥ ያስፈልጋል፦\n\n"
            "ከታች ካሉት የማረጋገጫ አማራጮች አንዱን ይምረጡ፦\n\n"
            "1️⃣ **📍 በቦታዬ (GPS Location) አረጋግጥ**\n"
            "• ስልክዎ ላይ ያለውን የቦታ መረጃ (GPS) በመላክ በት/ቤቱ ግቢ ውስጥ (እስከ 300 ሜትር) መሆንዎን ያረጋግጡ።\n\n"
            "2️⃣ **🔑 የመማሪያ ክፍል ሚስጥር ኮድ (Class PIN)**\n"
            "• ዛሬ በክፍል ውስጥ በመምህሩ የተሰጠውን ባለ 4-አሃዝ የሚስጥር ኮድ ያስገቡ።\n\n"
            "3️⃣ **🪪 የQR መታወቂያ ካርድ**\n"
            "• በበሩ ስካነር ላይ በQR መታወቂያዎ ስካን ያድርጉ።"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("📍 በቦታዬ (GPS Location) አረጋግጥ", callback_data="att_method_gps")],
            [InlineKeyboardButton("🔑 በክፍል ሚስጥር ኮድ (PIN) አረጋግጥ", callback_data="att_method_pin")],
            [InlineKeyboardButton("🪪 የQR መታወቂያዬን አሳይ (Scan at Gate)", callback_data="get_card")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
        ])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 2A. Method: GPS Location Request
    elif data == "att_method_gps":
        member = get_member_by_telegram_id(user.id)
        if not member or member["status"] != "approved":
            await query.edit_message_text("ይቅርታ፣ ተገኝነት ለመመዝገብ መጀመሪያ የጸደቀ ተማሪ መሆን አለብዎት።")
            return

        context.user_data["waiting_location"] = True
        loc_keyboard = ReplyKeyboardMarkup(
            [[KeyboardButton(text="📍 አሁን ያለሁበትን ቦታ ላክ (Send Current Location)", request_location=True)]],
            resize_keyboard=True,
            one_time_keyboard=True,
        )
        instruction = (
            "📍 **የቦታ መረጃዎን ለመላክ፦**\n\n"
            "ከታች በኪቦርዱ ላይ የሚታየውን ሰማያዊ **'📍 አሁን ያለሁበትን ቦታ ላክ'** የሚለውን አዝራር ይጫኑ።\n\n"
            "⚠️ **ማስታወሻ፦**\n"
            f"ቦቱ ከእርስዎ እስከ ሰንበት ት/ቤቱ ቅጥር ግቢ ያለውን ርቀት ያሰላል። በትምህርት ቤቱ ግቢ ውስጥ (እስከ {MAX_ATTENDANCE_DISTANCE_METERS} ሜትር ራዲየስ) ካልተገኙ ተገኝነቱ **ውድቅ** ይደረጋል።"
        )
        # We must send a new message to pop up the ReplyKeyboardMarkup with request_location
        await query.message.reply_text(instruction, parse_mode="Markdown", reply_markup=loc_keyboard)

    # 2B. Method: Daily Attendance PIN
    elif data == "att_method_pin":
        context.user_data["att_pin_state"] = True
        msg = (
            "🔑 **የዛሬው የመማሪያ ክፍል ሚስጥር ኮድ (Daily Class PIN)**\n\n"
            "እባክዎ ዛሬ በሰንበት ት/ቤት መምህርዎ በክፍል ውስጥ የተሰጠውን **ባለ 4-አሃዝ የሚስጥር ኮድ** በጽሁፍ ይላኩልን፦\n\n"
            "*(ለመሰረዝ /start ይጫኑ)*"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="back_start")]])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 3. 👤 MY PROFILE
    elif data == "btn_profile":
        member = get_member_by_telegram_id(user.id)
        if not member:
            msg = (
                "⚠️ **እስካሁን አልተመዘገቡም! (Not Registered)**\n\n"
                "ፕሮፋይልዎን ለማየት መጀመሪያ በቦቱ ላይ መመዝገብ አለብዎት።\n"
                "እባክዎ ከታች **'📝 Register Profile'** የሚለውን ይጫኑ።"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("📝 Register Profile", callback_data="btn_register")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
            ])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM attendance WHERE member_id = ?", (member["id"],))
        att_count = cursor.fetchone()[0]
        conn.close()

        is_approved = member["status"] == "approved"
        status_text = "✅ የጸደቀ ተማሪ (Active & Approved)" if is_approved else "⏳ ማጽደቅ የሚጠብቅ (Pending Approval)"
        student_id_text = f"`{member['code']}`" if member["code"] else "በአስተዳዳሪው ሂደት ላይ (Pending)"

        msg = (
            "👤 **የተማሪ ፕሮፋይል (Student Profile)**\n"
            "─────────────────────────\n"
            f"🏷️ **Student ID:** {student_id_text}\n"
            f"👤 **ሙሉ ስም:** {member['full_name_am']}\n"
            f"📞 **ስልክ ቁጥር:** {member['phone']}\n"
            f"🎒 **የትምህርት ክፍል:** {member['grade_level'] or 'አጠቃላይ'}\n"
            f"🏛️ **ኃላፊነት:** {member['department'] or 'የሰንበት ት/ቤት ተማሪ'}\n"
            f"🚻 **ጾታ:** {member['gender'] or 'አልተገለጸም'}\n"
            f"📌 **ሁኔታ:** {status_text}\n"
            f"📊 **ጠቅላላ የተገኙባቸው ቀናት:** **{att_count} ቀናት**\n"
            f"📅 **የተመዘገቡበት:** {str(member['created_at'])[:10]}\n"
            "─────────────────────────"
        )
        buttons = []
        if is_approved:
            buttons.append([InlineKeyboardButton("🪪 የQR መታወቂያዬን አውርድ/አሳይ", callback_data="get_card")])
        buttons.append([
            InlineKeyboardButton("📅 የተገኝነት ታሪክ", callback_data="btn_my_history"),
            InlineKeyboardButton("🗓️ የክፍሌ መርሐ ግብር", callback_data="sched_menu"),
        ])
        buttons.append([InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))

    # 4. 📅 MY ATTENDANCE HISTORY
    elif data == "btn_my_history":
        member = get_member_by_telegram_id(user.id)
        if not member:
            msg = "ተገኝነትዎን ለማየት መጀመሪያ መመዝገብ አለብዎት።"
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("📝 Register Profile", callback_data="btn_register")]])
            await query.edit_message_text(msg, reply_markup=markup)
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM attendance WHERE member_id = ? ORDER BY date DESC, time DESC LIMIT 10", (member["id"],))
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            msg = (
                f"📅 **የተገኝነት ታሪክ (Attendance Record)**\n\n"
                f"👤 **ተማሪ:** {member['full_name_am']}\n"
                f"🏷️ **Student ID:** `{member['code'] or 'በሂደት ላይ'}`\n\n"
                "እስካሁን የተመዘገበ የተገኝነት ታሪክ የለም። እሁድ እሁድ በትምህርት ቤቱ ቅጥር ግቢ ሲገኙ በቦቱ ወይም በበሩ ስካነር ይመዝገቡ!"
            )
        else:
            msg = (
                f"📅 **የተገኝነት ታሪክ (Attendance Record)**\n"
                f"👤 **ተማሪ:** {member['full_name_am']} (`{member['code']}`)\n"
                f"📊 **አጠቃላይ የተገኙባቸው:** {len(rows)} ቀናት\n"
                "─────────────────────────\n"
            )
            for r in rows:
                method_icon = "📍 GPS" if r["method"] == "gps_location" else ("🔑 PIN" if r["method"] == "class_pin" else "🪪 QR")
                msg += f"• **{r['date']}** | ⏰ {r['time']} ({method_icon})\n"
            msg += "─────────────────────────"

        markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 5. 🗓️ CLASS SCHEDULE
    elif data == "sched_menu":
        await schedule_menu(update, context)
    elif data == "grade_pre_kg":
        await query.edit_message_text(SCHEDULE_BY_GRADE["pre_kg"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "grade_1_2":
        await query.edit_message_text(SCHEDULE_BY_GRADE["grade_1_2"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "grade_3_5":
        await query.edit_message_text(SCHEDULE_BY_GRADE["grade_3_5"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "grade_6_9":
        await query.edit_message_text(SCHEDULE_BY_GRADE["grade_6_9"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "sched_friday":
        await query.edit_message_text(SCHEDULE_BY_DAY["friday"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "sched_saturday":
        await query.edit_message_text(SCHEDULE_BY_DAY["saturday"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))
    elif data == "sched_sunday":
        await query.edit_message_text(SCHEDULE_BY_DAY["sunday"], parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ መርሐ ግብር ተመለስ", callback_data="sched_menu")]]))

    # 6. 🆘 SUPPORT CENTER (WITH LEAVE REQUEST FEATURE!)
    elif data == "btn_support":
        msg = (
            "🆘 **የድጋፍ፣ የፈቃድ እና የምክር መስጫ ማዕከል (Support Center)**\n\n"
            "እንዴት ልንረዳዎ እንችላለን?\n"
            "ከታች ካሉት አማራጮች አንዱን ይምረጡ፦\n\n"
            "• **📝 የፈቃድ መጠየቂያ፦** በሰንበት ት/ቤት መገኘት ለማይችሉበት ጊዜ ፈቃድ ለመጠየቅ\n"
            "• **🙏 የጸሎት ጥያቄ፦** በሰንበት ት/ቤት መምህራን በጸሎት እንድታሰቡ\n"
            "• **💬 የምክር አገልግሎት፦** መንፈሳዊ ወይም ማህበራዊ ምክር ለማግኘት\n"
            "• **📞 የአመራሮች አድራሻ፦** ቢሮውን በቀጥታ ለማግኘት"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("📝 የፈቃድ መጠየቂያ (Request Leave / Excuse)", callback_data="sup_leave")],
            [InlineKeyboardButton("🙏 የጸሎት ጥያቄ ላክ", callback_data="sup_prayer")],
            [InlineKeyboardButton("💬 የምክር አገልግሎት ጥያቄ", callback_data="sup_counsel")],
            [InlineKeyboardButton("📞 የአመራሮች አድራሻ እና ቢሮ", callback_data="sup_contact")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")],
        ])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 6A. LEAVE REQUEST FLOW (ደረጃ 1፦ አይነት መምረጥ)
    elif data == "sup_leave":
        member = get_member_by_telegram_id(user.id)
        if not member:
            msg = (
                "⚠️ **እስካሁን አልተመዘገቡም!**\n\n"
                "የፈቃድ መጠየቂያ ለማስገባት መጀመሪያ በቦቱ ላይ መመዝገብ አለብዎት።"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("📝 Register Profile", callback_data="btn_register")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ", callback_data="back_start")]
            ])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        msg = (
            "📝 **የተማሪ ፈቃድ መጠየቂያ (Leave Request - ደረጃ 1/3)**\n\n"
            f"👤 ተማሪ፦ **{member['full_name_am']}** (`{member['code'] or 'በሂደት ላይ'}`)\n\n"
            "እባክዎ የሚፈልጉትን **የፈቃድ አይነት** ይምረጡ፦"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🤒 የህመም ፈቃድ (Medical / Sick Leave)", callback_data="ltype_ህመም")],
            [InlineKeyboardButton("📚 የትምህርት / ፈተና (Study / Exam)", callback_data="ltype_ፈተና")],
            [InlineKeyboardButton("👨‍👩‍👧 የቤተሰብ ጉዳይ (Family Matter)", callback_data="ltype_ቤተሰብ")],
            [InlineKeyboardButton("✈️ የጉዞ ወይም የስራ ፈቃድ (Travel / Work)", callback_data="ltype_ጉዞ")],
            [InlineKeyboardButton("📝 ሌላ አስፈላጊ ምክንያት (Other)", callback_data="ltype_ሌላ")],
            [InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="btn_support")],
        ])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 6B. LEAVE REQUEST (ደረጃ 2፦ ቆይታ መምረጥ)
    elif data.startswith("ltype_"):
        ltype = data.replace("ltype_", "")
        type_labels = {
            "ህመም": "🤒 የህመም ፈቃድ (Medical)",
            "ፈተና": "📚 የትምህርት / ፈተና (Exam)",
            "ቤተሰብ": "👨‍👩‍👧 የቤተሰብ ጉዳይ (Family)",
            "ጉዞ": "✈️ የጉዞ ፈቃድ (Travel)",
            "ሌላ": "📝 ሌላ ምክንያት (Other)",
        }
        chosen_type = type_labels.get(ltype, ltype)
        context.user_data["leave_type"] = chosen_type

        msg = (
            "📅 **ደረጃ 2/3፦ የፈቃድ ቆይታ (Duration)**\n\n"
            f"🏷️ አይነት፦ **{chosen_type}**\n\n"
            "ለስንት ጊዜ ወይም ለምን ያህል ሰንበታት ፈቃድ ይፈልጋሉ?"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("1️⃣ ለአንድ እሁድ (1 Sunday)", callback_data="ldur_1 እሁድ")],
            [InlineKeyboardButton("2️⃣ ለሁለት እሁዶች (2 Sundays)", callback_data="ldur_2 እሁዶች")],
            [InlineKeyboardButton("📅 ለአንድ ወር (1 Month)", callback_data="ldur_1 ወር")],
            [InlineKeyboardButton("✍️ ሌላ የተለየ ቀን (Custom Dates)", callback_data="ldur_የተለየ ቀን")],
            [InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="btn_support")],
        ])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 6C. LEAVE REQUEST (ደረጃ 3፦ ምክንያት በጽሁፍ ማስገባት)
    elif data.startswith("ldur_"):
        chosen_dur = data.replace("ldur_", "")
        context.user_data["leave_dur"] = chosen_dur
        context.user_data["leave_state"] = "WAITING_REASON"

        msg = (
            "✍️ **ደረጃ 3/3፦ የፈቃድ ምክንያት (Reason / Explanation)**\n\n"
            f"🏷️ አይነት፦ **{context.user_data.get('leave_type')}**\n"
            f"📅 ቆይታ፦ **{chosen_dur}**\n\n"
            "እባክዎ የፈቃድ መጠየቂያዎን ምክንያት ወይም ዝርዝር ማብራሪያ በአጭሩ ጽፈው ይላኩልን፦\n"
            "*(ለምሳሌ፦ የዩኒቨርሲቲ የፍጻሜ ፈተና ስላለኝ ነው / በህመም ምክንያት ሐኪም ቤት እገኛለሁ...)*\n\n"
            "ለመሰረዝ /start ይጫኑ።"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="btn_support")]])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 6D. ADMIN APPROVE LEAVE (Via Telegram Callback)
    elif data.startswith("lappr_"):
        is_admin, _ = check_is_admin(user.id)
        if not is_admin:
            await query.answer("ይህንን ለመፈጸም የአስተዳዳሪ ፈቃድ የለዎትም።", show_alert=True)
            return
        req_id = int(data.replace("lappr_", ""))
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leave_requests WHERE id = ?", (req_id,))
        l_row = cursor.fetchone()
        if l_row:
            cursor.execute("""
                UPDATE leave_requests
                SET status = 'approved', approved_by = ?, reviewed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (user.id, req_id))
            conn.commit()
            conn.close()

            await query.edit_message_text(
                f"✅ **የተማሪው ፈቃድ ጸድቋል! (Leave Approved)**\n\n"
                f"👤 ተማሪ፦ {l_row['student_name']} (`{l_row['student_code']}`)\n"
                f"🏷️ አይነት፦ {l_row['leave_type']}\n"
                f"📅 ቆይታ፦ {l_row['duration']}\n"
                f"👑 ያጸደቀው አስተዳዳሪ፦ {user.first_name} (`{user.id}`)",
                parse_mode="Markdown"
            )

            # Alert student
            if l_row["telegram_id"]:
                try:
                    await context.bot.send_message(
                        chat_id=l_row["telegram_id"],
                        text=(
                            "🎉 **የፈቃድ ማመልከቻዎ ጸድቋል! (Leave Approved)**\n\n"
                            f"👤 ተማሪ፦ {l_row['student_name']}\n"
                            f"📋 ማመልከቻ ቁጥር፦ `{l_row['request_number']}`\n"
                            f"🏷️ አይነት፦ {l_row['leave_type']}\n"
                            f"📅 ቆይታ፦ {l_row['duration']}\n\n"
                            "በሰንበት ት/ቤቱ አስተዳዳሪ ጸድቋል። ጉዳይዎን ወይም ፈተናዎን በሰላም ያጠናቅቁ! 🙏"
                        ),
                        parse_mode="Markdown"
                    )
                except Exception:
                    pass
        else:
            conn.close()
            await query.edit_message_text("የፈቃድ ማመልከቻው አልተገኘም።")

    # 6E. ADMIN REJECT LEAVE (Via Telegram Callback)
    elif data.startswith("lrejc_"):
        is_admin, _ = check_is_admin(user.id)
        if not is_admin:
            await query.answer("ይህንን ለመፈጸም የአስተዳዳሪ ፈቃድ የለዎትም።", show_alert=True)
            return
        req_id = int(data.replace("lrejc_", ""))
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leave_requests WHERE id = ?", (req_id,))
        l_row = cursor.fetchone()
        if l_row:
            cursor.execute("""
                UPDATE leave_requests
                SET status = 'rejected', approved_by = ?, reviewed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (user.id, req_id))
            conn.commit()
            conn.close()

            await query.edit_message_text(
                f"❌ **የተማሪው የፈቃድ ጥያቄ ውድቅ ተደርጓል! (Leave Rejected)**\n\n"
                f"👤 ተማሪ፦ {l_row['student_name']} (`{l_row['student_code']}`)\n"
                f"👑 አስተዳዳሪ፦ {user.first_name} (`{user.id}`)",
                parse_mode="Markdown"
            )

            if l_row["telegram_id"]:
                try:
                    await context.bot.send_message(
                        chat_id=l_row["telegram_id"],
                        text=(
                            "⚠️ **የፈቃድ ማመልከቻዎ ውድቅ ተደርጓል (Leave Request Rejected)**\n\n"
                            f"📋 ማመልከቻ ቁጥር፦ `{l_row['request_number']}`\n"
                            "እባክዎ ለተጨማሪ መረጃ የሰንበት ት/ቤቱን ቢሮ ወይም ክፍል ኃላፊዎን ያነጋግሩ።"
                        ),
                        parse_mode="Markdown"
                    )
                except Exception:
                    pass
        else:
            conn.close()
            await query.edit_message_text("የፈቃድ ማመልከቻው አልተገኘም።")

    elif data in ("sup_prayer", "sup_counsel"):
        category = "የጸሎት ጥያቄ" if data == "sup_prayer" else "የምክር አገልግሎት"
        context.user_data["support_state"] = "WAITING_MSG"
        context.user_data["support_cat"] = category

        msg = (
            f"✍️ **{category} ለመላክ፦**\n\n"
            "እባክዎ መልዕክትዎን ወይም ጥያቄዎን በአጭሩ ጽፈው ይላኩልን።\n"
            "መልዕክትዎ በሚስጥር ለአስተዳዳሪው እና ለመምህራን ይደርሳል።\n\n"
            "ለመሰረዝ /start ይጫኑ።"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="btn_support")]])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    elif data == "sup_contact":
        msg = (
            "📞 **የሰንበት ት/ቤት አመራሮች እና የቢሮ አድራሻ፦**\n\n"
            "🏛️ **የወልድ ዋሕድ ሰንበት ትምህርት ቤት (ፍትሐፖል)**\n"
            "📍 **ቦታ:** አዲስ አበባ፣ ኢትዮጵያ\n"
            "⏰ **የቢሮ ሰዓት:** ቅዳሜ እና እሁድ ከ 2:30 – 11:30\n\n"
            "☎️ **የስልክ ቁጥር:** +251 91 122 3344 / +251 92 233 4455\n"
            "📧 **ኢሜይል:** support@fithapol.church\n"
            "🌐 **ዌብሳይት:** https://fithapol.church"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ ወደ ድጋፍ ማዕከል ተመለስ", callback_data="btn_support")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")],
        ])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    # 7. 🔐 ADMIN DASHBOARD
    elif data == "btn_admin":
        is_admin, role = check_is_admin(user.id)
        if not is_admin:
            msg = (
                "🔐 **Admin Dashboard - የተከለከለ (Restricted)**\n\n"
                "ይህ ክፍል ለሰንበት ት/ቤቱ አስተዳዳሪዎች ብቻ የተፈቀደ ነው።\n\n"
                f"👤 የእርስዎ ቴሌግራም መለያ ቁጥር (ID)፦\n👉 `{user.id}`\n\n"
                "የአስተዳዳሪነት ፈቃድ ለማግኘት ይህንን ID ቁጥር ለዋና አስተዳዳሪው (Super Admin) ያሳውቁ።"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM members")
        total_m = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM members WHERE status = 'pending'")
        pending_c = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM leave_requests WHERE status = 'pending'")
        leave_c = cursor.fetchone()[0]
        today_str = local_now().date().isoformat()
        cursor.execute("SELECT COUNT(*) FROM attendance WHERE date = ?", (today_str,))
        att_c = cursor.fetchone()[0]
        conn.close()

        msg = (
            "👑 **የዋና አስተዳዳሪ መቆጣጠሪያ ሰሌዳ (Admin Security Dashboard)**\n\n"
            f"👤 **አስተዳዳሪ:** {user.first_name} (`{user.id}`)\n"
            f"🛡️ **ሚና:** {'ዋና አስተዳዳሪ (Super Admin)' if role == 'super_admin' else 'ረዳት አስተዳዳሪ (Sub-Admin)'}\n\n"
            f"📊 **የሲስተሙ አጠቃላይ ቁጥሮች፦**\n"
            f"• አጠቃላይ ተማሪዎች: **{total_m}**\n"
            f"• ማጽደቅ የሚጠብቁ ተማሪዎች: **{pending_c}**\n"
            f"• ማጽደቅ የሚጠብቁ ፈቃዶች: **{leave_c}**\n"
            f"• የዛሬ የተገኙ: **{att_c}**\n\n"
            f"🌐 **የዌብ አስተዳዳሪ ገጽ (Web Dashboard):**\n"
            f"👉 `{ADMIN_DASHBOARD_URL}`\n"
            "የመግቢያ መረጃው በአስተዳዳሪው የተዋቀረ ነው፤ የይለፍ ቃል በቦት መልዕክት አይታይም።\n\n"
            "በዳሽቦርዱ ላይ ተማሪዎችን በእጅ Student ID ሰጥተው ማጽደቅ እንዲሁም የተማሪዎችን ፈቃድ ማየት ይችላሉ።"
        )
        buttons = []
        if pending_c > 0:
            buttons.append([InlineKeyboardButton(f"📋 ማጽደቅ የሚጠብቁ ተማሪዎች ({pending_c})", callback_data="admin_pending")])
        if leave_c > 0:
            buttons.append([InlineKeyboardButton(f"📝 ማጽደቅ የሚጠብቁ ፈቃዶች ({leave_c})", callback_data="admin_leaves")])
        buttons.append([InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")])
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))

    elif data == "admin_pending":
        is_admin, _ = check_is_admin(user.id)
        if not is_admin:
            await query.edit_message_text("ይህንን ገጽ ለማየት የአስተዳዳሪ ፈቃድ ያስፈልጋል።")
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM members WHERE status = 'pending' ORDER BY id DESC LIMIT 5")
        pendings = cursor.fetchall()
        conn.close()

        if not pendings:
            msg = "🎉 በአሁኑ ሰዓት ማጽደቅ የሚጠብቅ አዲስ ተማሪ የለም። ሁሉም ተማሪዎች ጸድቀዋል!"
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ አስተዳዳሪ ክፍል", callback_data="btn_admin")]])
        else:
            msg = "📋 **ማጽደቅ የሚጠብቁ አዳዲስ ተማሪዎች፦**\n\n"
            for p in pendings:
                msg += f"• **{p['full_name_am']}** ({p['phone']})\n  ክፍል: {p['grade_level'] or 'አዲስ'}\n\n"
            msg += f"ተማሪዎችን በእጅ (Manually) Student ID ሰጥተው ለማጽደቅ በዌብ ዳሽቦርዱ ይጠቀሙ፦\n👉 {ADMIN_DASHBOARD_URL}"
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ ወደ አስተዳዳሪ ክፍል", callback_data="btn_admin")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
            ])

        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)

    elif data == "admin_leaves":
        is_admin, _ = check_is_admin(user.id)
        if not is_admin:
            await query.edit_message_text("ይህንን ገጽ ለማየት የአስተዳዳሪ ፈቃድ ያስፈልጋል።")
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leave_requests WHERE status = 'pending' ORDER BY id DESC LIMIT 5")
        leaves = cursor.fetchall()
        conn.close()

        if not leaves:
            msg = "🎉 ማጽደቅ የሚጠብቅ የፈቃድ ጥያቄ የለም!"
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ አስተዳዳሪ ክፍል", callback_data="btn_admin")]])
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=markup)
        else:
            for l in leaves:
                txt = (
                    f"📝 **የፈቃድ ማመልከቻ፦** `{l['request_number']}`\n"
                    f"👤 **ተማሪ:** {l['student_name']} (`{l['student_code'] or 'ተማሪ'}`)\n"
                    f"🏷️ **አይነት:** {l['leave_type']}\n"
                    f"📅 **ቆይታ:** {l['duration']}\n"
                    f"📝 **ምክንያት:** {l['reason']}\n"
                )
                btns = [
                    [
                        InlineKeyboardButton("✅ አጽድቅ (Approve)", callback_data=f"lappr_{l['id']}"),
                        InlineKeyboardButton("❌ ውድቅ አድርግ (Reject)", callback_data=f"lrejc_{l['id']}"),
                    ]
                ]
                await query.message.reply_text(txt, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(btns))

    elif data == "get_card":
        await card_command(update, context)

    elif data == "back_start":
        await start_command(update, context)

# -------------------------------------------------------------
# GPS LOCATION MESSAGE HANDLER (PRESENCE VERIFICATION)
# -------------------------------------------------------------

async def handle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Handles native Telegram location message sent by student to verify physical presence at Sunday school.
    Calculates distance to school using Haversine formula.
    """
    user = update.effective_user
    location = update.message.location
    if not context.user_data.get("waiting_location"):
        await update.message.reply_text("ቦታ መላክ የሚቻለው ከAttendance ሜኑ ውስጥ GPS ከመረጡ በኋላ ብቻ ነው።", reply_markup=ReplyKeyboardRemove())
        return
    context.user_data["waiting_location"] = False
    window_error = attendance_window_error()
    if window_error:
        await update.message.reply_text(window_error, reply_markup=ReplyKeyboardRemove())
        return

    member = get_member_by_telegram_id(user.id)
    if not member:
        await update.message.reply_text(
            "⚠️ እባክዎ መጀመሪያ በቦቱ ይመዝገቡ።",
            reply_markup=ReplyKeyboardRemove(),
        )
        return

    if member["status"] != "approved":
        await update.message.reply_text(
            "⏳ ምዝገባዎ በአስተዳዳሪው ገና አልጸደቀም።",
            reply_markup=ReplyKeyboardRemove(),
        )
        return

    # Check if attendance already marked today
    today_str = local_now().date().isoformat()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM attendance WHERE member_id = ? AND date = ?", (member["id"], today_str))
    att_row = cursor.fetchone()
    if att_row:
        conn.close()
        await update.message.reply_text(
            f"✅ **ዛሬ ቀደም ሲል ተገኝተዋል ተብለው ተመዝግበዋል!**\n\n⏰ ሰዓት፦ {att_row['time']}",
            parse_mode="Markdown",
            reply_markup=ReplyKeyboardRemove(),
        )
        return

    # Calculate distance to Sunday School in meters
    user_lat = location.latitude
    user_lon = location.longitude
    distance_meters = haversine_distance(user_lat, user_lon, CHURCH_LATITUDE, CHURCH_LONGITUDE)

    # STRICT CHECK: Student must be physically within allowed radius
    if distance_meters <= MAX_ATTENDANCE_DISTANCE_METERS:
        # SUCCESS: Within school compound!
        now_time = local_now().strftime("%I:%M %p")
        cursor.execute("""
            INSERT INTO attendance (member_id, session_name, date, time, method)
            VALUES (?, 'የእሁድ ሰንበት ት/ቤት መደበኛ ትምህርት', ?, ?, 'gps_location')
        """, (member["id"], today_str, now_time))
        conn.commit()
        conn.close()

        success_msg = (
            "✅ **ተገኝነትዎ በቦታ (GPS) ተረጋግጦ ተመዝግቧል! (Attendance Verified)**\n\n"
            f"👤 **ስም:** {member['full_name_am']}\n"
            f"🏷️ **Student ID:** `{member['code']}`\n"
            f"🎒 **ክፍል:** {member['grade_level']}\n"
            f"📍 **የተረጋገጠበት ርቀት:** {int(distance_meters)} ሜትር (በት/ቤቱ ቅጥር ግቢ ውስጥ)\n"
            f"📅 **ቀን:** {today_str}\n"
            f"⏰ **ሰዓት:** {now_time}\n\n"
            "🙏 ቃለ ሕይወትን ያሰማልን! ትምህርቱን በትጋት ይከታተሉ።"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🪪 የQR መታወቂያ ካርድ (Show QR)", callback_data="get_card")],
            [InlineKeyboardButton("📅 የተገኝነት ታሪክ (My History)", callback_data="btn_my_history")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
        ])
        await update.message.reply_text(
            success_msg,
            parse_mode="Markdown",
            reply_markup=ReplyKeyboardRemove(),
        )
        await update.message.reply_text("የተገኝነት ማረጋገጫ ተጠናቋል፦", reply_markup=markup)
    else:
        conn.close()
        # REJECTION: Too far away / Remote attempt!
        dist_km = distance_meters / 1000.0
        fail_msg = (
            "❌ **ተገኝነትዎ አልተመዘገበም (በትምህርት ቤቱ ቅጥር ግቢ ውስጥ አልተገኙም)!**\n\n"
            f"📍 ከእርስዎ እስከ ሰንበት ት/ቤቱ ቅጥር ግቢ ያለው ርቀት፦ **{dist_km:.2f} ኪ.ሜ** ({int(distance_meters)} ሜትር)\n"
            f"⚠️ የተፈቀደው ከፍተኛ ርቀት፦ **{MAX_ATTENDANCE_DISTANCE_METERS} ሜትር** ብቻ ነው!\n\n"
            "🚫 **ደንብ፦** ተማሪው በአካል ትምህርት ቤቱ ቅጥር ግቢ ሳይመጣ ከቤት ወይም ከሌላ ቦታ ሆኖ ተገኝነት መመዝገብ አይፈቀድለትም።\n\n"
            "እባክዎ በትምህርት ቤቱ ቅጥር ግቢ ውስጥ ሲደርሱ በድጋሚ ይሞክሩ ወይም በበሩ ስካነር ላይ በQR መታወቂያዎ ይጠቀሙ!"
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔑 በክፍል ሚስጥር ኮድ (PIN) ሞክር", callback_data="att_method_pin")],
            [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")],
        ])
        await update.message.reply_text(
            fail_msg,
            parse_mode="Markdown",
            reply_markup=ReplyKeyboardRemove(),
        )
        await update.message.reply_text("አማራጮች፦", reply_markup=markup)

# -------------------------------------------------------------
# TEXT MESSAGE HANDLER (REGISTRATION, LEAVE REASON & CLASS PIN)
# -------------------------------------------------------------

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text.strip()
    reg_state = context.user_data.get("reg_state")
    support_state = context.user_data.get("support_state")
    leave_state = context.user_data.get("leave_state")
    att_pin_state = context.user_data.get("att_pin_state")

    # A. Attendance Daily Class PIN Verification
    if att_pin_state:
        context.user_data["att_pin_state"] = False
        member = get_member_by_telegram_id(user.id)
        if not member or member["status"] != "approved":
            await update.message.reply_text("ተገኝነት ለመመዝገብ መጀመሪያ የጸደቀ ተማሪ መሆን አለብዎት።")
            return

        # Check configured PIN only; never accept a hard-coded bypass PIN.
        window_error = attendance_window_error()
        if window_error:
            await update.message.reply_text(window_error)
            return
        if DAILY_ATTENDANCE_PIN and text.strip() == DAILY_ATTENDANCE_PIN:
            today_str = local_now().date().isoformat()
            now_time = local_now().strftime("%I:%M %p")
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM attendance WHERE member_id = ? AND date = ?", (member["id"], today_str))
            if cursor.fetchone():
                conn.close()
                await update.message.reply_text("✅ ዛሬ ቀደም ሲል ተመዝግበዋል!")
                return

            cursor.execute("""
                INSERT INTO attendance (member_id, session_name, date, time, method)
                VALUES (?, 'የእሁድ ሰንበት ት/ቤት መደበኛ ትምህርት', ?, ?, 'class_pin')
            """, (member["id"], today_str, now_time))
            conn.commit()
            conn.close()

            success_msg = (
                "✅ **ተገኝነትዎ በክፍል ሚስጥር ኮድ (PIN) ተረጋግጦ ተመዝግቧል!**\n\n"
                f"👤 **ስም:** {member['full_name_am']}\n"
                f"🏷️ **Student ID:** `{member['code']}`\n"
                f"🎒 **ክፍል:** {member['grade_level']}\n"
                f"📅 **ቀን:** {today_str}\n"
                f"⏰ **ሰዓት:** {now_time}\n\n"
                "🙏 ቃለ ሕይወትን ያሰማልን! ትምህርቱን በትጋት ይከታተሉ።"
            )
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
            await update.message.reply_text(success_msg, parse_mode="Markdown", reply_markup=markup)
            return
        else:
            fail_msg = (
                "❌ **የገቡት የሚስጥር ኮድ የተሳሳተ ነው!**\n\n"
                "እባክዎ ከመምህርዎ ትክክለኛውን የዛሬ የሚስጥር ኮድ ጠይቀው እንደገና ይሞክሩ ወይም በቦታዎ (GPS) ያረጋግጡ።"
            )
            markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("🔑 እንደገና ኮድ አስገባ", callback_data="att_method_pin")],
                [InlineKeyboardButton("📍 በቦታዬ (GPS) አረጋግጥ", callback_data="att_method_gps")],
                [InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]
            ])
            await update.message.reply_text(fail_msg, parse_mode="Markdown", reply_markup=markup)
            return

    # B. Leave Request Reason Submission
    if leave_state == "WAITING_REASON":
        member = get_member_by_telegram_id(user.id)
        leave_type = context.user_data.get("leave_type", "ፈቃድ")
        leave_dur = context.user_data.get("leave_dur", "1 እሁድ")
        reason_text = text
        context.user_data.clear()

        # Save to leave_requests table
        req_num = f"LV-{datetime.date.today().strftime('%Y%m')}-{os.urandom(2).hex().upper()}"
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO leave_requests (request_number, member_id, student_name, student_code, telegram_id, leave_type, duration, reason, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            """, (
                req_num,
                member["id"] if member else None,
                member["full_name_am"] if member else user.first_name,
                member["code"] if member else None,
                user.id,
                leave_type,
                leave_dur,
                reason_text,
            ))
            new_req_id = cursor.lastrowid
            conn.commit()
            conn.close()
        except Exception as e:
            new_req_id = 1

        # Student receipt
        receipt_msg = (
            "🎉 **የፈቃድ መጠየቂያ ማመልከቻዎ በተሳካ ሁኔታ ተልኳል! (Leave Request Submitted)**\n\n"
            f"📋 **የማመልከቻ ቁጥር:** `{req_num}`\n"
            f"👤 **ተማሪ:** {member['full_name_am'] if member else user.first_name}\n"
            f"🏷️ **የፈቃድ አይነት:** {leave_type}\n"
            f"📅 **የፈቃድ ቆይታ:** {leave_dur}\n"
            f"📝 **ምክንያት:** {reason_text}\n"
            "📌 **ሁኔታ:** ⏳ ማጽደቅ የሚጠብቅ (Pending Review)\n\n"
            "🔔 **ማስታወሻ፦**\n"
            "የሰንበት ት/ቤቱ አስተዳዳሪ ማመልከቻዎን አይተው እንዳጸደቁት ማረጋገጫ ይደርስዎታል!"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
        await update.message.reply_text(receipt_msg, parse_mode="Markdown", reply_markup=markup)

        # Notify Super Admin (5281238412) with instant 1-click Approve/Reject buttons
        try:
            admin_leave_alert = (
                "🔔 **አዲስ የተማሪ ፈቃድ መጠየቂያ ደርሷል! (New Leave Request)**\n\n"
                f"👤 **ተማሪ:** {member['full_name_am'] if member else user.first_name} (`{member['code'] if member else 'አዲስ'}`)\n"
                f"📞 **ስልክ:** {member['phone'] if member else 'የለም'}\n"
                f"🎒 **ክፍል:** {member['grade_level'] if member else '-'}\n"
                f"🏷️ **የፈቃድ አይነት:** {leave_type}\n"
                f"📅 **ቆይታ:** {leave_dur}\n"
                f"📝 **ምክንያት:** {reason_text}\n"
                f"📋 **ቁጥር:** `{req_num}`\n\n"
                "ውሳኔዎን ከታች ካሉት አዝራሮች ይምረጡ፦"
            )
            admin_markup = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✅ ፈቃድ አጽድቅ (Approve)", callback_data=f"lappr_{new_req_id}"),
                    InlineKeyboardButton("❌ ውድቅ አድርግ (Reject)", callback_data=f"lrejc_{new_req_id}"),
                ]
            ])
            await context.bot.send_message(
                chat_id=SUPER_ADMIN_ID,
                text=admin_leave_alert,
                parse_mode="Markdown",
                reply_markup=admin_markup,
            )
        except Exception:
            pass
        return

    # Registration step 1: Name
    if reg_state == "WAITING_NAME":
        if len(text.strip()) < 3 or len(text.strip()) > 100:
            await update.message.reply_text("እባክዎ ቢያንስ 3 ፊደላት ያሉትን ሙሉ ስም ያስገቡ።")
            return
        context.user_data["reg_name"] = text.strip()
        context.user_data["reg_state"] = "WAITING_PHONE"
        msg = (
            "📞 **ደረጃ 2/4፦ ስልክ ቁጥር ያስገቡ**\n\n"
            f"👤 ስም: **{text}**\n\n"
            "እባክዎ **ስልክ ቁጥርዎን** ይላኩልን፦\n"
            "*(ለምሳሌ፦ 0911223344 ወይም +251911223344)*"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="back_start")]])
        await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=markup)
        return

    # Registration step 2: Phone
    elif reg_state == "WAITING_PHONE":
        phone_clean = re.sub(r"[\s()-]", "", text.strip())
        if not re.fullmatch(r"(?:\+2519\d{8}|09\d{8}|9\d{8})", phone_clean):
            await update.message.reply_text("የስልክ ቁጥሩ ትክክል አይደለም። ለምሳሌ 0911223344 ወይም +251911223344 ያስገቡ።")
            return
        if phone_clean.startswith("9") and not phone_clean.startswith("+251"):
            phone_clean = "0" + phone_clean
        context.user_data["reg_phone"] = phone_clean
        context.user_data["reg_state"] = "WAITING_GRADE"
        msg = (
            "🎒 **ደረጃ 3/4፦ የትምህርት ክፍል ደረጃ**\n\n"
            f"👤 ስም: **{context.user_data.get('reg_name')}**\n"
            f"📞 ስልክ: **{text}**\n\n"
            "የሚማሩበትን የክፍል ደረጃ ከታች ካሉት አዝራሮች ይምረጡ፦"
        )
        markup = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🧸 ቅድመ አንደኛ", callback_data="reg_grade_pre_kg"),
                InlineKeyboardButton("🎒 1ኛ እና 2ኛ ክፍል", callback_data="reg_grade_1_2"),
            ],
            [
                InlineKeyboardButton("📚 3ኛ–5ኛ ክፍል", callback_data="reg_grade_3_5"),
                InlineKeyboardButton("🎓 6ኛ–9ኛ ክፍል", callback_data="reg_grade_6_9"),
            ],
            [InlineKeyboardButton("❌ ሰርዝ (Cancel)", callback_data="back_start")]
        ])
        await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=markup)
        return

    # Support Message Input (Prayer / Counsel)
    elif support_state == "WAITING_MSG":
        cat = context.user_data.get("support_cat", "የድጋፍ ጥያቄ")
        context.user_data.clear()

        ticket_num = f"TK-{datetime.date.today().strftime('%Y%m')}-{os.urandom(2).hex().upper()}"
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO support_tickets (ticket_number, requester_name, category, title, description, status)
                VALUES (?, ?, ?, ?, ?, 'new')
            """, (ticket_num, user.first_name, cat, f"{cat} ከ {user.first_name}", text))
            conn.commit()
            conn.close()
        except Exception:
            pass

        msg = (
            f"✅ **መልዕክትዎ በተሳካ ሁኔታ ደርሶናል!**\n\n"
            f"📋 **የቲኬት ቁጥር:** `{ticket_num}`\n"
            f"🏷️ **አይነት:** {cat}\n\n"
            "መምህራን እና አስተዳዳሪዎች መልዕክትዎን አይተው ምላሽ ይሰጡዎታል። እግዚአብሔር ይባርክዎ! 🙏"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ ወደ ዋናው ገጽ (Back)", callback_data="back_start")]])
        await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=markup)
        return

    # Default fallback: show main menu
    await start_command(update, context)

def main():
    problems = validate_runtime_config()
    if problems:
        for problem in problems:
            print(f"CONFIG ERROR: {problem}")
        raise SystemExit(1)
    init_db()
    print("=" * 60)
    print(f"⛪ Starting {ORGANIZATION_NAME_AM} Bot")
    print("🔑 BOT_TOKEN: configured (value hidden)")
    print(f"👑 SUPER_ADMIN_ID: {SUPER_ADMIN_ID}")
    print(f"🌐 Admin Dashboard: {ADMIN_DASHBOARD_URL}")
    print(f"📍 Geolocation: lat {CHURCH_LATITUDE}, lon {CHURCH_LONGITUDE} (Max Radius: {MAX_ATTENDANCE_DISTANCE_METERS}m)")
    print("=" * 60)

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("schedule", schedule_menu))
    app.add_handler(CommandHandler("program", schedule_menu))
    app.add_handler(CommandHandler("myid", myid_command))
    app.add_handler(CommandHandler("card", card_command))
    app.add_handler(CommandHandler("attendance", attendance_command))

    # Callbacks
    app.add_handler(CallbackQueryHandler(button_callback))

    # GPS Location Handler for Presence Verification
    app.add_handler(MessageHandler(filters.LOCATION, handle_location))

    # Text Messages
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_message))

    # Error handling
    async def global_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        import traceback
        print(f"⚠️ Exception occurred: {context.error}")
        traceback.print_exception(None, context.error, context.error.__traceback__)

    app.add_error_handler(global_error_handler)

    print("Bot polling started! Listening for updates from Telegram...")
    app.run_polling()

if __name__ == "__main__":
    main()
