import os
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env", override=False)
except ImportError:
    env_file = BASE_DIR / ".env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOT_USERNAME = os.getenv("BOT_USERNAME", "attendanceforchurchbot").strip().lstrip("@")

# Super Admin is explicit; ADMIN_IDS contains regular/sub-admin IDs only.
try:
    SUPER_ADMIN_ID = int(os.getenv("SUPER_ADMIN_ID", "0").strip() or "0")
except ValueError:
    SUPER_ADMIN_ID = 0
raw_admin_ids = os.getenv("ADMIN_IDS", "")
ADMIN_IDS = []
for value in re.findall(r"\d+", raw_admin_ids):
    user_id = int(value)
    if user_id and user_id != SUPER_ADMIN_ID and user_id not in ADMIN_IDS:
        ADMIN_IDS.append(user_id)

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///fithapol_sundayschool.db")
if "///" in DATABASE_URL:
    _db_path = DATABASE_URL.split("///", 1)[1]
else:
    _db_path = os.getenv("DATABASE_PATH", "fithapol_sundayschool.db")
DATABASE_PATH = str((BASE_DIR / _db_path).resolve()) if not os.path.isabs(_db_path) else _db_path

SCHOOL_NAME = os.getenv("SCHOOL_NAME", "Fithapol Sunday School")
SCHOOL_NAME_AM = "የወልድ ዋሕድ ሰንበት ትምህርት ቤት (ፍትሐፖል)"
ORGANIZATION_NAME_AM = SCHOOL_NAME_AM
TIMEZONE = os.getenv("TIMEZONE", "Africa/Addis_Ababa")
ATTENDANCE_DAY = os.getenv("ATTENDANCE_DAY", "Sunday").strip().capitalize()
ATTENDANCE_OPEN_TIME = os.getenv("ATTENDANCE_OPEN_TIME", "08:00").strip()
ATTENDANCE_CLOSE_TIME = os.getenv("ATTENDANCE_CLOSE_TIME", "12:00").strip()
CHURCH_LATITUDE = float(os.getenv("CHURCH_LATITUDE", "9.0108"))
CHURCH_LONGITUDE = float(os.getenv("CHURCH_LONGITUDE", "38.7618"))
MAX_ATTENDANCE_DISTANCE_METERS = int(os.getenv("MAX_ATTENDANCE_DISTANCE_METERS", "300"))
DAILY_ATTENDANCE_PIN = os.getenv("DAILY_ATTENDANCE_PIN", "").strip()
SECRET_KEY = os.getenv("SECRET_KEY", "").strip()
ADMIN_DASHBOARD_USERNAME = os.getenv("ADMIN_DASHBOARD_USERNAME", "admin").strip()
ADMIN_DASHBOARD_PASSWORD = os.getenv("ADMIN_DASHBOARD_PASSWORD", "").strip()
ADMIN_DASHBOARD_URL = os.getenv("ADMIN_DASHBOARD_URL", "http://127.0.0.1:5001/").strip()
PORT = int(os.getenv("PORT", "5001"))


def validate_runtime_config(require_dashboard=False):
    problems = []
    if not BOT_TOKEN or BOT_TOKEN.upper().startswith(("YOUR_", "PASTE_")):
        problems.append("BOT_TOKEN is missing or still a placeholder; set it in python_backend/.env")
    if SUPER_ADMIN_ID <= 0:
        problems.append("SUPER_ADMIN_ID must be your Telegram numeric user ID")
    if not DAILY_ATTENDANCE_PIN or DAILY_ATTENDANCE_PIN.upper().startswith(("SET_", "YOUR_", "PASTE_")):
        problems.append("DAILY_ATTENDANCE_PIN must be set to a real PIN in python_backend/.env")
    if require_dashboard:
        if not SECRET_KEY or SECRET_KEY.upper().startswith(("GENERATE_", "SET_", "YOUR_")):
            problems.append("SECRET_KEY must be set to a private random value in python_backend/.env")
        if not ADMIN_DASHBOARD_PASSWORD or ADMIN_DASHBOARD_PASSWORD.upper().startswith(("SET_", "YOUR_", "PASTE_")):
            problems.append("ADMIN_DASHBOARD_PASSWORD must be set to a private strong password in python_backend/.env")
    return problems
