# የወልድ ዋሕድ ሰንበት ት/ቤት ቦት እና አስተዳዳሪ ሰሌዳ (Python Backend)

ይህ ክፍል የተጠቃሚውን ሙሉ ውቅር (Configuration) የያዘ ሲሆን፤ የቴሌግራም ቦቱን እና የዌብ አስተዳዳሪ ሰሌዳውን (Admin Dashboard) ያካትታል።

---

### ⚙️ የተካተቱት ቅንብሮች (Active Configuration)፦

* **BOT_TOKEN:** በ `.env` ውስጥ በግል ይቀመጣል።
* **BOT_USERNAME:** `@attendanceforchurchbot`
* **SUPER_ADMIN_ID:** በ `.env` ውስጥ ያዘጋጁ።
* **DATABASE:** `fithapol_sundayschool.db` (SQLite)
* **SCHOOL_NAME:** የወልድ ዋሕድ ሰንበት ትምህርት ቤት (ፍትሐፖል)
* **ATTENDANCE_DAY:** Sunday (እሁድ)
* **ATTENDANCE_TIME:** 08:00 – 12:00
* **ADMIN_DASHBOARD_URL:** `http://127.0.0.1:5001/`
* **DASHBOARD USERNAME:** በ `.env` ውስጥ ያዘጋጁ።
* **DASHBOARD PASSWORD:** በ `.env` ውስጥ ያዘጋጁ፤ በREADME ውስጥ አይጻፉ።

---

### 🚀 እንዴት ማስነሳት ይቻላል? (How to Run)

#### ለዊንዶውስ (Windows) ተጠቃሚዎች፦
1. ዚፑን ያውርዱ እና **Extract** ያድርጉት።
2. `python_backend/.env.example` ን `python_backend/.env` ብለው ይቅዱ እና አዲስ BOT_TOKEN፣ SUPER_ADMIN_ID፣ PIN እና የDashboard የይለፍ ቃል ያስገቡ። ከዚያ በኋላ የቀጣይ ደረጃዎቹን ይከተሉ።
2. ወደ `python_backend` ፎልደር ይግቡ።
3. **`start_all.bat`** የሚለውን ፋይል ደብል ክሊክ (Double Click) ያድርጉት!
   * ወዲያውኑ አስፈላጊውን package ይጭናል።
   * የዳሽቦርዱን ሰርቨር በ `http://127.0.0.1:5001/` ያስነሳል።
   * ቦቱን ያገናኛል!

#### በእጅ (Manually) ማስነሳት ከፈለጉ፦
```bash
cd python_backend
pip install -r requirements.txt

# ዳሽቦርዱን ለማስነሳት (Port 5001)
python admin_dashboard.py

# ቦቱን ለማስነሳት
python bot.py
```

---

### 🌟 ዋና ዋና አገልግሎቶች፦

1. **ለተማሪዎች እና አባላት (በቴሌግራም @attendanceforchurchbot)፦**
   * `/start` – ዋና ሜኑ
   * `/schedule` ወይም `/program` – መርሐ ግብር በክፍል ደረጃ (ቅድመ አንደኛ፣ 1ኛ-2ኛ፣ 3ኛ-5ኛ፣ 6ኛ-9ኛ) እና በቀን (አርብ፣ ቅዳሜ፣ እሁድ)
   * `/card` – ዲጂታል የQR መታወቂያ ካርድ መቀበያ
   * `/myid` – የራስዎን የቴሌግራም User ID ማወቂያ

2. **ለዋና አስተዳዳሪ (Super Admin - 5281238412)፦**
   * በዳሽቦርዱ (`http://127.0.0.1:5001/`) ላይ አዳዲስ ተማሪዎችን አይቶ በእጅ (Manually) Student ID ሰጥቶ ማጽደቅ (Approve)
   * ለረዳት አስተዳዳሪዎች (Sub-Admins) የፈቃድ ቁጥጥር መስጠት
   * የተገኝነት ሰዓት (Sunday 08:00 - 12:00) ሪፖርት ማየትና ማውረድ
