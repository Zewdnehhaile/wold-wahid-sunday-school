@echo off
chcp 65001 > nul
cd /d "%~dp0"
title Wold Wahid Sunday School Bot and Dashboard
set PYCMD=python
%PYCMD% --version >nul 2>&1
if errorlevel 1 set PYCMD=py
%PYCMD% --version >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.11+ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".env" (
  echo Missing python_backend\.env
  echo Copy .env.example to .env and fill in the private settings first.
  pause
  exit /b 1
)
echo Installing dependencies...
%PYCMD% -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed.
  pause
  exit /b 1
)
echo Starting Admin Dashboard at http://127.0.0.1:5001/
start "FithaPol Admin Dashboard" cmd /k "cd /d "%~dp0" ^&^& %PYCMD% admin_dashboard.py"
echo Starting Telegram bot. Do not share the .env file.
%PYCMD% bot.py
echo Bot stopped.
pause
