"""
FithaPol Sunday School Admin Dashboard (Flask Service)
Running on port 5001 as configured in .env (ADMIN_DASHBOARD_URL=http://127.0.0.1:5001/)
"""
import os
import sqlite3
import datetime
import secrets
import hmac
import io
import json
import urllib.request
import urllib.error
from zoneinfo import ZoneInfo
from flask import send_file
from flask import Flask, render_template_string, request, redirect, url_for, session, jsonify, flash
from config import (
    DATABASE_PATH,
    BOT_TOKEN,
    SECRET_KEY,
    ADMIN_DASHBOARD_USERNAME,
    ADMIN_DASHBOARD_PASSWORD,
    SCHOOL_NAME,
    SCHOOL_NAME_AM,
    ATTENDANCE_DAY,
    ATTENDANCE_OPEN_TIME,
    ATTENDANCE_CLOSE_TIME,
    SUPER_ADMIN_ID,
    PORT,
    TIMEZONE,
    validate_runtime_config,
)
from database import get_connection, init_db

app = Flask(__name__)
app.secret_key = SECRET_KEY or os.urandom(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

@app.before_request
def protect_mutations():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.endpoint != "login":
        if not is_authenticated():
            return jsonify({"error": "Authentication required"}), 401
        token = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token")
        if not token or not hmac.compare_digest(str(token), str(session.get("csrf_token", ""))):
            return jsonify({"error": "Invalid CSRF token"}), 403


# HTML Templates with Tailwind CSS
LOGIN_HTML = """
<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ግባ | {{ school_name_am }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl shadow-amber-500/5">
        <div class="text-center mb-8">
            <div class="inline-flex p-3 rounded-2xl bg-amber-500/10 text-amber-400 mb-3 text-3xl">⛪</div>
            <h1 class="text-2xl font-bold tracking-tight text-white">{{ school_name_am }}</h1>
            <p class="text-xs text-amber-400/90 font-medium mt-1">የአስተዳዳሪ መግቢያ (Admin Dashboard)</p>
        </div>

        {% if error %}
        <div class="bg-red-500/10 border border-red-500/30 text-red-400 text-sm rounded-lg p-3 mb-6 text-center">
            {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/login" class="space-y-4">
            <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">የተጠቃሚ ስም (Username)</label>
                <input type="text" name="username" required value="admin"
                    class="w-full px-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500">
            </div>

            <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">የይለፍ ቃል (Password)</label>
                <input type="password" name="password" required
                    placeholder="••••••••"
                    class="w-full px-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500">
            </div>

            <button type="submit"
                class="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-amber-500/20 mt-2">
                መግቢያ (Sign In)
            </button>
        </form>

        <div class="mt-6 pt-4 border-t border-slate-800 text-center text-xs text-slate-500">
            <p>መደበኛ የተጠቃሚ ስም: <code class="text-amber-300">admin</code></p>
            <p class="mt-1">Dashboard URL: <code class="text-slate-400">http://127.0.0.1:5001/</code></p>
        </div>
    </div>
</body>
</html>
"""

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>አስተዳዳሪ ሰሌዳ | {{ school_name_am }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen">
    <!-- Navbar -->
    <header class="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <span class="text-2xl">⛪</span>
                <div>
                    <h1 class="font-bold text-white text-base leading-none">{{ school_name_am }}</h1>
                    <p class="text-xs text-amber-400 font-mono mt-0.5">Admin Security Dashboard</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                    Super Admin: {{ super_admin_id }}
                </span>
                <a href="/logout" class="text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition">
                    ውጣ (Logout)
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <section class="rounded-xl border border-indigo-500/30 bg-slate-900 p-4">
          <div class="flex items-center justify-between gap-4 flex-wrap">
            <h2 class="font-bold">🔔 የድጋፍ ጥያቄዎች (Support) <span id="supportCount" class="text-amber-400">{{ new_support_count }}</span></h2>
            <button type="button" onclick="loadSupport()" class="bg-indigo-700 px-4 py-2 rounded">አድስ / Refresh</button>
          </div>
          <div id="supportList" class="mt-3 text-sm space-y-2">እየተጫነ ነው...</div>
        </section>
        <section class="rounded-xl border border-slate-700 bg-slate-900 p-4">
          <h2 class="font-bold mb-2">🔎 የAttendance ፍለጋ እና ሪፖርት</h2>
          <form action="/api/attendance/report/xlsx" method="GET" class="flex flex-wrap gap-2 items-center">
            <label>ከ <input type="date" name="from" id="dateFrom" class="text-black rounded p-2"></label>
            <label>እስከ <input type="date" name="to" id="dateTo" class="text-black rounded p-2"></label>
            <button class="bg-emerald-700 rounded px-3 py-2" type="submit">⬇ Excel</button>
            <button class="bg-rose-700 rounded px-3 py-2" type="submit" formaction="/api/attendance/report/pdf">⬇ PDF</button>
            <button class="bg-sky-700 rounded px-3 py-2" type="button" onclick="searchAttendance()">ፈልግ</button>
          </form>
          <div id="attendanceResults" class="mt-3 overflow-x-auto text-sm"></div>
        </section>
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, msg in messages %}
                <div class="p-4 rounded-xl text-sm font-medium {% if category == 'success' %}bg-emerald-500/10 border border-emerald-500/30 text-emerald-300{% else %}bg-red-500/10 border border-red-500/30 text-red-300{% endif %}">
                    {{ msg }}
                </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        <!-- Stat Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5">
                <p class="text-xs text-slate-400 uppercase font-semibold">አጠቃላይ ተማሪዎች</p>
                <p class="text-3xl font-bold text-white mt-2">{{ total_members }}</p>
                <p class="text-xs text-emerald-400 mt-1">በሲስተሙ የተመዘገቡ</p>
            </div>
            <div class="bg-slate-900 border border-amber-500/30 rounded-xl p-5 bg-amber-500/5">
                <p class="text-xs text-amber-400 uppercase font-semibold">ማጽደቅ የሚጠብቁ (Pending)</p>
                <p class="text-3xl font-bold text-amber-300 mt-2">{{ pending_count }}</p>
                <p class="text-xs text-slate-400 mt-1">መታወቂያ (ID) ያልተሰጣቸው</p>
            </div>
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5">
                <p class="text-xs text-slate-400 uppercase font-semibold">የዛሬ የተገኙ (Attendance)</p>
                <p class="text-3xl font-bold text-emerald-400 mt-2">{{ attendance_today }}</p>
                <p class="text-xs text-slate-400 mt-1">የስካን ሰዓት: {{ attendance_open }} - {{ attendance_close }}</p>
            </div>
            <div class="bg-slate-900 border border-purple-500/30 rounded-xl p-5 bg-purple-500/5">
                <p class="text-xs text-purple-400 uppercase font-semibold">የፈቃድ ጥያቄዎች (Leaves)</p>
                <p class="text-3xl font-bold text-purple-300 mt-2">{{ pending_leaves_count }}</p>
                <p class="text-xs text-slate-400 mt-1">ማጽደቅ የሚጠብቁ</p>
            </div>
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5">
                <p class="text-xs text-slate-400 uppercase font-semibold">አስተዳዳሪዎች (Admins)</p>
                <p class="text-3xl font-bold text-cyan-400 mt-2">{{ admin_count }}</p>
                <p class="text-xs text-slate-400 mt-1">ፈቃድ የተሰጣቸው ረዳቶች</p>
            </div>
        </div>

        <!-- Section 1: Pending Approvals (Manual Student ID assignment requested by user) -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div class="p-6 border-b border-slate-800 flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-white flex items-center gap-2">
                        <span class="w-3 h-3 rounded-full bg-amber-500 animate-pulse"></span>
                        ተማሪዎችን ማጽደቅና Student ID መመደብ (Pending Approvals)
                    </h2>
                    <p class="text-xs text-slate-400 mt-0.5">አዳዲስ የተመዘገቡ ተማሪዎችን እዚህ በእጅ (Manually) Student ID ሰጥተው ያጽድቁ።</p>
                </div>
                <span class="px-3 py-1 bg-amber-500/10 text-amber-400 rounded-lg text-xs font-bold border border-amber-500/20">
                    {{ pending_count }} ጥያቄዎች
                </span>
            </div>

            {% if pending_members %}
            <div class="divide-y divide-slate-800">
                {% for m in pending_members %}
                <div class="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-800/40 transition">
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="font-bold text-white text-base">{{ m.full_name_am }}</h3>
                            <span class="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">{{ m.phone }}</span>
                            <span class="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-300">{{ m.grade_level or 'ያልተገለጸ' }}</span>
                        </div>
                        <p class="text-xs text-slate-400 mt-1">የምዝገባ ቀን: {{ m.created_at }}</p>
                    </div>

                    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <form method="POST" action="/approve_student" class="flex flex-wrap items-center gap-2">
                        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
                        <input type="hidden" name="member_id" value="{{ m.id }}">
                        <input type="text" name="student_id" placeholder="Student ID (e.g. WW-2026-{{ '%03d' % m.id }})" required
                            value="" maxlength="60"
                            class="px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs font-mono text-amber-300 focus:outline-none focus:border-amber-500 w-44">
                        <button type="submit" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition">
                            ✓ አጽድቅ (Approve)
                        </button>
                      </form>
                      <form method="POST" action="/reject_student" class="flex flex-wrap items-center gap-2" onsubmit="return confirm('ይህን የተማሪ ምዝገባ ጥያቄ ውድቅ ማድረግ ይፈልጋሉ?');">
                        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
                        <input type="hidden" name="member_id" value="{{ m.id }}">
                        <input type="text" name="reason" maxlength="300" placeholder="የውድቅ ምክንያት (አማራጭ)" class="px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 w-44">
                        <button type="submit" class="px-4 py-2 bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold rounded-lg transition">
                            ✕ ውድቅ አድርግ (Reject)
                        </button>
                      </form>
                    </div>
                </div>
                {% endfor %}
            </div>
            {% else %}
            <div class="p-8 text-center text-slate-500 text-sm">
                🎉 በአሁኑ ሰዓት ማጽደቅ የሚጠብቅ አዲስ ተማሪ የለም። ሁሉም ተማሪዎች ጸድቀዋል!
            </div>
            {% endif %}
        </div>

        <!-- Section 1.5: Leave Requests (የተማሪዎች ፈቃድ መጠየቂያዎች) -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div class="p-6 border-b border-slate-800 flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-white flex items-center gap-2">
                        <span>📝</span>
                        የተማሪዎች ፈቃድ መጠየቂያዎች (Leave Requests / Excuses)
                    </h2>
                    <p class="text-xs text-slate-400 mt-0.5">በቦቱ Support Center በኩል በተማሪዎች የተላኩ የፈቃድ ጥያቄዎች</p>
                </div>
                <span class="px-3 py-1 bg-purple-500/10 text-purple-400 rounded-lg text-xs font-bold border border-purple-500/20">
                    {{ pending_leaves_count }} አዳዲስ ፈቃዶች
                </span>
            </div>

            {% if leave_requests %}
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-950/60 text-slate-400 uppercase font-mono border-b border-slate-800">
                        <tr>
                            <th class="p-4">መለያ ቁጥር</th>
                            <th class="p-4">የተማሪ ስም</th>
                            <th class="p-4">የፈቃድ አይነት</th>
                            <th class="p-4">የፈቃድ ቆይታ</th>
                            <th class="p-4">ምክንያት (Reason)</th>
                            <th class="p-4">ሁኔታ</th>
                            <th class="p-4 text-right">ውሳኔ (Action)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800 text-slate-300">
                        {% for l in leave_requests %}
                        <tr class="hover:bg-slate-800/30">
                            <td class="p-4 font-mono font-bold text-purple-400">{{ l.request_number }}</td>
                            <td class="p-4 font-medium text-white">{{ l.student_name }} <span class="text-slate-500 font-mono text-[10px]">({{ l.student_code or '-' }})</span></td>
                            <td class="p-4 font-semibold text-amber-300">{{ l.leave_type }}</td>
                            <td class="p-4">{{ l.duration }}</td>
                            <td class="p-4 max-w-xs truncate text-slate-300" title="{{ l.reason }}">{{ l.reason or '-' }}</td>
                            <td class="p-4">
                                {% if l.status == 'approved' %}
                                <span class="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                                    Approved
                                </span>
                                {% elif l.status == 'rejected' %}
                                <span class="px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 font-bold">
                                    Rejected
                                </span>
                                {% else %}
                                <span class="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold animate-pulse">
                                    Pending
                                </span>
                                {% endif %}
                            </td>
                            <td class="p-4 text-right">
                                {% if l.status == 'pending' %}
                                <div class="inline-flex gap-1.5 justify-end">
                                    <form method="POST" action="/approve_leave/{{ l.id }}" class="inline"><input type="hidden" name="csrf_token" value="{{ csrf_token }}">
                                        <button type="submit" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold">
                                            ✓ አጽድቅ
                                        </button>
                                    </form>
                                    <form method="POST" action="/reject_leave/{{ l.id }}" class="inline"><input type="hidden" name="csrf_token" value="{{ csrf_token }}">
                                        <button type="submit" class="px-2.5 py-1 bg-red-600/80 hover:bg-red-500 text-white rounded text-[11px] font-bold">
                                            ✕ ውድቅ
                                        </button>
                                    </form>
                                </div>
                                {% else %}
                                <span class="text-slate-500 text-[10px]">ተጠናቋል</span>
                                {% endif %}
                            </td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
            {% else %}
            <div class="p-8 text-center text-slate-500 text-sm">
                🎉 እስካሁን የቀረበ የፈቃድ መጠየቂያ ማመልከቻ የለም።
            </div>
            {% endif %}
        </div>


        <!-- Section 2: Active Students & Members List -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div class="p-6 border-b border-slate-800 flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-white">የተማሪዎች እና አባላት ዝርዝር (Approved Members)</h2>
                    <p class="text-xs text-slate-400 mt-0.5">Student ID የተሰጣቸው እና ዲጂታል QR ካርድ ያላቸው</p>
                </div>
                <div class="text-xs text-slate-400 font-mono">መደበኛ የሰንበት መግቢያ፡ {{ attendance_day }} ({{ attendance_open }} - {{ attendance_close }})</div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-950/60 text-slate-400 uppercase font-mono border-b border-slate-800">
                        <tr>
                            <th class="p-4">Student ID</th>
                            <th class="p-4">ሙሉ ስም</th>
                            <th class="p-4">ስልክ</th>
                            <th class="p-4">የክፍል ደረጃ</th>
                            <th class="p-4">ኃላፊነት ክፍል</th>
                            <th class="p-4">ሁኔታ</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800 text-slate-300">
                        {% for m in approved_members %}
                        <tr class="hover:bg-slate-800/30">
                            <td class="p-4 font-mono font-bold text-amber-400">{{ m.code }}</td>
                            <td class="p-4 font-medium text-white">{{ m.full_name_am }}</td>
                            <td class="p-4 font-mono text-slate-400">{{ m.phone }}</td>
                            <td class="p-4">{{ m.grade_level or '-' }}</td>
                            <td class="p-4">{{ m.department or '-' }}</td>
                            <td class="p-4">
                                <span class="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                                    Approved
                                </span>
                            </td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Section 3: Super Admin & Sub-Admins Management -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                    <h2 class="text-lg font-bold text-white">🔐 ረዳት አስተዳዳሪዎችና የፈቃድ ቁጥጥር (Admins & Permissions)</h2>
                    <p class="text-xs text-slate-400 mt-0.5">ዋና አስተዳዳሪ (Super Admin) የቴሌግራም መለያ ቁጥር (Telegram ID) በማስገባት ለረዳት አስተዳዳሪዎች ፈቃድ ይሰጣል</p>
                </div>
            </div>

            <!-- Add Sub-Admin Form -->
            <form method="POST" action="/add_admin" class="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800 mb-6"><input type="hidden" name="csrf_token" value="{{ csrf_token }}">
                <div>
                    <label class="block text-xs text-slate-400 mb-1">Telegram User ID</label>
                    <input type="number" name="telegram_id" placeholder="उदा: 5281238412" required
                        class="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white">
                </div>
                <div>
                    <label class="block text-xs text-slate-400 mb-1">ሙሉ ስም</label>
                    <input type="text" name="full_name" placeholder="የአስተዳዳሪው ስም" required
                        class="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white">
                </div>
                <div>
                    <label class="block text-xs text-slate-400 mb-1">ስልክ ቁጥር</label>
                    <input type="text" name="phone" placeholder="+251..."
                        class="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white">
                </div>
                <div class="flex items-end">
                    <button type="submit" class="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition">
                        + አስተዳዳሪ መዝግብ
                    </button>
                </div>
            </form>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-950/60 text-slate-400 uppercase font-mono border-b border-slate-800">
                        <tr>
                            <th class="p-3">Telegram ID</th>
                            <th class="p-3">ስም</th>
                            <th class="p-3">ሚና (Role)</th>
                            <th class="p-3 text-center">ተማሪ ማጽደቅ</th>
                            <th class="p-3 text-center">QR መመዝገብ</th>
                            <th class="p-3 text-center">ድጋፍ ማስተናገድ</th>
                            <th class="p-3 text-center">Excel ሪፖርት</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800">
                        {% for a in admins %}
                        <tr class="hover:bg-slate-800/30">
                            <td class="p-3 font-mono text-amber-400 font-bold">{{ a.telegram_id }}</td>
                            <td class="p-3 font-medium text-white">{{ a.full_name }}</td>
                            <td class="p-3">
                                {% if a.role == 'super_admin' %}
                                <span class="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">👑 Super Admin</span>
                                {% else %}
                                <span class="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold">Sub-Admin</span>
                                {% endif %}
                            </td>
                            <td class="p-3 text-center font-bold {% if a.can_approve_students %}text-emerald-400{% else %}text-slate-600{% endif %}">
                                {{ '✓' if a.can_approve_students else '✕' }}
                            </td>
                            <td class="p-3 text-center font-bold {% if a.can_take_attendance %}text-emerald-400{% else %}text-slate-600{% endif %}">
                                {{ '✓' if a.can_take_attendance else '✕' }}
                            </td>
                            <td class="p-3 text-center font-bold {% if a.can_manage_support %}text-emerald-400{% else %}text-slate-600{% endif %}">
                                {{ '✓' if a.can_manage_support else '✕' }}
                            </td>
                            <td class="p-3 text-center font-bold {% if a.can_export_reports %}text-emerald-400{% else %}text-slate-600{% endif %}">
                                {{ '✓' if a.can_export_reports else '✕' }}
                            </td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <script>
    const csrfToken = {{ csrf_token|tojson }};
    async function loadSupport() {
      const el=document.getElementById('supportList');
      try {
        const r=await fetch('/api/support'); if(!r.ok)throw Error('Request failed');
        const tickets=await r.json();document.getElementById('supportCount').textContent=tickets.filter(t=>t.status==='new').length;
        el.replaceChildren();
        for(const t of tickets){
          const line=document.createElement('div');line.className='p-2 border-b border-slate-700 flex flex-wrap gap-2';
          const label=document.createElement('span');label.className='flex-1';label.textContent=`${t.ticket_number} ${t.requester_name}: ${t.description||t.title} (${t.status})`;line.append(label);
          for(const status of ['in_progress','resolved','rejected']){
            const btn=document.createElement('button');btn.className='bg-indigo-700 rounded px-2 py-1';btn.textContent=status;
            btn.onclick=async()=>{const response=await fetch(`/api/support/${t.id}/status`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrfToken},body:JSON.stringify({status})});if(response.ok)loadSupport();else alert('Unable to update');};line.append(btn);
          }el.append(line);
        }if(!tickets.length)el.textContent='ምንም የድጋፍ ጥያቄ የለም።';
      }catch(e){el.textContent='የSupport መረጃ አልተገኘም';}
    }
    async function searchAttendance(){
      const qs=new URLSearchParams({from:document.getElementById('dateFrom').value,to:document.getElementById('dateTo').value});
      const r=await fetch('/api/attendance/search?'+qs);const el=document.getElementById('attendanceResults');el.replaceChildren();
      if(!r.ok){el.textContent='ፍለጋ አልተሳካም';return;}
      const rows=await r.json();for(const row of rows){const line=document.createElement('div');line.className='border-b border-slate-700 p-2';line.textContent=`${row.date} ${row.time} — ${row.code||''} ${row.full_name_am||''} — ${row.session_name}`;el.append(line);}
      if(!rows.length)el.textContent='ምንም መዝገብ የለም';
    }
    loadSupport();setInterval(loadSupport,30000);
    </script>
</body>
</html>
"""

def is_authenticated():
    return session.get("logged_in") is True

@app.route("/")
def index():
    if not is_authenticated():
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM bot_admins ORDER BY full_name")
    admins = [dict(r) for r in cursor.fetchall()]
    admin_count = len(admins)

    # Total members
    cursor.execute("SELECT COUNT(*) FROM members WHERE status = 'approved'")
    total_members = cursor.fetchone()[0]

    # Pending members
    cursor.execute("SELECT * FROM members WHERE status = 'pending' ORDER BY id DESC")
    pending_members = [dict(r) for r in cursor.fetchall()]
    pending_count = len(pending_members)

    # Approved members
    cursor.execute("SELECT * FROM members WHERE status = 'approved' ORDER BY id DESC")
    approved_members = [dict(r) for r in cursor.fetchall()]

    # Today attendance
    today_str = datetime.datetime.now(ZoneInfo(TIMEZONE)).date().isoformat()
    cursor.execute("SELECT COUNT(*) FROM attendance WHERE date = ?", (today_str,))
    attendance_today = cursor.fetchone()[0]

    # Leave requests
    cursor.execute("SELECT * FROM leave_requests ORDER BY id DESC")
    leave_requests = [dict(r) for r in cursor.fetchall()]
    pending_leaves = [l for l in leave_requests if l["status"] == "pending"]
    pending_leaves_count = len(pending_leaves)

    cursor.execute("SELECT COUNT(*) FROM support_tickets WHERE status='new'")
    new_support_count=cursor.fetchone()[0]
    conn.close()

    return render_template_string(
        DASHBOARD_HTML,
        school_name_am=SCHOOL_NAME_AM,
        super_admin_id=SUPER_ADMIN_ID,
        csrf_token=session.get("csrf_token"),
        total_members=total_members,
        pending_count=pending_count,
        pending_members=pending_members,
        approved_members=approved_members,
        attendance_today=attendance_today,
        admins=admins,
        admin_count=admin_count,
        new_support_count=new_support_count,
        leave_requests=leave_requests,
        pending_leaves_count=pending_leaves_count,
        attendance_day=ATTENDANCE_DAY,
        attendance_open=ATTENDANCE_OPEN_TIME,
        attendance_close=ATTENDANCE_CLOSE_TIME,
    )

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if username == ADMIN_DASHBOARD_USERNAME and password == ADMIN_DASHBOARD_PASSWORD:
            session.clear()
            session["csrf_token"] = secrets.token_urlsafe(32)
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("index"))
        else:
            error = "የተሳሳተ የተጠቃሚ ስም ወይም የይለፍ ቃል (Invalid credentials)!"

    return render_template_string(LOGIN_HTML, school_name_am=SCHOOL_NAME_AM, error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

def notify_student(telegram_id, message):
    """Send a best-effort Telegram notification without exposing the bot token."""
    if not BOT_TOKEN or not telegram_id:
        return False
    payload = json.dumps({"chat_id": int(telegram_id), "text": message}).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            result = json.loads(response.read().decode("utf-8"))
            return bool(result.get("ok"))
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as exc:
        print(f"Telegram student notification failed: {type(exc).__name__}")
        return False


@app.route("/approve_student", methods=["POST"])
def approve_student():
    if not is_authenticated():
        return redirect(url_for("login"))

    member_id = request.form.get("member_id", "").strip()
    student_id = request.form.get("student_id", "").strip()
    if not member_id.isdigit() or not student_id or len(student_id) > 60:
        flash("እባክዎ ትክክለኛ Student ID ያስገቡ!", "error")
        return redirect(url_for("index"))

    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT full_name_am, telegram_id, status FROM members WHERE id = ?", (member_id,))
        member = cursor.fetchone()
        if not member or member["status"] != "pending":
            flash("ይህ ተማሪ አልተገኘም ወይም ቀድሞ ተወስኗል።", "error")
            return redirect(url_for("index"))
        cursor.execute(
            "UPDATE members SET code = ?, status = 'approved', approved_by = ? WHERE id = ? AND status = 'pending'",
            (student_id, SUPER_ADMIN_ID, member_id),
        )
        if cursor.rowcount != 1:
            conn.rollback()
            flash("ማጽደቁ አልተሳካም፤ ገጹን አድስና እንደገና ይሞክሩ።", "error")
            return redirect(url_for("index"))
        conn.commit()
        full_name, telegram_id = member["full_name_am"], member["telegram_id"]
    except sqlite3.IntegrityError:
        conn.rollback()
        flash(f"ስህተት፡ Student ID {student_id} ቀደም ሲል ለሌላ ተማሪ ተሰጥቷል!", "error")
        return redirect(url_for("index"))
    finally:
        conn.close()

    delivered = notify_student(
        telegram_id,
        f"🎉 ሰላም {full_name}! የሰንበት ት/ቤት ምዝገባዎ ጸድቋል።\n\n🆔 Student ID: {student_id}\nአሁን የተማሪ አባል ሆነዋል።",
    )
    flash(
        f"ተማሪው ጸድቋል። Student ID: {student_id}" + (" ማሳወቂያውም ተልኳል።" if delivered else " ማሳወቂያው ግን አልተላከም (Telegram ላይ /start እንዲል ያረጋግጡ)."),
        "success" if delivered else "error",
    )
    return redirect(url_for("index"))


@app.route("/reject_student", methods=["POST"])
def reject_student():
    if not is_authenticated():
        return redirect(url_for("login"))

    member_id = request.form.get("member_id", "").strip()
    reason = request.form.get("reason", "").strip()[:300]
    if not member_id.isdigit():
        flash("የተማሪ መለያ ትክክል አይደለም።", "error")
        return redirect(url_for("index"))

    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT full_name_am, telegram_id, status FROM members WHERE id = ?", (member_id,))
        member = cursor.fetchone()
        if not member or member["status"] != "pending":
            flash("ይህ ተማሪ አልተገኘም ወይም ቀድሞ ተወስኗል።", "error")
            return redirect(url_for("index"))
        cursor.execute("UPDATE members SET status = 'rejected' WHERE id = ? AND status = 'pending'", (member_id,))
        if cursor.rowcount != 1:
            conn.rollback()
            flash("ውድቅ ማድረጉ አልተሳካም፤ ገጹን አድስና እንደገና ይሞክሩ።", "error")
            return redirect(url_for("index"))
        conn.commit()
        full_name, telegram_id = member["full_name_am"], member["telegram_id"]
    finally:
        conn.close()

    message = f"ሰላም {full_name}! የሰንበት ት/ቤት የምዝገባ ጥያቄዎ በአሁኑ ጊዜ አልጸደቀም።"
    if reason:
        message += f"\n\nምክንያት: {reason}"
    message += "\n\nተጨማሪ መረጃ ካስፈለገ እባክዎ አስተዳዳሪውን ያነጋግሩ።"
    delivered = notify_student(telegram_id, message)
    flash("የተማሪው ጥያቄ ውድቅ ተደርጓል." + (" ማሳወቂያ ተልኳል።" if delivered else " Telegram ማሳወቂያ ግን አልተላከም።"), "success" if delivered else "error")
    return redirect(url_for("index"))

@app.route("/add_admin", methods=["POST"])
def add_admin():
    if not is_authenticated():
        return redirect(url_for("login"))

    telegram_id = request.form.get("telegram_id")
    full_name = request.form.get("full_name", "").strip()
    phone = request.form.get("phone", "").strip()

    if not telegram_id or not telegram_id.isdigit() or int(telegram_id) <= 0 or not full_name:
        flash("Telegram User ID እና ሙሉ ስም ማስገባት ግዴታ ነው!", "error")
        return redirect(url_for("index"))

    if int(telegram_id) == SUPER_ADMIN_ID:
        flash("Super Admin cannot be edited through this form", "error")
        return redirect(url_for("index"))
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
        INSERT INTO bot_admins (telegram_id, full_name, phone, role, can_approve_students, can_take_attendance, can_manage_support, can_export_reports)
        VALUES (?, ?, ?, 'sub_admin', 1, 1, 1, 0)
        ON CONFLICT(telegram_id) DO UPDATE SET full_name=excluded.full_name, phone=excluded.phone
        """, (int(telegram_id), full_name, phone))
        conn.commit()
        flash(f"አስተዳዳሪ {full_name} ({telegram_id}) በተሳካ ሁኔታ ተመድቧል!", "success")
    except Exception as e:
        flash(f"ስህተት፡ {str(e)}", "error")
    finally:
        conn.close()

    return redirect(url_for("index"))

@app.route("/approve_leave/<int:leave_id>", methods=["POST"])
def approve_leave(leave_id):
    if not is_authenticated():
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE leave_requests SET status = 'approved', approved_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?",
            (SUPER_ADMIN_ID, leave_id)
        )
        conn.commit()
        flash("የተማሪው የፈቃድ ጥያቄ በተሳካ ሁኔታ ጸድቋል!", "success")
    except Exception as e:
        flash(f"ስህተት፡ {str(e)}", "error")
    finally:
        conn.close()

    return redirect(url_for("index"))

@app.route("/reject_leave/<int:leave_id>", methods=["POST"])
def reject_leave(leave_id):
    if not is_authenticated():
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE leave_requests SET status = 'rejected', approved_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?",
            (SUPER_ADMIN_ID, leave_id)
        )
        conn.commit()
        flash("የተማሪው የፈቃድ ጥያቄ ውድቅ ተደርጓል!", "warning")
    except Exception as e:
        flash(f"ስህተት፡ {str(e)}", "error")
    finally:
        conn.close()

    return redirect(url_for("index"))

# API endpoints
@app.route("/api/members", methods=["GET"])
def api_members():
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, code, full_name_am, full_name_en, gender, grade_level, department, status, created_at FROM members ORDER BY id DESC")
    rows = [dict(ix) for ix in cursor.fetchall()]
    conn.close()
    return jsonify(rows)

@app.route("/api/attendance/checkin", methods=["POST"])
def api_checkin():
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401
    data = request.get_json(silent=True) or {}
    code = str(data.get("code") or "").strip()
    if not code:
        return jsonify({"error": "Member code required"}), 400
    session_name = str(data.get("session_name") or "Sunday Service").strip()[:100]
    now = datetime.datetime.now(ZoneInfo(TIMEZONE))
    date = now.date().isoformat()
    time = now.strftime("%H:%M")
    if now.strftime("%A") != ATTENDANCE_DAY or not (ATTENDANCE_OPEN_TIME <= time <= ATTENDANCE_CLOSE_TIME):
        return jsonify({"error": "Attendance is closed outside configured hours"}), 403

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, full_name_am, status FROM members WHERE code = ?", (code,))
    member = cursor.fetchone()

    if not member:
        conn.close()
        return jsonify({"error": "Member not found"}), 404

    if member["status"] != "approved":
        conn.close()
        return jsonify({"error": "Member is not yet approved by admin"}), 403

    cursor.execute("SELECT id FROM attendance WHERE member_id = ? AND date = ? LIMIT 1", (member["id"], date))
    if cursor.fetchone():
        conn.close()
        return jsonify({"error": "Attendance already recorded for this date"}), 409

    cursor.execute(
        "INSERT INTO attendance (member_id, session_name, date, time, method) VALUES (?, ?, ?, ?, ?)",
        (member["id"], session_name, date, time, "qr")
    )
    conn.commit()
    conn.close()
    return jsonify({"success": True, "name": member["full_name_am"]})



def _valid_dates():
    start,end=request.args.get("from",""),request.args.get("to","")
    for d in (start,end):
        if d: datetime.date.fromisoformat(d)
    if start and end and start>end: raise ValueError("Invalid date range")
    return start,end

@app.route("/api/attendance/search")
def attendance_search():
    if not is_authenticated(): return jsonify({"error":"Authentication required"}),401
    try: start,end=_valid_dates()
    except ValueError: return jsonify({"error":"Invalid date range"}),400
    query=request.args.get("q","").strip()[:100]
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT a.id,a.date,a.time,a.session_name,a.method,m.code,m.full_name_am
            FROM attendance a LEFT JOIN members m ON a.member_id=m.id
            WHERE (?='' OR a.date>=?) AND (?='' OR a.date<=?)
            AND (?='' OR m.code LIKE ? OR m.full_name_am LIKE ?)
            ORDER BY a.date DESC,a.time DESC LIMIT 500""",
            (start,start,end,end,query,'%'+query+'%','%'+query+'%')).fetchall()
        return jsonify([dict(r) for r in rows])
    finally: conn.close()

@app.route("/api/support")
def support_list():
    if not is_authenticated(): return jsonify({"error":"Authentication required"}),401
    conn=get_connection()
    try:
        return jsonify([dict(r) for r in conn.execute("""SELECT id,ticket_number,requester_name,category,title,description,status,created_at
            FROM support_tickets ORDER BY id DESC LIMIT 200""")])
    finally: conn.close()

@app.route("/api/support/<int:ticket_id>/status",methods=["POST"])
def support_status(ticket_id):
    if not is_authenticated(): return jsonify({"error":"Authentication required"}),401
    data=request.get_json(silent=True) or {}
    status=data.get('status')
    if status not in ('new','in_progress','resolved','rejected'):
        return jsonify({'error':'Invalid status'}),400
    conn=get_connection()
    try:
        result=conn.execute("UPDATE support_tickets SET status=? WHERE id=?",(status,ticket_id))
        conn.commit()
        return (jsonify({'success':True}) if result.rowcount else (jsonify({'error':'Not found'}),404))
    finally: conn.close()

@app.route("/api/attendance/report/<format_name>")
def attendance_report(format_name):
    if not is_authenticated():
        return jsonify({"error": "Authentication required"}), 401
    if format_name not in ("xlsx", "pdf"):
        return jsonify({"error": "Unsupported format"}), 400
    start, end = request.args.get("from", ""), request.args.get("to", "")
    try:
        for d in (start, end):
            if d: datetime.date.fromisoformat(d)
    except ValueError:
        return jsonify({"error": "Invalid date format"}), 400
    conn = get_connection()
    try:
        records = [list(r) for r in conn.execute("""
            SELECT a.date,a.time,m.code,m.full_name_am,a.session_name,a.method
            FROM attendance a LEFT JOIN members m ON m.id=a.member_id
            WHERE (?='' OR a.date>=?) AND (?='' OR a.date<=?)
            ORDER BY a.date DESC,a.time DESC
        """,(start,start,end,end))]
    finally:
        conn.close()
    headers = ["Date","Time","Member ID","Student Name","Session","Method"]
    output = io.BytesIO()
    if format_name == "xlsx":
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb=Workbook(); ws=wb.active; ws.title="Attendance"; ws.append(headers)
        for row in records: ws.append(row)
        for cell in ws[1]: cell.font=Font(bold=True)
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        for col,width in {"A":16,"B":12,"C":18,"D":35,"E":28,"F":16}.items():
            ws.column_dimensions[col].width=width
        wb.save(output)
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.pagesizes import A4,landscape
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from xml.sax.saxutils import escape
        font="Helvetica"
        for path in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "C:/Windows/Fonts/arial.ttf"):
            if os.path.exists(path):
                pdfmetrics.registerFont(TTFont("AttendanceUnicode",path));font="AttendanceUnicode";break
        style=getSampleStyleSheet()["Normal"];style.fontName=font;style.fontSize=8
        data=[[Paragraph(escape(str(x or "")),style) for x in row] for row in [headers]+records]
        table=Table(data,repeatRows=1,colWidths=[75,55,95,180,110,65])
        table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),0.3,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP")]))
        SimpleDocTemplate(output,pagesize=landscape(A4)).build([table])
        mime="application/pdf"
    output.seek(0)
    return send_file(output,mimetype=mime,as_attachment=True,download_name=f"attendance_report.{format_name}")

if __name__ == "__main__":
    init_db()
    print(f"⛪ FithaPol Admin Dashboard running on http://127.0.0.1:{PORT}/")
    problems = validate_runtime_config(require_dashboard=True)
    if problems:
        for problem in problems:
            print(f"CONFIG ERROR: {problem}")
        raise SystemExit(1)
    print("Dashboard credentials are configured (values hidden).")
    app.run(host="127.0.0.1", port=PORT, debug=False)
