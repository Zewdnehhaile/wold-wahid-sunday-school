#!/usr/bin/env bash
echo "========================================================"
echo " የወልድ ዋሕድ ሰንበት ትምህርት ቤት (ፍትሐፖል)"
echo " Wold Wahid Sunday School Bot & Admin Dashboard"
echo "========================================================"

pip install -r requirements.txt

echo "Starting Admin Dashboard on http://127.0.0.1:5001/ ..."
python admin_dashboard.py &

echo "Starting Telegram Bot @attendanceforchurchbot ..."
python bot.py
