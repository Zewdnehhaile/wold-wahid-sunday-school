import sqlite3
from typing import List, Dict, Any, Optional
from config import DATABASE_PATH, SCHOOL_NAME_AM, SUPER_ADMIN_ID

def get_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Members Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        full_name_am TEXT NOT NULL,
        full_name_en TEXT,
        phone TEXT UNIQUE,
        gender TEXT,
        grade_level TEXT,
        department TEXT,
        role TEXT DEFAULT 'student',
        photo_path TEXT,
        blood_group TEXT,
        subcity TEXT,
        emergency_name TEXT,
        emergency_phone TEXT,
        telegram_id INTEGER,
        telegram_username TEXT,
        status TEXT DEFAULT 'pending', -- 'pending' or 'approved'
        approved_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Attendance Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER,
        session_name TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        method TEXT DEFAULT 'qr',
        is_guest INTEGER DEFAULT 0,
        FOREIGN KEY (member_id) REFERENCES members(id)
    )
    """)

    # Admins & Roles Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bot_admins (
        telegram_id INTEGER PRIMARY KEY,
        full_name TEXT NOT NULL,
        phone TEXT,
        role TEXT NOT NULL DEFAULT 'sub_admin', -- 'super_admin' or 'sub_admin'
        can_approve_students INTEGER DEFAULT 1,
        can_take_attendance INTEGER DEFAULT 1,
        can_manage_support INTEGER DEFAULT 1,
        can_export_reports INTEGER DEFAULT 0,
        added_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Support Tickets Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS support_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_number TEXT UNIQUE NOT NULL,
        member_id INTEGER,
        requester_name TEXT NOT NULL,
        phone TEXT,
        category TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        priority TEXT DEFAULT 'medium',
        status TEXT DEFAULT 'new',
        assigned_to TEXT,
        is_confidential INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (member_id) REFERENCES members(id)
    )
    """)

    # Leave Requests Table (የተማሪዎች ፈቃድ መጠየቂያ)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS leave_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_number TEXT UNIQUE NOT NULL,
        member_id INTEGER,
        student_name TEXT NOT NULL,
        student_code TEXT,
        telegram_id INTEGER,
        leave_type TEXT NOT NULL,
        duration TEXT NOT NULL,
        start_date TEXT,
        reason TEXT,
        status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
        approved_by INTEGER,
        reviewed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (member_id) REFERENCES members(id)
    )
    """)

    # Seed only the configured Super Admin. Never hard-code a Telegram ID.
    if SUPER_ADMIN_ID > 0:
        cursor.execute("""
        INSERT INTO bot_admins (telegram_id, full_name, role, can_approve_students, can_take_attendance, can_manage_support, can_export_reports)
        VALUES (?, 'Super Admin', 'super_admin', 1, 1, 1, 1)
        ON CONFLICT(telegram_id) DO UPDATE SET role='super_admin', can_approve_students=1,
            can_take_attendance=1, can_manage_support=1, can_export_reports=1
        """, (SUPER_ADMIN_ID,))
    # Migrate any previously hard-coded/duplicate Super Admin rows to sub-admin.
    if SUPER_ADMIN_ID > 0:
        cursor.execute("UPDATE bot_admins SET role='sub_admin' WHERE role='super_admin' AND telegram_id != ?", (SUPER_ADMIN_ID,))
    else:
        cursor.execute("UPDATE bot_admins SET role='sub_admin' WHERE role='super_admin'")

    # Never seed production with demonstration student identities.

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database fithapol_sundayschool.db initialized successfully.")
