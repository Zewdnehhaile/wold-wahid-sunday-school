@echo off
chcp 65001 > nul
cd /d "%~dp0"
title Wold Wahid Sunday School Bot
echo ========================================================
echo  የወልድ ዋሕድ ሰንበት ትምህርት ቤት (ፍትሐፖል) የቴሌግራም ቦት
echo ========================================================

set PYCMD=python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    py --version >nul 2>&1
    if %errorlevel% equ 0 (
        set PYCMD=py
    ) else (
        python3 --version >nul 2>&1
        if %errorlevel% equ 0 (
            set PYCMD=python3
        ) else (
            echo ❌ Python አልተገኘም! እባክዎ Python ይጫኑ።
            pause
            exit /b 1
        )
    )
)

echo.
echo 🚀 ቦቱን በማስነሳት ላይ (@attendanceforchurchbot)...
%PYCMD% bot.py
pause
