@echo off
chcp 65001 > nul
cd /d "%~dp0python_backend"
call run_bot.bat
