# የወልድ ዋሕድ ሰንበት ት/ቤት - ሙሉ ሲስተም (Wold Wahid Sunday School Suite)

ይህ ዚፕ (ZIP) ፋይል ሙሉውን የሰንበት ት/ቤቱን የዲጂታል አስተዳደር፣ የቴሌግራም ቦት እና የዌብ ዳሽቦርድ ኮድ የያዘ ነው።

---

## 📂 በዚፕ ፋይሉ ውስጥ ያሉ ክፍሎች፦

1. **`src/` & `index.html`** – ዘመናዊው የReact/TypeScript ዌብ ዳሽቦርድ (Web App):
   - **የክፍሎች መርሐ ግብር (`ScheduleView.tsx`)**፦ በክፍል ደረጃ (ቅድመ አንደኛ፣ 1ኛ–2ኛ፣ 3ኛ–5ኛ፣ 6ኛ–9ኛ) እና በቀናት የተከፋፈለ።
   - **የተማሪዎችና አባላት ማውጫ (`MemberList.tsx`)**፦ አዲስ ተማሪዎች የሚመዘገቡበት፣ አድሚኑ በእጅ Student ID ሰጥቶ የሚያጸድቅበት (Manual ID assignment)።
   - **የመታወቂያ ስቱዲዮ (`IdCardStudio.tsx`)**፦ የሚታተም የQR መታወቂያ ካርድ (A4 በጅምላ ወይም ነጠላ)።
   - **የቀጥታ QR ክትትል ስካነር (`AttendanceScanner.tsx`)**፦ በስልክ ካሜራ ወይም ስካነር ክትትል መመዝገቢያ።
   - **የአድሚኖች አስተዳደር (`AdminManagement.tsx`)**፦ Super Admin ሌሎች ረዳት አድሚኖችን የሚሾምበትና ፈቃድ የሚሰጥበት።
   - **የድጋፍ ሰሌዳ (`SupportDesk.tsx`)**፦ የጸሎት፣ የህመም እና የጉብኝት ጥያቄዎች መከታተያ።
   - **ሪፖርቶች (`AnalyticsView.tsx`)**፦ መረጃዎችን ወደ Excel/CSV ማውረጃ።

2. **`python_backend/`** – የቴሌግራም ቦት እና ዳታቤዝ፦
   - **`bot.py`**፦ የቴሌግራም ቦት (መርሐ ግብር በክፍል ማሳያ፣ ዲጂታል ካርድ፣ የSuper Admin `/myid` መለያ)።
   - **`config.py`**፦ የቴሌግራም ቦት ቶከን እና የSuper Admin መለያ ማስገቢያ።
   - **`database.py`**፦ SQLite ዳታቤዝ እና ግንኙነት።
   - **`requirements.txt`**፦ የፓይተን ጥቅሎች።

---

## 🚀 አሰራርና ማስነሻ መመሪያ (How to Run)

### ፩. የዌብ ዳሽቦርዱን (React Web App) በኮምፒውተርዎ ለማስነሳት፦
```bash
# 1. ኖድ ሞጁሎችን ጫን
npm install

# 2. ፕሮጀክቱን አስነሳ
npm run dev
```
ከዚያ ብሮውዘርዎን ከፍተው `http://localhost:3000` (ወይም በተርሚናሉ የሚሰጥዎትን ፖርት) ይክፈቱ።

---

### ፪. የቴሌግራም ቦቱን (Telegram Bot) ለማስነሳት፦
```bash
# 1. ወደ python_backend አቃፊ ግባ
cd python_backend

# 2. አስፈላጊ ጥቅሎችን ጫን
pip install -r requirements.txt

# 3. በ config.py ውስጥ የቦት ቶከንህን አስገባ
# BOT_TOKEN = "የቴሌግራም_ቦት_ቶከን"
# SUPER_ADMIN_ID = የእርስዎ_ቴሌግራም_ID (በ /myid የሚገኝ)

# 4. ቦቱን አስነሳ
python bot.py
```
አባላት በቴሌግራማቸው `/start` ሲሉ በክፍል ደረጃ መርሐ ግብራቸውን፣ ዲጂታል የQR ካርዳቸውን እና ሌሎችንም ያገኛሉ።
