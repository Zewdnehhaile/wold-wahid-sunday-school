import React, { useState } from 'react';
import { ScheduleItem, DayOfWeek, GradeLevel, Language } from '../types';
import { WOLD_WAHID_SCHEDULE } from '../data/initialData';
import { t } from '../utils/translations';
import {
  Calendar,
  Clock,
  Printer,
  BookOpen,
  Music,
  Palette,
  Shield,
  Scroll,
  ArrowRight,
  Layers,
  GraduationCap,
  Sparkles,
} from 'lucide-react';

interface ScheduleViewProps {
  onSelectSessionForAttendance: (sessionName: string, grade: string) => void;
  lang: Language;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  onSelectSessionForAttendance,
  lang,
}) => {
  const [viewMode, setViewMode] = useState<'by_grade' | 'by_day'>('by_grade');
  const [activeGrade, setActiveGrade] = useState<GradeLevel>('pre_kg');
  const [selectedDay, setSelectedDay] = useState<DayOfWeek | 'all'>('all');

  const dict = t[lang];

  // Grade meta definitions
  const gradeTabs: { id: GradeLevel; titleAm: string; titleEn: string; icon: string; descAm: string }[] = [
    {
      id: 'pre_kg',
      titleAm: 'ቅድመ አንደኛ',
      titleEn: 'Pre-School / KG',
      icon: '🧸',
      descAm: 'የህፃናት ትምህርት፣ ጸሎት፣ መዝሙር፣ አብነትና ኪነ ጥበብ',
    },
    {
      id: 'grade_1_2',
      titleAm: '1ኛ እና 2ኛ ክፍል',
      titleEn: 'Grades 1 & 2',
      icon: '🎒',
      descAm: 'የታዳጊዎች ትምህርት፣ አብነት፣ መዝሙርና ስነ ስርዓት',
    },
    {
      id: 'grade_3_5',
      titleAm: '3ኛ–5ኛ ክፍል',
      titleEn: 'Grades 3–5',
      icon: '📚',
      descAm: 'የቅዳሜና የእሁድ ጥልቅ ትምህርት፣ መዝሙርና አብነት',
    },
    {
      id: 'grade_6_9',
      titleAm: '6ኛ–9ኛ ክፍል',
      titleEn: 'Grades 6–9',
      icon: '🎓',
      descAm: 'የአርብ፣ የቅዳሜና የእሁድ ትምህርት፣ ወረብ፣ አብነትና ኪነ ጥበብ',
    },
  ];

  const getDeptIcon = (deptKey: string) => {
    switch (deptKey) {
      case 'education':
        return <BookOpen className="w-3.5 h-3.5 text-blue-400" />;
      case 'choir':
        return <Music className="w-3.5 h-3.5 text-pink-400" />;
      case 'arts':
        return <Palette className="w-3.5 h-3.5 text-amber-400" />;
      case 'abnet':
        return <Scroll className="w-3.5 h-3.5 text-emerald-400" />;
      case 'discipline':
      default:
        return <Shield className="w-3.5 h-3.5 text-indigo-400" />;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Schedule for currently selected class in 'by_grade' mode
  const currentGradeItems = WOLD_WAHID_SCHEDULE.filter((item) => {
    const matchesGrade = item.gradeLevel === activeGrade;
    const matchesDay = selectedDay === 'all' || item.day === selectedDay;
    return matchesGrade && matchesDay;
  });

  // Group current grade items by day
  const gradeDays = Array.from(new Set(currentGradeItems.map((item) => item.day)));

  const dayLabels: Record<DayOfWeek, string> = {
    friday: '📅 አርብ (Friday)',
    saturday: '📅 ቅዳሜ (Saturday)',
    sunday: '📅 እሁድ (Sunday)',
  };

  return (
    <div className="space-y-6">
      {/* Header and Print action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {dict.schedule.title}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {dict.schedule.subtitle} ·{' '}
            <span className="text-amber-400 font-medium">በክፍል ወይም በቀን የተከፋፈለ ዝርዝር</span>
          </p>
        </div>

        <div className="no-print flex items-center gap-2.5">
          {/* View mode toggle: By Grade vs By Day */}
          <div className="bg-slate-900 border border-slate-800 p-1 rounded-xl flex items-center text-xs">
            <button
              onClick={() => setViewMode('by_grade')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                viewMode === 'by_grade'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🎒 በክፍል ደረጃ እይታ
            </button>
            <button
              onClick={() => setViewMode('by_day')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                viewMode === 'by_day'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              📅 በቀናት እይታ
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span>{dict.schedule.printSchedule}</span>
          </button>
        </div>
      </div>

      {/* MODE 1: BY CLASS / GRADE LEVEL (Primary Mode requested by user) */}
      {viewMode === 'by_grade' ? (
        <div className="space-y-6">
          {/* Class Selectors Grid */}
          <div className="no-print grid grid-cols-2 md:grid-cols-4 gap-3">
            {gradeTabs.map((g) => {
              const count = WOLD_WAHID_SCHEDULE.filter((i) => i.gradeLevel === g.id).length;
              const isSelected = activeGrade === g.id;
              return (
                <button
                  key={g.id}
                  onClick={() => setActiveGrade(g.id)}
                  className={`p-4 rounded-2xl border text-left transition-all duration-200 relative overflow-hidden ${
                    isSelected
                      ? 'bg-slate-900 border-amber-500/80 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500/50'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{g.icon}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-950 text-amber-400 border border-slate-800">
                      {count} ክፍለ-ጊዜ
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                    {g.titleAm}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    {g.descAm}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Active Class Schedule Display */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
            {/* Class Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="text-3xl">
                  {gradeTabs.find((g) => g.id === activeGrade)?.icon}
                </span>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {gradeTabs.find((g) => g.id === activeGrade)?.titleAm} መርሐ ግብር
                  </h3>
                  <p className="text-xs text-slate-400">
                    {gradeTabs.find((g) => g.id === activeGrade)?.descAm}
                  </p>
                </div>
              </div>

              {/* Quick Attendance Check-in for this class */}
              <button
                onClick={() =>
                  onSelectSessionForAttendance(
                    gradeTabs.find((g) => g.id === activeGrade)?.titleAm || '',
                    gradeTabs.find((g) => g.id === activeGrade)?.titleAm || ''
                  )
                }
                className="no-print inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-colors"
              >
                <span>ለዚህ ክፍል የQR ክትትል ጀምር</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Timetable grouped by Day for this Class */}
            {gradeDays.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">ለዚህ ክፍል ምንም የተመዘገበ መርሐ ግብር የለም።</p>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {gradeDays.map((dayKey) => {
                  const periods = currentGradeItems.filter((i) => i.day === dayKey);
                  return (
                    <div
                      key={dayKey}
                      className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                          <span className="text-xs font-bold text-amber-400">
                            {dayLabels[dayKey]}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            {periods.length} ክፍለ-ጊዜ
                          </span>
                        </div>

                        <div className="space-y-2">
                          {periods.map((period) => (
                            <div
                              key={period.id}
                              className="p-3 rounded-lg bg-slate-900/90 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
                            >
                              <div>
                                <span className="font-semibold text-slate-100 block">
                                  {period.activity}
                                </span>
                                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1">
                                  {getDeptIcon(period.departmentKey)}
                                  <span>ኃላፊ፦ <strong className="text-slate-300">{period.departmentResponsible}</strong></span>
                                </div>
                              </div>
                              <span className="font-mono text-amber-300 font-bold text-xs shrink-0">
                                {period.timeRange}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mt-4 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-500">
                        <span>የክፍለ-ጊዜ ቆይታ</span>
                        <span className="font-mono text-slate-400">
                          {periods[0]?.timeRange.split('–')[0]} - {periods[periods.length - 1]?.timeRange.split('–')[1]}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* MODE 2: BY DAY (All classes in chronological order for that day) */
        <div className="space-y-6">
          {/* Day selection tabs */}
          <div className="no-print flex items-center gap-2 overflow-x-auto pb-1 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-400 font-medium shrink-0 mr-1">ቀን ይምረጡ:</span>
            {[
              { key: 'all' as const, label: 'ሁሉም ቀናት' },
              { key: 'friday' as const, label: 'አርብ' },
              { key: 'saturday' as const, label: 'ቅዳሜ' },
              { key: 'sunday' as const, label: 'እሁድ' },
            ].map((d) => (
              <button
                key={d.key}
                onClick={() => setSelectedDay(d.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedDay === d.key
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white bg-slate-950'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>

          {/* Day Groups */}
          {(['friday', 'saturday', 'sunday'] as DayOfWeek[])
            .filter((d) => selectedDay === 'all' || selectedDay === d)
            .map((d) => {
              const dayItems = WOLD_WAHID_SCHEDULE.filter((i) => i.day === d);
              if (dayItems.length === 0) return null;
              const distinctGrades = Array.from(new Set(dayItems.map((i) => i.gradeAm)));

              return (
                <div key={d} className="bg-slate-900/70 rounded-2xl border border-slate-800 p-5 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>{dayLabels[d]}</span>
                    </h3>
                    <span className="text-xs font-mono text-amber-400 font-bold">
                      {dayItems.length} ክፍለ-ጊዜያት
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {distinctGrades.map((gradeTitle) => {
                      const items = dayItems.filter((i) => i.gradeAm === gradeTitle);
                      return (
                        <div key={gradeTitle} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
                          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                            <span className="text-xs font-bold text-amber-400">• {gradeTitle}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{items.length} ክፍለ-ጊዜ</span>
                          </div>
                          <div className="space-y-1.5">
                            {items.map((it) => (
                              <div key={it.id} className="p-2 rounded-lg bg-slate-900/80 flex items-center justify-between text-xs">
                                <div>
                                  <span className="font-medium text-slate-200">{it.activity}</span>
                                  <span className="text-[10px] text-slate-400 block">ኃላፊ፦ {it.departmentResponsible}</span>
                                </div>
                                <span className="font-mono text-amber-300 font-semibold text-xs">{it.timeRange}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
};
