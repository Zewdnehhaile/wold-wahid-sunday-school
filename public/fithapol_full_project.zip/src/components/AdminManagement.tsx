import React, { useState } from 'react';
import { AdminUser, SundaySchoolDepartment, Language } from '../types';
import { t } from '../utils/translations';
import { AVATAR_MALE, AVATAR_FEMALE } from '../data/initialData';
import {
  ShieldCheck,
  ShieldAlert,
  UserPlus,
  Key,
  Lock,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
  Users,
  Check,
  Info,
  X,
  Phone,
  Sparkles,
} from 'lucide-react';

export interface AdminPermission {
  approveStudents: boolean;
  takeAttendance: boolean;
  manageSupport: boolean;
  exportReports: boolean;
}

export interface DetailedAdmin extends AdminUser {
  phone: string;
  telegramId?: string;
  permissions: AdminPermission;
}

interface AdminManagementProps {
  currentAdmin: AdminUser;
  lang: Language;
}

export const AdminManagement: React.FC<AdminManagementProps> = ({
  currentAdmin,
  lang,
}) => {
  const [adminsList, setAdminsList] = useState<DetailedAdmin[]>([
    {
      id: 'admin-super',
      nameAm: 'መ/ር ዮሴፍ ተስፋዬ (እርስዎ / You)',
      nameEn: 'Memhir Yoseph Tesfaye',
      role: 'super_admin',
      department: 'education',
      phone: '+251 91 122 3344',
      telegramId: '606572754',
      avatarUrl: AVATAR_MALE,
      permissions: {
        approveStudents: true,
        takeAttendance: true,
        manageSupport: true,
        exportReports: true,
      },
    },
    {
      id: 'admin-1',
      nameAm: 'ቤትልሔም ካሳሁን',
      nameEn: 'Bethlehem Kassahun',
      role: 'admin',
      department: 'discipline',
      phone: '+251 94 456 7890',
      telegramId: '782910345',
      avatarUrl: AVATAR_FEMALE,
      permissions: {
        approveStudents: true,
        takeAttendance: true,
        manageSupport: false,
        exportReports: false,
      },
    },
    {
      id: 'admin-2',
      nameAm: 'ዲ/ን ዳዊት መንግስቱ',
      nameEn: 'Dn. Dawit Mengistu',
      role: 'admin',
      department: 'abnet',
      phone: '+251 93 345 6789',
      telegramId: '549201832',
      avatarUrl: AVATAR_MALE,
      permissions: {
        approveStudents: false,
        takeAttendance: true,
        manageSupport: true,
        exportReports: false,
      },
    },
    {
      id: 'admin-3',
      nameAm: 'ሰላማዊት አበራ',
      nameEn: 'Selamawit Abera',
      role: 'admin',
      department: 'choir',
      phone: '+251 92 234 5678',
      telegramId: '891043219',
      avatarUrl: AVATAR_FEMALE,
      permissions: {
        approveStudents: true,
        takeAttendance: true,
        manageSupport: false,
        exportReports: true,
      },
    },
  ]);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<DetailedAdmin | null>(null);

  // New admin form state
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminPhone, setNewAdminPhone] = useState('');
  const [newAdminTelegramId, setNewAdminTelegramId] = useState('');
  const [newAdminDept, setNewAdminDept] = useState<SundaySchoolDepartment>('education');
  const [permApprove, setPermApprove] = useState(true);
  const [permAttendance, setPermAttendance] = useState(true);
  const [permSupport, setPermSupport] = useState(false);
  const [permReports, setPermReports] = useState(false);

  const dict = t[lang];

  const handleCreateAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminName.trim()) return;

    const newAdmin: DetailedAdmin = {
      id: `admin-${Date.now()}`,
      nameAm: newAdminName,
      nameEn: newAdminName,
      role: 'admin',
      department: newAdminDept,
      phone: newAdminPhone || '+251 91 ...',
      telegramId: newAdminTelegramId || `${Math.floor(100000000 + Math.random() * 900000000)}`,
      avatarUrl: AVATAR_MALE,
      permissions: {
        approveStudents: permApprove,
        takeAttendance: permAttendance,
        manageSupport: permSupport,
        exportReports: permReports,
      },
    };

    setAdminsList((prev) => [...prev, newAdmin]);
    setIsAddModalOpen(false);

    // Reset
    setNewAdminName('');
    setNewAdminPhone('');
    setNewAdminTelegramId('');
  };

  const handleTogglePermission = (adminId: string, permKey: keyof AdminPermission) => {
    setAdminsList((prev) =>
      prev.map((adm) => {
        if (adm.id === adminId && adm.role !== 'super_admin') {
          return {
            ...adm,
            permissions: {
              ...adm.permissions,
              [permKey]: !adm.permissions[permKey],
            },
          };
        }
        return adm;
      })
    );
  };

  const handleDeleteAdmin = (adminId: string) => {
    if (confirm('ይህን ረዳት አስተዳዳሪ ከሲስተሙ መሰረዝ ይፈልጋሉ?')) {
      setAdminsList((prev) => prev.filter((adm) => adm.id !== adminId));
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
            <span>የአስተዳዳሪዎች ማኔጅመንት እና ፈቃድ መስጫ (Admin Management)</span>
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            እርስዎ እንደ <strong className="text-amber-400">ዋና አስተዳዳሪ (Super Admin)</strong> ረዳት አድሚኖችን ይሾማሉ፣ የሚያከናውኑትን ፈቃድ ይሰጣሉ።
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs shadow-lg shadow-amber-500/20 transition-colors"
        >
          <UserPlus className="w-4 h-4" />
          <span>አዲስ ረዳት አድሚን ሹም (Add Sub-Admin)</span>
        </button>
      </div>

      {/* Super Admin Ownership Card */}
      <div className="p-5 bg-gradient-to-r from-amber-500/15 via-slate-900 to-indigo-950/40 border border-amber-500/40 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-2xl shadow-inner">
            👑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                ዋና አስተዳዳሪ (Super Admin)
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                ሙሉ ስልጣን (Full Root Access)
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">
              መ/ር ዮሴፍ ተስፋዬ (የእርስዎ አካውንት)
            </h3>
            <p className="text-xs text-slate-300 font-mono">
              Telegram ID: 606572754 · ስልክ: +251 91 122 3344
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-300 bg-slate-950/70 p-3 rounded-xl border border-slate-800 max-w-sm">
          <p className="font-semibold text-amber-300 mb-1">💡 እንዴት Super Admin ሆኑ?</p>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            የእርስዎ የቴሌግራም ቁጥር ወይም ስልክ በሲስተሙ ዋና ቁጥጥር ውስጥ ስለተመዘገበ የትኛውንም ረዳት አድሚን የመጨመር፣ የመሰረዝ እና ፈቃድ የመስጠት ስልጣን የእርስዎ ብቻ ነው።
          </p>
        </div>
      </div>

      {/* Sub-Admins and Permissions Table */}
      <div className="bg-slate-900/70 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            <span>የአስተዳዳሪዎች ዝርዝርና የተሰጣቸው ፈቃዶች ({adminsList.length})</span>
          </h3>
          <span className="text-xs text-slate-400">
            ከታች ያሉትን የፈቃድ ምልክቶች በመጫን በማንኛውም ጊዜ ፈቃድ መስጠት ወይም መከልከል ይችላሉ
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 font-semibold">አስተዳዳሪ (Admin)</th>
                <th className="py-3 px-4 font-semibold">የስራ ድርሻ (Role)</th>
                <th className="py-3 px-4 font-semibold text-center">ተማሪዎችን ማጽደቅ</th>
                <th className="py-3 px-4 font-semibold text-center">የQR ክትትል</th>
                <th className="py-3 px-4 font-semibold text-center">የድጋፍ ሰሌዳ</th>
                <th className="py-3 px-4 font-semibold text-center">ሪፖርት ማውጣት</th>
                <th className="py-3 px-4 font-semibold text-right">ተግባር</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {adminsList.map((adm) => {
                const isSuper = adm.role === 'super_admin';
                return (
                  <tr key={adm.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={adm.avatarUrl || AVATAR_MALE}
                          alt={adm.nameAm}
                          className="w-9 h-9 rounded-xl object-cover border border-slate-700 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <p className="font-bold text-slate-100 truncate flex items-center gap-1.5">
                            <span>{adm.nameAm}</span>
                            {isSuper && <span className="text-xs">👑</span>}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            {adm.phone} · TG: {adm.telegramId}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      {isSuper ? (
                        <span className="text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                          ዋና አስተዳዳሪ
                        </span>
                      ) : (
                        <span className="text-slate-300 bg-slate-800 px-2 py-0.5 rounded">
                          ረዳት አስተዳዳሪ ({dict.departments[adm.department]})
                        </span>
                      )}
                    </td>

                    {/* Permissions Switches */}
                    <td className="py-3 px-4 text-center">
                      <button
                        disabled={isSuper}
                        onClick={() => handleTogglePermission(adm.id, 'approveStudents')}
                        className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                          adm.permissions.approveStudents
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-950 text-slate-500 border border-slate-800'
                        } ${isSuper ? 'opacity-80 cursor-default' : 'hover:scale-105'}`}
                      >
                        {adm.permissions.approveStudents ? '✓ የተፈቀደ' : '✗ የተከለከለ'}
                      </button>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        disabled={isSuper}
                        onClick={() => handleTogglePermission(adm.id, 'takeAttendance')}
                        className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                          adm.permissions.takeAttendance
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-950 text-slate-500 border border-slate-800'
                        } ${isSuper ? 'opacity-80 cursor-default' : 'hover:scale-105'}`}
                      >
                        {adm.permissions.takeAttendance ? '✓ የተፈቀደ' : '✗ የተከለከለ'}
                      </button>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        disabled={isSuper}
                        onClick={() => handleTogglePermission(adm.id, 'manageSupport')}
                        className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                          adm.permissions.manageSupport
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-950 text-slate-500 border border-slate-800'
                        } ${isSuper ? 'opacity-80 cursor-default' : 'hover:scale-105'}`}
                      >
                        {adm.permissions.manageSupport ? '✓ የተፈቀደ' : '✗ የተከለከለ'}
                      </button>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        disabled={isSuper}
                        onClick={() => handleTogglePermission(adm.id, 'exportReports')}
                        className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                          adm.permissions.exportReports
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-950 text-slate-500 border border-slate-800'
                        } ${isSuper ? 'opacity-80 cursor-default' : 'hover:scale-105'}`}
                      >
                        {adm.permissions.exportReports ? '✓ የተፈቀደ' : '✗ የተከለከለ'}
                      </button>
                    </td>

                    <td className="py-3 px-4 text-right">
                      {!isSuper && (
                        <button
                          onClick={() => handleDeleteAdmin(adm.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                          title="አስተዳዳሪን ሰርዝ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add New Admin Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  አዲስ ረዳት አድሚን መመደቢያ (Add Sub-Admin)
                </h3>
                <p className="text-xs text-slate-400">
                  ለአዲሱ አገልጋይ የሚያከናውናቸውን ስልጣኖችና ፈቃዶች ይስጡ
                </p>
              </div>
            </div>

            <form onSubmit={handleCreateAdmin} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  የአስተዳዳሪው ሙሉ ስም *
                </label>
                <input
                  type="text"
                  required
                  value={newAdminName}
                  onChange={(e) => setNewAdminName(e.target.value)}
                  placeholder="ምሳሌ: አብርሃም ገብረሚካኤል"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    ስልክ ቁጥር
                  </label>
                  <input
                    type="text"
                    value={newAdminPhone}
                    onChange={(e) => setNewAdminPhone(e.target.value)}
                    placeholder="+251 91 ..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    የቴሌግራም User ID (አስፈላጊ)
                  </label>
                  <input
                    type="text"
                    value={newAdminTelegramId}
                    onChange={(e) => setNewAdminTelegramId(e.target.value)}
                    placeholder="ምሳሌ: 789123456"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  የአገልግሎት ክፍል / ኮሚቴ
                </label>
                <select
                  value={newAdminDept}
                  onChange={(e) => setNewAdminDept(e.target.value as SundaySchoolDepartment)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                >
                  <option value="discipline">{dict.departments.discipline}</option>
                  <option value="education">{dict.departments.education}</option>
                  <option value="arts">{dict.departments.arts}</option>
                  <option value="abnet">{dict.departments.abnet}</option>
                  <option value="choir">{dict.departments.choir}</option>
                </select>
              </div>

              {/* Permissions Checkboxes */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <span className="font-bold text-amber-400 block mb-1">
                  የፈቃድ ገደቦች (Permissions Checklist):
                </span>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={permApprove}
                    onChange={(e) => setPermApprove(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-amber-500"
                  />
                  <span>ተማሪዎችን ማጽደቅና በእጅ Student ID መስጠት</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={permAttendance}
                    onChange={(e) => setPermAttendance(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-amber-500"
                  />
                  <span>የQR ኮድ ክትትል መመዝገብ (Take Attendance)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={permSupport}
                    onChange={(e) => setPermSupport(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-amber-500"
                  />
                  <span>የድጋፍና የጸሎት ጥያቄዎችን መከታተል (Pastoral Desk)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={permReports}
                    onChange={(e) => setPermReports(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-amber-500"
                  />
                  <span>የExcel እና የተማሪዎች ሪፖርት ማውረድ</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  ሰርዝ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20"
                >
                  ሹም / Confirm Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
