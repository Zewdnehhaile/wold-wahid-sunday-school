import React, { useState } from 'react';
import { SupportTicket, SupportCategory, SupportStatus, Priority, Member, Language, LeaveRequest } from '../types';
import { INITIAL_LEAVE_REQUESTS } from '../data/initialData';
import { t } from '../utils/translations';
import {
  HeartHandshake,
  AlertTriangle,
  Lock,
  Plus,
  MessageSquare,
  User,
  Phone,
  Clock,
  CheckCircle2,
  Filter,
  X,
  Send,
  CalendarX,
  FileText,
  Check,
} from 'lucide-react';

interface SupportDeskProps {
  tickets: SupportTicket[];
  members: Member[];
  onAddTicket: (ticket: SupportTicket) => void;
  onUpdateTicketStatus: (ticketId: string, status: SupportStatus) => void;
  onAddNote: (ticketId: string, author: string, text: string) => void;
  lang: Language;
}

export const SupportDesk: React.FC<SupportDeskProps> = ({
  tickets,
  members,
  onAddTicket,
  onUpdateTicketStatus,
  onAddNote,
  lang,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'kanban' | 'absence' | 'leaves'>('kanban');
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [newNoteText, setNewNoteText] = useState('');
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(INITIAL_LEAVE_REQUESTS);


  // Form states
  const [requesterName, setRequesterName] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState<SupportCategory>('prayer');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [isConfidential, setIsConfidential] = useState(false);
  const [assignedTo, setAssignedTo] = useState('');

  const dict = t[lang];

  // Absence Alert list (members with 2+ consecutive absences)
  const absentMembers = members.filter((m) => m.consecutiveAbsences >= 2);

  const filteredTickets = tickets.filter((t) => {
    return selectedCategory === 'all' || t.category === selectedCategory;
  });

  const columns: { id: SupportStatus; label: string; color: string }[] = [
    { id: 'new', label: dict.support.columns.new, color: 'border-blue-500/30' },
    { id: 'assigned', label: dict.support.columns.assigned, color: 'border-amber-500/30' },
    { id: 'in_contact', label: dict.support.columns.in_contact, color: 'border-purple-500/30' },
    { id: 'resolved', label: dict.support.columns.resolved, color: 'border-emerald-500/30' },
  ];

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !requesterName.trim()) return;

    const newTicket: SupportTicket = {
      id: `spt-${Date.now()}`,
      ticketNumber: `SPT-${Math.floor(100 + Math.random() * 900)}`,
      requesterName,
      phone: phone || '+251 91 000 0000',
      category,
      title,
      description,
      priority,
      status: 'new',
      assignedTo: assignedTo || undefined,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      isConfidential,
      notes: [],
    };

    onAddTicket(newTicket);
    setIsNewModalOpen(false);

    // Reset
    setTitle('');
    setDescription('');
    setRequesterName('');
    setPhone('');
    setIsConfidential(false);
  };

  const handleSendNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !newNoteText.trim()) return;

    onAddNote(selectedTicket.id, 'አስተባባሪ / Minister', newNoteText.trim());
    setNewNoteText('');

    // Update local ticket view
    setSelectedTicket((prev) =>
      prev
        ? {
            ...prev,
            notes: [
              ...prev.notes,
              {
                id: `n-${Date.now()}`,
                author: 'አስተባባሪ / Minister',
                text: newNoteText.trim(),
                date: new Date().toISOString().replace('T', ' ').slice(0, 16),
              },
            ],
          }
        : null
    );
  };

  const getPriorityBadge = (p: Priority) => {
    switch (p) {
      case 'urgent':
        return <span className="text-[10px] font-semibold text-rose-400">● አስቸኳይ / Urgent</span>;
      case 'high':
        return <span className="text-[10px] font-semibold text-amber-400">● ከፍተኛ / High</span>;
      case 'medium':
        return <span className="text-[10px] text-blue-400">● መካከለኛ / Med</span>;
      default:
        return <span className="text-[10px] text-slate-400">● መደበኛ / Low</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {dict.support.title}
          </h2>
          <p className="text-sm text-slate-400 mt-1">{dict.support.subtitle}</p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Leaves Tab Button */}
          <button
            onClick={() => setActiveTab(activeTab === 'leaves' ? 'kanban' : 'leaves')}
            className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
              activeTab === 'leaves'
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700'
            }`}
          >
            <FileText className="w-4 h-4 text-purple-400" />
            <span>የፈቃድ ጥያቄዎች (Leaves)</span>
            <span className="px-1.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold">
              {leaveRequests.filter((l) => l.status === 'pending').length}
            </span>
          </button>

          {/* Absence Alert Tab button */}
          <button
            onClick={() => setActiveTab(activeTab === 'absence' ? 'kanban' : 'absence')}
            className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
              activeTab === 'absence'
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700'
            }`}
          >
            <CalendarX className="w-4 h-4 text-rose-400" />
            <span>{dict.support.absenceAlerts}</span>
            {absentMembers.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                {absentMembers.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsNewModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20"
          >
            <Plus className="w-4 h-4" />
            <span>{dict.support.newTicket}</span>
          </button>
        </div>
      </div>

      {/* Category Segmented Filters */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 bg-slate-900/60 p-2 rounded-2xl border border-slate-800">
        {[
          { id: 'all', label: dict.support.categories.all },
          { id: 'prayer', label: dict.support.categories.prayer },
          { id: 'visitation', label: dict.support.categories.visitation },
          { id: 'counseling', label: dict.support.categories.counseling },
          { id: 'welfare', label: dict.support.categories.welfare },
        ].map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCategory(c.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
              selectedCategory === c.id
                ? 'bg-slate-800 text-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {activeTab === 'leaves' ? (
        /* Leave Requests View */
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  የተማሪዎች ፈቃድ መጠየቂያዎች (Leave of Absence Requests)
                </h3>
                <p className="text-xs text-slate-400">
                  በቴሌግራም ቦቱ Support Center በኩል በተማሪዎች የተላኩ የፈቃድ ጥያቄዎች ማረጋገጫና ውሳኔ መስጫ
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl bg-purple-500/10 text-purple-300 border border-purple-500/20 text-xs font-bold">
                {leaveRequests.filter((l) => l.status === 'pending').length} ማጽደቅ የሚጠብቁ
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 uppercase font-mono border-b border-slate-800">
                <tr>
                  <th className="p-3">መለያ ቁጥር</th>
                  <th className="p-3">የተማሪ ስም</th>
                  <th className="p-3">የፈቃድ አይነት</th>
                  <th className="p-3">የፈቃድ ቆይታ</th>
                  <th className="p-3">ምክንያት (Reason)</th>
                  <th className="p-3">ቀን</th>
                  <th className="p-3">ሁኔታ</th>
                  <th className="p-3 text-right">ውሳኔ (Actions)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {leaveRequests.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-800/30 transition">
                    <td className="p-3 font-mono font-bold text-purple-400">{l.requestNumber}</td>
                    <td className="p-3">
                      <p className="font-medium text-white">{l.studentName}</p>
                      <p className="font-mono text-[10px] text-amber-300">{l.studentCode || '-'}</p>
                    </td>
                    <td className="p-3 font-semibold text-purple-300">{l.leaveType}</td>
                    <td className="p-3">{l.duration}</td>
                    <td className="p-3 max-w-xs truncate text-slate-400" title={l.reason}>{l.reason}</td>
                    <td className="p-3 font-mono text-[10px] text-slate-500">{l.createdAt}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        l.status === 'approved'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : l.status === 'rejected'
                          ? 'bg-red-500/10 text-red-400 border-red-500/20'
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse'
                      }`}>
                        {l.status === 'approved' ? 'Approved' : l.status === 'rejected' ? 'Rejected' : 'Pending'}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      {l.status === 'pending' ? (
                        <div className="inline-flex gap-1.5 justify-end">
                          <button
                            onClick={() => {
                              setLeaveRequests(leaveRequests.map((r) => r.id === l.id ? { ...r, status: 'approved' as const, approvedBy: 'ኪዱስ ያሬድ' } : r));
                            }}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold flex items-center gap-1 transition shadow-sm"
                          >
                            <Check className="w-3 h-3" />
                            <span>አጽድቅ</span>
                          </button>
                          <button
                            onClick={() => {
                              setLeaveRequests(leaveRequests.map((r) => r.id === l.id ? { ...r, status: 'rejected' as const, approvedBy: 'ኪዱስ ያሬድ' } : r));
                            }}
                            className="px-2.5 py-1 bg-red-600/80 hover:bg-red-500 text-white rounded text-[11px] font-bold flex items-center gap-1 transition shadow-sm"
                          >
                            <X className="w-3 h-3" />
                            <span>ውድቅ</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-500">
                          {l.status === 'approved' ? 'በአድሚን ጸድቋል' : 'ውድቅ ተደርጓል'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === 'absence' ? (
        /* Absence Alert View */
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
              <CalendarX className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                ያልተገኙ አባላት ክትትል (Absence Follow-Up Engine)
              </h3>
              <p className="text-xs text-slate-400">
                ለተከታታይ 2 ወይም ከዚያ በላይ ሳምንት ጉባኤ ያልተገኙ አባላት ዝርዝር። በስልክ እንዲደወልላቸው ወይም በቤት እንዲጎበኙ ያድርጉ።
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {absentMembers.map((m) => (
              <div
                key={m.id}
                className="p-4 rounded-xl bg-slate-950 border border-rose-500/30 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={m.photoUrl}
                    alt={m.fullNameAm}
                    className="w-12 h-12 rounded-xl object-cover border border-rose-400/50 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <h5 className="text-sm font-bold text-white truncate">{m.fullNameAm}</h5>
                    <p className="text-xs text-slate-400">{m.fullNameEn} · {dict.departments[m.department]}</p>
                    <p className="text-xs text-rose-400 font-medium mt-1">
                      ለ {m.consecutiveAbsences} ተከታታይ ሳምንት አልተገኙም
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-2 shrink-0">
                  <a
                    href={`tel:${m.phone}`}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 hover:bg-emerald-600/30 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>ይደውሉ</span>
                  </a>
                  <button
                    onClick={() => {
                      setRequesterName(m.fullNameAm);
                      setPhone(m.phone);
                      setCategory('visitation');
                      setTitle(`የአባል መጠየቅ እና የቤት ጉብኝት፡ ${m.fullNameAm}`);
                      setDescription(`አባሉ ለ ${m.consecutiveAbsences} ሳምንት ስላልተገኙ ደውሎ ሁኔታቸውን ማጣራትና መጎብኘት።`);
                      setPriority('high');
                      setIsNewModalOpen(true);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium"
                  >
                    ጥያቄ ክፈት
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Kanban Board View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((col) => {
            const colTickets = filteredTickets.filter((t) => t.status === col.id);
            return (
              <div
                key={col.id}
                className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 flex flex-col min-h-[500px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-200">{col.label}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                      {colTickets.length}
                    </span>
                  </div>
                </div>

                {/* Tickets list */}
                <div className="space-y-3 flex-1 overflow-y-auto">
                  {colTickets.length === 0 ? (
                    <div className="h-32 flex items-center justify-center text-slate-500 text-xs">
                      {lang === 'am' ? 'ምንም ጥያቄ የለም' : 'No tickets in this stage'}
                    </div>
                  ) : (
                    colTickets.map((ticket) => (
                      <div
                        key={ticket.id}
                        onClick={() => setSelectedTicket(ticket)}
                        className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer shadow-sm group"
                      >
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <span className="text-[10px] font-mono font-bold text-amber-400">
                            {ticket.ticketNumber}
                          </span>
                          <div className="flex items-center gap-1.5">
                            {ticket.isConfidential && (
                              <span
                                title="Confidential"
                                className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-0.5"
                              >
                                <Lock className="w-2.5 h-2.5" />
                                <span>ሚስጥራዊ</span>
                              </span>
                            )}
                            {getPriorityBadge(ticket.priority)}
                          </div>
                        </div>

                        <h4 className="text-xs font-bold text-slate-100 group-hover:text-amber-300 transition-colors line-clamp-2">
                          {ticket.title}
                        </h4>

                        <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                          {ticket.description}
                        </p>

                        <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                          <div className="flex items-center gap-1">
                            <User className="w-3 h-3 text-slate-500" />
                            <span className="truncate max-w-[90px]">{ticket.requesterName}</span>
                          </div>

                          {ticket.notes.length > 0 && (
                            <span className="flex items-center gap-1 text-slate-400">
                              <MessageSquare className="w-3 h-3" />
                              <span className="font-mono">{ticket.notes.length}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Ticket Details & Notes Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative max-h-[85vh] flex flex-col">
            <button
              onClick={() => setSelectedTicket(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-amber-400">
                  {selectedTicket.ticketNumber}
                </span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-xs text-slate-300">
                  {dict.support.categories[selectedTicket.category]}
                </span>
                {selectedTicket.isConfidential && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> ሚስጥራዊ
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-white mt-1">
                {selectedTicket.title}
              </h3>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <p className="text-slate-200 leading-relaxed">
                  {selectedTicket.description}
                </p>
                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-slate-400">
                  <span>ጠያቂ፡ <strong className="text-white">{selectedTicket.requesterName}</strong></span>
                  <a href={`tel:${selectedTicket.phone}`} className="text-indigo-400 font-mono flex items-center gap-1">
                    <Phone className="w-3 h-3" /> {selectedTicket.phone}
                  </a>
                </div>
              </div>

              {/* Status Selector */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
                  የጉዳዩ ወቅታዊ ሁኔታ (Status)
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {columns.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        onUpdateTicketStatus(selectedTicket.id, c.id);
                        setSelectedTicket((prev) => prev ? { ...prev, status: c.id } : null);
                      }}
                      className={`py-1.5 px-2 rounded-lg text-[11px] font-medium transition-colors ${
                        selectedTicket.status === c.id
                          ? 'bg-indigo-600 text-white font-bold'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Case Notes History */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-2">
                  የክትትል ማስታወሻዎች ({selectedTicket.notes.length})
                </label>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {selectedTicket.notes.length === 0 ? (
                    <p className="text-slate-500 italic">እስካሁን ምንም ማስታወሻ አልተጨመረም።</p>
                  ) : (
                    selectedTicket.notes.map((note) => (
                      <div key={note.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                          <span className="font-semibold text-amber-400">{note.author}</span>
                          <span className="font-mono">{note.date}</span>
                        </div>
                        <p className="text-slate-200">{note.text}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Note Input */}
            <form onSubmit={handleSendNote} className="pt-3 border-t border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={newNoteText}
                onChange={(e) => setNewNoteText(e.target.value)}
                placeholder="አዲስ የክትትል ማስታወሻ ይጻፉ..."
                className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>ላክ</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* New Ticket Modal */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative">
            <button
              onClick={() => setIsNewModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">
              {dict.support.newTicket}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {lang === 'am' ? 'የአገልግሎት ወይም የድጋፍ ጥያቄን ይመዝግቡ' : 'Log pastoral or welfare request'}
            </p>

            <form onSubmit={handleCreateTicket} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    የጠያቂው ስም *
                  </label>
                  <input
                    type="text"
                    required
                    value={requesterName}
                    onChange={(e) => setRequesterName(e.target.value)}
                    placeholder="ምሳሌ: አበበ ከበደ"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    ስልክ ቁጥር
                  </label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+251 91 ..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    የጉዳዩ ዓይነት (Category)
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as SupportCategory)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="prayer">{dict.support.categories.prayer}</option>
                    <option value="visitation">{dict.support.categories.visitation}</option>
                    <option value="counseling">{dict.support.categories.counseling}</option>
                    <option value="welfare">{dict.support.categories.welfare}</option>
                    <option value="general">{dict.support.categories.general}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    አስቸኳይነት (Priority)
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as Priority)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="low">{dict.support.priority.low}</option>
                    <option value="medium">{dict.support.priority.medium}</option>
                    <option value="high">{dict.support.priority.high}</option>
                    <option value="urgent">{dict.support.priority.urgent}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  የጉዳዩ አርዕስት *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="ምሳሌ: የጸሎት ጥያቄ ለፈተና"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  ዝርዝር ማብራሪያ
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="የጉዳዩን ዝርዝር መረጃ እዚህ ያስገቡ..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="confidential-check"
                  checked={isConfidential}
                  onChange={(e) => setIsConfidential(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="confidential-check" className="text-xs text-slate-300 cursor-pointer">
                  ሚስጥራዊ ጉዳይ ነው (ለተመረጡ መሪዎች ብቻ እንዲታይ)
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  ሰርዝ / Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
                >
                  መዝግብ / Create Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
