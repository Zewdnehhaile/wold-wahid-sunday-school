import React, { useState, useEffect } from 'react';
import { Member, AttendanceRecord, ServiceSession, Language } from '../types';
import { t } from '../utils/translations';
import {
  QrCode,
  Scan,
  CheckCircle,
  UserCheck,
  Clock,
  Sparkles,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  UserPlus,
  X,
  AlertCircle,
  Search,
} from 'lucide-react';

interface AttendanceScannerProps {
  members: Member[];
  attendance: AttendanceRecord[];
  sessions: ServiceSession[];
  activeSession: ServiceSession;
  onSelectSession: (session: ServiceSession) => void;
  onCheckIn: (record: AttendanceRecord) => void;
  lang: Language;
}

export const AttendanceScanner: React.FC<AttendanceScannerProps> = ({
  members,
  attendance,
  sessions,
  activeSession,
  onSelectSession,
  onCheckIn,
  lang,
}) => {
  const [codeQuery, setCodeQuery] = useState('');
  const [lastCheckedInMember, setLastCheckedInMember] = useState<{
    member: Member | { fullNameAm: string; fullNameEn: string; code: string; photoUrl?: string };
    timestamp: string;
    isDuplicate?: boolean;
    isGuest?: boolean;
  } | null>(null);

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isKioskMode, setIsKioskMode] = useState(false);
  const [isGuestModalOpen, setIsGuestModalOpen] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');

  const dict = t[lang];

  // Synthetic Pleasant Audio Chime using Web Audio API
  const playChime = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5

      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    } catch {
      // AudioContext unavailable or restricted
    }
  };

  const handleProcessCode = (code: string, method: 'qr' | 'kiosk' | 'manual' = 'qr') => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return;

    // Check if member exists
    const member = members.find(
      (m) =>
        m.code.toUpperCase() === cleanCode ||
        m.phone.replace(/\s+/g, '') === cleanCode.replace(/\s+/g, '')
    );

    const currentTime = new Date().toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const todayDate = new Date().toISOString().split('T')[0];

    if (!member) {
      alert(
        lang === 'am'
          ? `የተሳሳተ የአባል መለያ ኮድ፡ "${code}" አልተገኘም።`
          : `Member code "${code}" not found. You can register as guest.`
      );
      return;
    }

    // Check if already checked in today for this session
    const alreadyCheckedIn = attendance.some(
      (att) => att.memberId === member.id && att.sessionName === activeSession.nameAm
    );

    if (alreadyCheckedIn) {
      setLastCheckedInMember({
        member,
        timestamp: currentTime,
        isDuplicate: true,
      });
      return;
    }

    const newRecord: AttendanceRecord = {
      id: `att-${Date.now()}`,
      memberId: member.id,
      memberNameAm: member.fullNameAm,
      memberNameEn: member.fullNameEn,
      memberCode: member.code,
      department: member.department,
      sessionName: activeSession.nameAm,
      timestamp: currentTime,
      date: todayDate,
      method,
    };

    onCheckIn(newRecord);
    setLastCheckedInMember({
      member,
      timestamp: currentTime,
      isDuplicate: false,
    });
    playChime();
    setCodeQuery('');
  };

  const handleGuestCheckIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;

    const currentTime = new Date().toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const todayDate = new Date().toISOString().split('T')[0];
    const guestCode = `GST-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRecord: AttendanceRecord = {
      id: `att-guest-${Date.now()}`,
      memberId: `guest-${Date.now()}`,
      memberNameAm: `${guestName} (እንግዳ / Guest)`,
      memberNameEn: `${guestName} (Guest)`,
      memberCode: guestCode,
      department: 'general',
      sessionName: activeSession.nameAm,
      timestamp: currentTime,
      date: todayDate,
      method: 'manual',
      isGuest: true,
    };

    onCheckIn(newRecord);
    setLastCheckedInMember({
      member: {
        fullNameAm: guestName,
        fullNameEn: guestName,
        code: guestCode,
      },
      timestamp: currentTime,
      isDuplicate: false,
      isGuest: true,
    });
    playChime();
    setGuestName('');
    setGuestPhone('');
    setIsGuestModalOpen(false);
  };

  // KPIs
  const todayRecords = attendance.filter((a) => a.sessionName === activeSession.nameAm);
  const presentCount = todayRecords.length;
  const guestCount = todayRecords.filter((a) => a.isGuest).length;

  return (
    <div className={`space-y-6 ${isKioskMode ? 'fixed inset-0 z-50 bg-slate-950 p-6 overflow-y-auto' : ''}`}>
      {/* Top Header & Session Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {dict.attendance.title}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {dict.attendance.subtitle} ·{' '}
            <span className="text-amber-400 font-medium">
              {lang === 'am' ? activeSession.nameAm : activeSession.nameEn}
            </span>
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'Mute Chime' : 'Enable Chime'}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Guest Registration */}
          <button
            onClick={() => setIsGuestModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold"
          >
            <UserPlus className="w-4 h-4 text-indigo-400" />
            <span>{dict.attendance.fastTrackGuest}</span>
          </button>

          {/* Kiosk Mode Toggle */}
          <button
            onClick={() => setIsKioskMode(!isKioskMode)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
              isKioskMode
                ? 'bg-amber-500 text-slate-950'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20'
            }`}
          >
            {isKioskMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            <span>{dict.attendance.kioskMode}</span>
          </button>
        </div>
      </div>

      {/* Active Sunday School Class Session Selector */}
      <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs font-medium text-slate-300">
            {dict.attendance.sessionLabel}:
          </span>
        </div>
        <select
          value={activeSession.id}
          onChange={(e) => {
            const found = sessions.find((s) => s.id === e.target.value);
            if (found) onSelectSession(found);
          }}
          className="flex-1 max-w-md px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-amber-300 font-semibold focus:outline-none focus:border-amber-400"
        >
          {sessions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.nameAm}
            </option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 font-medium">{dict.attendance.todayPresent}</span>
          <p className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {presentCount}
          </p>
        </div>
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 font-medium">የተመዘገቡ አባላት / Total</span>
          <p className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            {members.length}
          </p>
        </div>
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 font-medium">የመጀመሪያ እንግዶች / Guests</span>
          <p className="text-2xl font-bold font-mono text-indigo-400 mt-1 tabular-nums">
            {guestCount}
          </p>
        </div>
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 font-medium">የተገኝነት ምጣኔ / Attendance %</span>
          <p className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            {members.length > 0 ? `${Math.round((presentCount / members.length) * 100)}%` : '0%'}
          </p>
        </div>
      </div>

      {/* Main Check-In Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Scanner & Code Entry */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl text-center flex flex-col items-center justify-center relative overflow-hidden">
            {/* Visual Scanner Frame */}
            <div className="relative w-56 h-56 rounded-2xl border-2 border-dashed border-indigo-500/60 bg-slate-950/60 flex flex-col items-center justify-center p-4 shadow-inner group">
              {/* Corner markers */}
              <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-amber-400" />
              <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-amber-400" />
              <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-amber-400" />
              <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-amber-400" />

              {/* Animated scanning laser line */}
              <div className="absolute left-3 right-3 h-0.5 bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-pulse" />

              <Scan className="w-12 h-12 text-indigo-400 mb-2 opacity-80" />
              <span className="text-xs font-semibold text-slate-200">
                {lang === 'am' ? 'የQR ኮድ ስካነር' : 'Optical QR Scanner'}
              </span>
              <span className="text-[10px] text-slate-400 mt-1 max-w-[160px]">
                {dict.attendance.scanInstruction}
              </span>
            </div>

            {/* Quick Test Simulator: Click any member to simulate instant scan */}
            <div className="mt-5 w-full">
              <span className="text-xs font-medium text-slate-400 mb-2 block">
                {lang === 'am' ? 'ፈጣን የሙከራ ስካን (አባል ይምረጡ):' : 'Instant Test Scan (Click to Scan):'}
              </span>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                {members.slice(0, 4).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleProcessCode(m.code, 'qr')}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-slate-700 transition-colors"
                  >
                    <img
                      src={m.photoUrl}
                      alt={m.fullNameAm}
                      className="w-5 h-5 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <span>{m.fullNameAm.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Code Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleProcessCode(codeQuery, 'manual');
              }}
              className="mt-5 w-full max-w-sm flex items-center gap-2"
            >
              <input
                type="text"
                value={codeQuery}
                onChange={(e) => setCodeQuery(e.target.value)}
                placeholder={dict.attendance.enterCode}
                className="flex-1 px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shrink-0"
              >
                {dict.attendance.checkInBtn}
              </button>
            </form>
          </div>
        </div>

        {/* Right: Live Greeting Banner & Recent Check-Ins */}
        <div className="lg:col-span-6 space-y-4">
          {/* Recent Scan Greeting Box */}
          {lastCheckedInMember && (
            <div
              className={`p-4 rounded-2xl border transition-all ${
                lastCheckedInMember.isDuplicate
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
              }`}
            >
              <div className="flex items-center gap-3">
                {'photoUrl' in lastCheckedInMember.member && lastCheckedInMember.member.photoUrl ? (
                  <img
                    src={lastCheckedInMember.member.photoUrl}
                    alt="Member"
                    className="w-12 h-12 rounded-xl object-cover border border-emerald-400"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-300">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                      {lastCheckedInMember.isDuplicate
                        ? dict.attendance.alreadyCheckedIn
                        : dict.attendance.welcomeBanner}
                    </span>
                    <span className="text-[10px] font-mono opacity-70">
                      {lastCheckedInMember.timestamp}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white truncate">
                    {lastCheckedInMember.member.fullNameAm}
                  </h4>
                  <p className="text-xs text-slate-300 font-mono">
                    {lastCheckedInMember.member.code}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Recent Check-Ins List */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center justify-between">
              <span>{dict.attendance.recentCheckins}</span>
              <span className="text-xs font-mono text-slate-400">
                {todayRecords.length} ተመዝግበዋል
              </span>
            </h3>

            <div className="space-y-2 max-h-80 overflow-y-auto">
              {todayRecords.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs">
                  {lang === 'am' ? 'እስካሁን የተመዘገበ የለም።' : 'No check-ins recorded yet.'}
                </div>
              ) : (
                todayRecords.map((record) => (
                  <div
                    key={record.id}
                    className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-200 truncate">
                          {record.memberNameAm}
                        </p>
                        <p className="text-[10px] font-mono text-amber-400">
                          {record.memberCode}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-mono text-slate-400 block">{record.timestamp}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                        {record.method}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Guest Modal */}
      {isGuestModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl relative">
            <button
              onClick={() => setIsGuestModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-1">
              {dict.attendance.fastTrackGuest}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {lang === 'am'
                ? 'የመጀመሪያ እንግዳን በ30 ሰከንድ ውስጥ መዝግቦ መገኘታቸውን ያረጋግጡ።'
                : 'Fast-track visitor check-in at the front desk.'}
            </p>

            <form onSubmit={handleGuestCheckIn} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  የእንግዳው ሙሉ ስም *
                </label>
                <input
                  type="text"
                  required
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="ምሳሌ: አበበ ከበደ"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  ስልክ ቁጥር
                </label>
                <input
                  type="text"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  placeholder="+251 91 ..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsGuestModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  ሰርዝ / Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
                >
                  መዝግብና አረጋግጥ / Confirm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
