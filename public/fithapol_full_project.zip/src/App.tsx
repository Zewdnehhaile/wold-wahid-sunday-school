import React, { useState, useEffect } from 'react';
import { Member, AttendanceRecord, SupportTicket, ServiceSession, Language, SupportStatus, AdminUser } from './types';
import {
  INITIAL_SESSIONS,
  INITIAL_ADMINS,
  FITHAPOL_LOGO,
  AVATAR_MALE,
  AVATAR_FEMALE,
} from './data/initialData';
import { db } from './firebase';
import { collection, onSnapshot, doc, addDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { t } from './utils/translations';
import { MemberList } from './components/MemberList';
import { AttendanceScanner } from './components/AttendanceScanner';
import { SupportDesk } from './components/SupportDesk';
import { AnalyticsView } from './components/AnalyticsView';
import { TelegramSimulator } from './components/TelegramSimulator';
import { IdCardStudio } from './components/IdCardStudio';
import { ScheduleView } from './components/ScheduleView';
import { AdminManagement } from './components/AdminManagement';
import { MobileAppSimulator } from './components/MobileAppSimulator';
import { ZipDownloadModal } from './components/ZipDownloadModal';
import {
  Calendar,
  Users,
  QrCode,
  HeartHandshake,
  BarChart3,
  Smartphone,
  Globe,
  Printer,
  ChevronRight,
  ShieldCheck,
  FolderArchive,
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('am');
  const [activeTab, setActiveTab] = useState<'schedule' | 'members' | 'attendance' | 'support' | 'admins' | 'analytics' | 'telegram' | 'mobile'>('schedule');
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Live Firestore state (no mock data)
  const [registrations, setRegistrations] = useState<Member[]>([]);
  const [students, setStudents] = useState<Member[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  const [sessions] = useState<ServiceSession[]>(INITIAL_SESSIONS);
  const [activeSession, setActiveSession] = useState<ServiceSession>(INITIAL_SESSIONS[0]);

  // Role-Based Access Control: 1 Super Admin and Multiple Admins
  const [admins] = useState<AdminUser[]>(INITIAL_ADMINS);
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser>(INITIAL_ADMINS[0]);

  // Card Studio state
  const [isCardStudioOpen, setIsCardStudioOpen] = useState(false);
  const [studioTargetMember, setStudioTargetMember] = useState<Member | null>(null);

  // Real-time Firestore subscriptions
  useEffect(() => {
    // 1. Listen to real-time pending & approved registrations
    const unsubReg = onSnapshot(collection(db, 'registrations'), (snap) => {
      const regList: Member[] = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          code: d.studentCode || `PENDING-${d.telegramId ? String(d.telegramId).slice(-4) : docSnap.id.slice(0, 4)}`,
          fullNameAm: d.fullNameAm || d.fullNameEn || 'ያልተገለጸ ስም',
          fullNameEn: d.fullNameEn || d.fullNameAm || 'Unnamed Student',
          phone: d.phone || '',
          gender: d.gender === 'female' ? 'female' : 'male',
          department: d.department || 'education',
          gradeLevel: d.gradeLevel || 'pre_kg',
          roleAm: 'ተማሪ / Student',
          roleEn: 'Student',
          photoUrl: d.gender === 'female' ? AVATAR_FEMALE : AVATAR_MALE,
          registeredDate: d.submittedAt?.split('T')[0] || new Date().toISOString().split('T')[0],
          bloodGroup: 'Unknown',
          emergencyContact: { name: '', phone: '', relation: '' },
          subcity: d.subcity || '',
          status: d.status === 'approved' ? 'active' : d.status === 'rejected' ? 'rejected' : 'pending_approval',
          telegramUsername: d.telegramUsername || '',
          consecutiveAbsences: 0,
        };
      });
      setRegistrations(regList);
    });

    // 2. Listen to real-time approved students
    const unsubStudents = onSnapshot(collection(db, 'students'), (snap) => {
      const studentList: Member[] = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          code: d.code || d.studentCode || 'WW-2026-0001',
          fullNameAm: d.fullNameAm || d.fullNameEn || '',
          fullNameEn: d.fullNameEn || d.fullNameAm || '',
          phone: d.phone || '',
          gender: d.gender === 'female' ? 'female' : 'male',
          department: d.department || 'education',
          gradeLevel: d.gradeLevel || 'general',
          roleAm: 'ተማሪ / Student',
          roleEn: 'Student',
          photoUrl: d.photoUrl || (d.gender === 'female' ? AVATAR_FEMALE : AVATAR_MALE),
          registeredDate: d.registeredDate || new Date().toISOString().split('T')[0],
          bloodGroup: d.bloodGroup || 'O+',
          emergencyContact: d.emergencyContact || { name: '', phone: '', relation: '' },
          subcity: d.subcity || '',
          status: 'active',
          telegramUsername: d.telegramUsername || '',
          consecutiveAbsences: d.consecutiveAbsences || 0,
        };
      });
      setStudents(studentList);
    });

    // 3. Listen to real-time support tickets
    const unsubTickets = onSnapshot(collection(db, 'support_tickets'), (snap) => {
      const ticketList: SupportTicket[] = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          ticketNumber: d.ticketNumber || `WW-SPT-${docSnap.id.slice(0, 4)}`,
          requesterName: d.requesterName || d.studentName || 'Sunday School Member',
          phone: d.phone || '',
          category: d.category || 'general',
          title: d.title || d.category || 'Support Request',
          description: d.description || d.message || '',
          priority: d.priority || 'medium',
          status: d.status || 'new',
          createdAt: d.createdAt || new Date().toISOString(),
          updatedAt: d.updatedAt || new Date().toISOString(),
          isConfidential: !!d.isConfidential,
          notes: d.notes || [],
        };
      });
      setTickets(ticketList);
    });

    // 4. Listen to real-time attendance logs
    const unsubAttendance = onSnapshot(collection(db, 'attendance'), (snap) => {
      const attList: AttendanceRecord[] = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          memberId: d.memberId || d.studentId || '',
          memberNameAm: d.memberNameAm || d.fullNameAm || 'Student',
          memberNameEn: d.memberNameEn || d.fullNameEn || 'Student',
          memberCode: d.memberCode || d.studentCode || '',
          department: d.department || 'education',
          sessionName: d.sessionName || 'Sunday School Session',
          timestamp: d.timestamp || '',
          date: d.date || '',
          method: d.method || 'qr',
        };
      });
      setAttendance(attList);
    });

    return () => {
      unsubReg();
      unsubStudents();
      unsubTickets();
      unsubAttendance();
    };
  }, []);

  // Combined live members: approved students + pending applications
  const members = [...students, ...registrations.filter((r) => r.status === 'pending_approval')];
  const pendingCount = registrations.filter((r) => r.status === 'pending_approval').length;

  const dict = t[lang];

  // Real Actions hooked to Firestore and Backend Notification
  const handleAddMember = async (newMember: Member) => {
    try {
      await addDoc(collection(db, 'students'), {
        code: newMember.code,
        fullNameAm: newMember.fullNameAm,
        fullNameEn: newMember.fullNameEn,
        phone: newMember.phone,
        gender: newMember.gender,
        department: newMember.department,
        gradeLevel: newMember.gradeLevel || 'general',
        status: 'active',
        registeredDate: new Date().toISOString().split('T')[0],
      });
    } catch (e) {
      console.error('Error adding member to Firestore:', e);
    }
  };

  const handleApproveMember = async (memberId: string, manualStudentId: string) => {
    try {
      // Call backend approval API to update registration, add student, and notify Telegram bot
      await fetch(`/api/registrations/${memberId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentCode: manualStudentId,
          approvedBy: currentAdmin.nameAm,
        }),
      });
    } catch (e) {
      console.error('Approval failed:', e);
    }
  };

  const handleRejectMember = async (memberId: string) => {
    try {
      await updateDoc(doc(db, 'registrations', memberId), {
        status: 'rejected',
        rejectedAt: new Date().toISOString(),
        rejectedBy: currentAdmin.nameAm,
      });
    } catch (e) {
      console.error('Rejection failed:', e);
    }
  };

  const handleCheckIn = async (record: AttendanceRecord) => {
    try {
      await addDoc(collection(db, 'attendance'), {
        ...record,
        timestamp: record.timestamp || new Date().toLocaleTimeString(),
        date: record.date || new Date().toISOString().split('T')[0],
      });
    } catch (e) {
      console.error('Check-in failed:', e);
    }
  };

  const handleAddTicket = async (ticket: SupportTicket) => {
    try {
      await addDoc(collection(db, 'support_tickets'), ticket);
    } catch (e) {
      console.error('Add ticket failed:', e);
    }
  };

  const handleUpdateTicketStatus = async (ticketId: string, status: SupportStatus) => {
    try {
      await updateDoc(doc(db, 'support_tickets', ticketId), {
        status,
        updatedAt: new Date().toISOString(),
      });
    } catch (e) {
      console.error('Update ticket failed:', e);
    }
  };

  const handleAddNote = async (ticketId: string, author: string, text: string) => {
    try {
      const ticket = tickets.find((t) => t.id === ticketId);
      if (!ticket) return;
      const updatedNotes = [
        ...ticket.notes,
        {
          id: `n-${Date.now()}`,
          author,
          text,
          date: new Date().toISOString().replace('T', ' ').slice(0, 16),
        },
      ];
      await updateDoc(doc(db, 'support_tickets', ticketId), {
        notes: updatedNotes,
        updatedAt: new Date().toISOString(),
      });
    } catch (e) {
      console.error('Add note failed:', e);
    }
  };

  const handleOpenCardStudio = (member?: Member) => {
    setStudioTargetMember(member || members[0] || null);
    setIsCardStudioOpen(true);
  };

  const handleSelectSessionFromSchedule = (sessionName: string, grade: string) => {
    const matching = sessions.find((s) => s.gradeAm === grade || s.nameAm.includes(grade));
    if (matching) {
      setActiveSession(matching);
    }
    setActiveTab('attendance');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Bar Contract: Zone 1 (Wordmark) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Primary Action) */}
      <header className="no-print border-b border-slate-800/80 bg-slate-900/70 backdrop-blur-md sticky top-0 z-40 px-6 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <img
            src={FITHAPOL_LOGO}
            alt="Wold Wahid Logo"
            className="w-8 h-8 rounded-full border border-amber-400/50 object-cover shadow-sm"
            referrerPolicy="no-referrer"
          />
          <a href="#" className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            <span>የወልድ ዋሕድ</span>
            <span className="text-amber-400 ml-1.5 font-medium font-sans">ሰ/ት/ቤት</span>
          </a>
        </div>

        {/* Zone 2: 4-5 Concise Single-Line Nav Links */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-medium text-slate-300">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'schedule' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.schedule}
          </button>

          <button
            onClick={() => setActiveTab('members')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white flex items-center gap-1.5 ${
              activeTab === 'members' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            <span>{dict.nav.members}</span>
            {pendingCount > 0 && (
              <span className="bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded-full text-[10px] animate-pulse">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'attendance' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.attendance}
          </button>

          <button
            onClick={() => setActiveTab('support')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'support' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.support}
          </button>

          <button
            onClick={() => setActiveTab('admins')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'admins' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.admins}
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'analytics' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.analytics}
          </button>

          <button
            onClick={() => setActiveTab('telegram')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeTab === 'telegram' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            {dict.nav.telegram}
          </button>

          <button
            onClick={() => setActiveTab('mobile')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white flex items-center gap-1.5 ${
              activeTab === 'mobile' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-1' : ''
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'am' ? 'ሞባይል መተግበሪያ' : 'Mobile App'}</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action (Admin Role Switcher, Language Switcher & ZIP Download) */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Admin Role Profile Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-800/90 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs">
            <span className="text-sm">
              {currentAdmin.role === 'super_admin' ? '👑' : '🛡️'}
            </span>
            <select
              value={currentAdmin.id}
              onChange={(e) => {
                const found = admins.find((a) => a.id === e.target.value);
                if (found) setCurrentAdmin(found);
              }}
              className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
              title="የአስተዳዳሪ ፕሮፋይል ይቀይሩ / Switch Admin Role"
            >
              {admins.map((admin) => (
                <option key={admin.id} value={admin.id} className="bg-slate-900 text-white">
                  {admin.nameAm} ({admin.role === 'super_admin' ? 'ዋና አስተዳዳሪ' : 'አስተዳዳሪ'})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20 transition-all whitespace-nowrap shrink-0 font-bold cursor-pointer"
            title="ሙሉውን የፕሮጀክት ኮድ በዚፕ ያውርዱ ወይም ፋይሎችን ይመልከቱ / Download Full Project ZIP"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>{lang === 'am' ? 'ሙሉ ኮድ (.ZIP)' : 'Download (.ZIP)'}</span>
          </button>

          <button
            onClick={() => setLang(lang === 'am' ? 'en' : 'am')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors whitespace-nowrap shrink-0"
            title="ቋንቋ ይቀይሩ / Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'am' ? 'English' : 'አማርኛ'}</span>
          </button>
        </div>
      </header>

      {/* Mobile Nav Bar for smaller viewports */}
      <div className="no-print lg:hidden border-b border-slate-800 bg-slate-900/50 px-4 py-2 flex items-center justify-between gap-1 overflow-x-auto">
        {[
          { id: 'schedule', label: lang === 'am' ? 'መርሐ ግብር' : 'Schedule', icon: Calendar },
          { id: 'members', label: lang === 'am' ? 'አባላት' : 'Members', icon: Users },
          { id: 'attendance', label: lang === 'am' ? 'QR ክትትል' : 'Attendance', icon: QrCode },
          { id: 'support', label: lang === 'am' ? 'ድጋፍ' : 'Support', icon: HeartHandshake },
          { id: 'admins', label: lang === 'am' ? 'አድሚኖች' : 'Admins', icon: ShieldCheck },
          { id: 'analytics', label: lang === 'am' ? 'ሪፖርት' : 'Analytics', icon: BarChart3 },
          { id: 'telegram', label: 'Telegram', icon: Smartphone },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'schedule' && (
          <ScheduleView
            onSelectSessionForAttendance={handleSelectSessionFromSchedule}
            lang={lang}
          />
        )}

        {activeTab === 'members' && (
          <MemberList
            members={members}
            onAddMember={handleAddMember}
            onApproveMember={handleApproveMember}
            onRejectMember={handleRejectMember}
            onOpenCardStudio={handleOpenCardStudio}
            currentAdminRole={currentAdmin.role}
            lang={lang}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceScanner
            members={members}
            attendance={attendance}
            sessions={sessions}
            activeSession={activeSession}
            onSelectSession={setActiveSession}
            onCheckIn={handleCheckIn}
            lang={lang}
          />
        )}

        {activeTab === 'support' && (
          <SupportDesk
            tickets={tickets}
            members={members}
            onAddTicket={handleAddTicket}
            onUpdateTicketStatus={handleUpdateTicketStatus}
            onAddNote={handleAddNote}
            lang={lang}
          />
        )}

        {activeTab === 'admins' && (
          <AdminManagement
            currentAdmin={currentAdmin}
            lang={lang}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            members={members}
            attendance={attendance}
            tickets={tickets}
            lang={lang}
          />
        )}

        {activeTab === 'telegram' && (
          <TelegramSimulator
            members={members}
            attendance={attendance}
            lang={lang}
          />
        )}

        {activeTab === 'mobile' && (
          <MobileAppSimulator
            members={members}
            onCheckIn={handleCheckIn}
            lang={lang}
          />
        )}
      </main>

      {/* Printable ID Card Studio Modal */}
      {isCardStudioOpen && (
        <IdCardStudio
          members={members}
          selectedMember={studioTargetMember}
          onClose={() => setIsCardStudioOpen(false)}
          lang={lang}
        />
      )}

      {/* Zip and Project Downloader Modal */}
      <ZipDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Quiet Footer */}
      <footer className="no-print border-t border-slate-900 py-6 px-6 text-center text-xs text-slate-500">
        <p>
          ፍትሐፖል ማህበር (FithaPol) · {new Date().getFullYear()} · የአባላት አስተዳደር፣ ክትትልና የአገልግሎት ሥርዓት
        </p>
      </footer>
    </div>
  );
}
