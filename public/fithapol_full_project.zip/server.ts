import express from 'express';
import cors from 'cors';
import * as dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { db } from './backend/src/services/firebase.ts';
import { bot } from './backend/src/services/bot.ts';

dotenv.config();

async function startServer() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  app.get('/api/registrations/:id', async (req, res) => {
    try {
      const doc = await db.collection('registrations').doc(req.params.id).get();
      if (!doc.exists) {
        return res.status(404).json({ error: 'Registration not found' });
      }
      res.json({ id: doc.id, ...doc.data() });
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  app.post('/api/registrations/:id/approve', async (req, res) => {
    try {
      const { id } = req.params;
      const { studentCode, approvedBy } = req.body;

      const regRef = db.collection('registrations').doc(id);
      const regDoc = await regRef.get();
      if (!regDoc.exists) return res.status(404).json({ error: 'Registration not found' });

      const regData = regDoc.data()!;
      
      await regRef.update({
        status: 'approved',
        studentCode,
        approvedBy,
        updatedAt: new Date().toISOString()
      });

      await db.collection('students').add({
        code: studentCode,
        fullNameAm: regData.fullNameAm,
        fullNameEn: regData.fullNameEn,
        phone: regData.phone,
        gender: regData.gender,
        department: regData.department || 'education',
        gradeLevel: regData.gradeLevel || 'general',
        telegramId: regData.telegramId,
        status: 'active',
        registeredDate: new Date().toISOString().split('T')[0]
      });

      // Dispatch Telegram notification to student if bot is active
      if (bot && regData.telegramId) {
        try {
          await bot.sendMessage(
            regData.telegramId,
            `🎉 *እንኳን ደስ አለዎት! ምዝገባዎ ጸድቋል*\n*Congratulations! Registration Approved*\n\nYour registration for Wold Wahid Sunday School has been approved.\n\n*Assigned Student ID:* \`${studentCode}\`\n\nYou can now send /start or tap '👤 My QR / Profile' in the bot to view your official student badge.`,
            { parse_mode: 'Markdown' }
          );
        } catch (tgErr) {
          console.error('Failed to send Telegram notification:', tgErr);
        }
      }

      res.json({ success: true, message: 'Registration approved and student profile created.' });
    } catch (error) {
      res.status(500).json({ error: 'Approval failed' });
    }
  });

  // Initialize Vite middleware for frontend development with HMR disabled to prevent port 24678 conflicts
  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      hmr: false,
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);

  const PORT = 3000;
  
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
