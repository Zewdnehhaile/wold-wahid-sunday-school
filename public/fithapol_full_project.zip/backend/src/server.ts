import express from 'express';
import cors from 'cors';
import * as dotenv from 'dotenv';
import { db } from './services/firebase';
import { bot } from './services/bot';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Registration endpoint: Get registration status
app.get('/api/registrations/:id', async (req, res) => {
  try {
    const doc = await db.collection('registrations').doc(req.params.id).get();
    if (!doc.exists) {
      return res.status(404).json({ error: 'Registration not found' });
    }
    res.json({ id: doc.id, ...doc.data() });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Admin approval trigger with Telegram notification
app.post('/api/registrations/:id/approve', async (req, res) => {
  try {
    const { id } = req.params;
    const { studentCode, approvedBy } = req.body;

    const regRef = db.collection('registrations').doc(id);
    const regDoc = await regRef.get();
    if (!regDoc.exists) return res.status(404).json({ error: 'Registration not found' });

    const regData = regDoc.data()!;
    
    // Update registration
    await regRef.update({
      status: 'approved',
      studentCode,
      approvedBy,
      updatedAt: new Date().toISOString()
    });

    // Create student profile
    await db.collection('students').add({
      code: studentCode,
      fullNameAm: regData.fullNameAm,
      fullNameEn: regData.fullNameEn,
      phone: regData.phone,
      gender: regData.gender,
      department: regData.department || 'education',
      gradeLevel: regData.gradeLevel || 'general',
      telegramId: regData.telegramId,
      status: 'active',
      registeredDate: new Date().toISOString().split('T')[0]
    });

    // Send real Telegram notification if bot is active and telegramId exists
    if (bot && regData.telegramId) {
      try {
        await bot.sendMessage(
          regData.telegramId,
          `🎉 *გილოცავთ! Registration Approved*\n\nYour registration for Wold Wahid Sunday School has been approved.\n\n*Assigned Student ID:* \`${studentCode}\`\n\nYou can now use /start or click 'My QR / Profile' to access your profile.`,
          { parse_mode: 'Markdown' }
        );
      } catch (tgErr) {
        console.error('Failed to send Telegram notification:', tgErr);
      }
    }

    res.json({ success: true, message: 'Registration approved and student profile created.' });
  } catch (error) {
    res.status(500).json({ error: 'Approval failed' });
  }
});

// Telegram Webhook endpoint (alternative to polling)
app.post('/api/telegram/webhook', (req, res) => {
  if (bot) {
    bot.processUpdate(req.body);
  }
  res.sendStatus(200);
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});
