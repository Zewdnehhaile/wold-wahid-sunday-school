import * as TelegramBotModule from 'node-telegram-bot-api';
import { db } from './firebase.ts';
import * as dotenv from 'dotenv';

dotenv.config();

const token = process.env.TELEGRAM_BOT_TOKEN || '';
const BotClass = (TelegramBotModule as any).Bot || (TelegramBotModule as any).default?.Bot || TelegramBotModule;

let botInstance: any = null;

// In-memory conversation state for multi-step wizards
interface UserSession {
  action: 'register' | 'support' | 'leave';
  step: string;
  data: Record<string, any>;
}
const userSessions = new Map<number, UserSession>();

const mainMenuKeyboard = {
  reply_markup: {
    keyboard: [
      [{ text: '📝 Register as Student' }, { text: '🔍 My Registration' }],
      [{ text: '👤 My QR / Profile' }, { text: '📊 My Attendance' }],
      [{ text: '📅 Class Schedule' }, { text: '✉️ Leave Request' }],
      [{ text: '💬 Support & Help' }]
    ],
    resize_keyboard: true,
  }
};

const cancelKeyboard = {
  reply_markup: {
    keyboard: [
      [{ text: '❌ Cancel (ይቅር)' }]
    ],
    resize_keyboard: true,
  }
};

if (!token || token.startsWith('PASTE_')) {
  console.log('ℹ️ TELEGRAM_BOT_TOKEN is not set or still default. Telegram bot polling is idle.');
} else {
  try {
    botInstance = new BotClass(token);
    botInstance.sendMessage = async (chatId: number | string, text: string, options?: any) => {
      try {
        const payload: Record<string, any> = {
          chat_id: chatId,
          text: text,
          parse_mode: options?.parse_mode || 'Markdown',
          ...options,
        };
        const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!data.ok) {
          console.warn('Telegram API response not ok:', data);
        }
        return data;
      } catch (sendErr) {
        console.error('Failed to dispatch Telegram message:', sendErr);
        throw sendErr;
      }
    };

    console.log('🤖 Telegram bot service initializing for @attendanceforchurchbot...');

    // /start command
    botInstance.command('start', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (telegramId) userSessions.delete(telegramId);

      await ctx.reply(
        'እንኳን ወደ ወልድ ዋሕድ ሰንበት ት/ቤት ቦት በደህና መጡ! ✝️\nWelcome to Wold Wahid Sunday School Bot.\n\nከዚህ በታች ካሉት አማራጮች አንዱን ይምረጡ / Please select an option from the menu below:',
        mainMenuKeyboard
      );
    });

    // ❌ Cancel command
    botInstance.hears(/❌ Cancel|ይቅር|/i, async (ctx: any, next: any) => {
      const text = ctx.message?.text || '';
      if (text.includes('Cancel') || text.includes('ይቅር')) {
        const telegramId = ctx.from?.id;
        if (telegramId) userSessions.delete(telegramId);
        await ctx.reply('ኦፕሬሽኑ ተሰርዟል / Operation cancelled.', mainMenuKeyboard);
        return;
      }
      return next();
    });

    // 1. 📝 REGISTER AS STUDENT WIZARD
    botInstance.hears('📝 Register as Student', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      // Check if already registered
      const regSnap = await db.collection('registrations').where('telegramId', '==', telegramId).get();
      if (!regSnap.empty) {
        const reg = regSnap.docs[0].data();
        if (reg.status === 'pending') {
          await ctx.reply(
            `⚠️ You already have a pending registration submitted on ${reg.submittedAt?.split('T')[0] || 'recently'}.\n\nUse '🔍 My Registration' to check your status.`,
            mainMenuKeyboard
          );
          return;
        } else if (reg.status === 'approved') {
          await ctx.reply(
            `🎉 You are already an approved student!\nYour Student ID is: \`${reg.studentCode}\`\n\nClick '👤 My QR / Profile' to access your profile.`,
            mainMenuKeyboard
          );
          return;
        }
      }

      userSessions.set(telegramId, {
        action: 'register',
        step: 'name',
        data: {}
      });

      await ctx.reply(
        '📝 *የተማሪ ምዝገባ (Step 1/6)*\n*Student Registration*\n\nእባክዎ ሙሉ ስምዎን በአማርኛ ወይም በእንግሊዝኛ ያስገቡ:\nPlease enter your Full Name:\n\n(ምሳሌ፡ ዮሐንስ ተስፋዬ / Yohannes Tesfaye)',
        cancelKeyboard
      );
    });

    // 2. 🔍 MY REGISTRATION STATUS
    botInstance.hears('🔍 My Registration', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      try {
        const regSnap = await db.collection('registrations').where('telegramId', '==', telegramId).get();
        if (regSnap.empty) {
          await ctx.reply(
            'ምንም አይነት የተመዘገበ መረጃ አልተገኘም። እባክዎ "📝 Register as Student" የሚለውን በመጫን ይመዝገቡ።\nNo registration found. Click "📝 Register as Student" to submit your application.',
            mainMenuKeyboard
          );
          return;
        }

        const reg = regSnap.docs[0].data();
        let statusAm = reg.status === 'approved' ? '✅ ጸድቋል (Approved)' : reg.status === 'rejected' ? '❌ አልተቀበለም (Rejected)' : '⏳ በመጠባበቅ ላይ (Pending Review)';
        
        let msg = `📋 *የምዝገባ ሁኔታ / Registration Status*\n\n` +
          `• *ስም (Name):* ${reg.fullNameAm || reg.fullNameEn}\n` +
          `• *ስልክ (Phone):* ${reg.phone || 'N/A'}\n` +
          `• *ክፍል (Dept):* ${reg.department || 'N/A'}\n` +
          `• *ሁኔታ (Status):* ${statusAm}\n`;

        if (reg.status === 'approved') {
          msg += `• *የተማሪ መታወቂያ (Student ID):* \`${reg.studentCode}\`\n\nመታወቂያዎን ለማየት "👤 My QR / Profile" ን ይጫኑ።`;
        } else if (reg.status === 'rejected') {
          msg += `• *ምክንያት (Reason):* ${reg.rejectionReason || 'ተጨማሪ ማብራሪያ ያስፈልጋል'}\n`;
        } else {
          msg += `\nማመልከቻዎ በአስተዳዳሪው እየታየ ነው፤ እንደጸደቀ የተማሪ መታወቂያዎ ይላክሎታል።`;
        }

        await ctx.reply(msg, { parse_mode: 'Markdown', ...mainMenuKeyboard });
      } catch (err) {
        console.error('Error fetching registration status:', err);
        await ctx.reply('መረጃውን ማግኘት አልተቻለም። እባክዎ ቆይተው እንደገና ይሞክሩ።');
      }
    });

    // 3. 👤 MY QR / PROFILE
    botInstance.hears('👤 My QR / Profile', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      try {
        // Look up student record
        const studentSnap = await db.collection('students').where('telegramId', '==', telegramId).get();
        if (studentSnap.empty) {
          // Check if pending
          const regSnap = await db.collection('registrations').where('telegramId', '==', telegramId).get();
          if (!regSnap.empty && regSnap.docs[0].data().status === 'pending') {
            await ctx.reply(
              '⏳ ምዝገባዎ በአስተዳዳሪው ገና አልጸደቀም። እንደጸደቀ የተማሪ መታወቂያ እና QR ኮድ ይፈጠርልዎታል።\nYour registration is still pending review.',
              mainMenuKeyboard
            );
          } else {
            await ctx.reply(
              'የተመዘገበ ተማሪ አልተገኘም። እባክዎ በመጀመሪያ ይመዝገቡ።\nNo active student profile found. Please register first.',
              mainMenuKeyboard
            );
          }
          return;
        }

        const student = studentSnap.docs[0].data();
        const profileMsg = 
          `👤 *የተማሪ መገለጫ / Student Profile*\n` +
          `═══════════════════════\n` +
          `🆔 *Student ID:* \`${student.code}\`\n` +
          `👤 *ስም (Name):* ${student.fullNameAm || student.fullNameEn}\n` +
          `📞 *ስልክ (Phone):* ${student.phone || 'N/A'}\n` +
          `⛪ *ክፍል (Dept):* ${student.department || 'N/A'}\n` +
          `🎓 *ደረጃ (Grade):* ${student.gradeLevel || 'N/A'}\n` +
          `🟢 *ሁኔታ (Status):* ${student.status || 'Active'}\n` +
          `═══════════════════════\n\n` +
          `*የመገኘት መመዝገቢያ ኮድ:* \`${student.code}\`\n` +
          `ይህንን መታወቂያ ቁጥር ለሰንበት ት/ቤት መገኘት መመዝገቢያ ይጠቀሙ።`;

        await ctx.reply(profileMsg, { parse_mode: 'Markdown', ...mainMenuKeyboard });
      } catch (err) {
        console.error('Error fetching profile:', err);
        await ctx.reply('መገለጫዎን ማውጣት አልተቻለም።');
      }
    });

    // 4. 📊 MY ATTENDANCE
    botInstance.hears('📊 My Attendance', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      try {
        const attSnap = await db.collection('attendance')
          .where('telegramId', '==', telegramId)
          .orderBy('timestamp', 'desc')
          .limit(6)
          .get();

        if (attSnap.empty) {
          await ctx.reply('ምንም አይነት የመገኘት ታሪክ አልተገኘም።\nNo recent attendance records found.', mainMenuKeyboard);
          return;
        }

        let report = `📊 *የመገኘት ታሪክ (Recent Attendance)*\n═══════════════════════\n`;
        attSnap.docs.forEach((doc: any) => {
          const a = doc.data();
          report += `📅 *${a.date}* | ${a.sessionName || 'Class'}\n` +
                    `   ⏰ Time: ${a.timestamp} (${a.method || 'QR'})\n`;
        });
        report += `═══════════════════════\nጠቅላላ መገኘትዎ በሰንበት ትምህርት ቤት ስርዓት ተመዝግቧል።`;

        await ctx.reply(report, { parse_mode: 'Markdown', ...mainMenuKeyboard });
      } catch (err) {
        console.error('Error fetching attendance:', err);
        await ctx.reply('የመገኘት መረጃን ማውጣት አልተቻለም።');
      }
    });

    // 5. 📅 CLASS SCHEDULE
    botInstance.hears('📅 Class Schedule', async (ctx: any) => {
      try {
        const classSnap = await db.collection('classes').get();
        if (classSnap.empty) {
          const defaultSchedule = 
            `📅 *የሰንበት ትምህርት ቤት ፕሮግራም (Schedule)*\n` +
            `═══════════════════════\n` +
            `• *አርብ (Friday):*\n  11:30 - 01:00 (የአብነት እና የዜማ ትምህርት)\n\n` +
            `• *ቅዳሜ (Saturday):*\n  09:00 - 11:30 (የመዘምራን ልምምድ እና ስነ-ጽሑፍ)\n\n` +
            `• *እሁድ (Sunday):*\n  01:30 - 04:30 (ጠቅላላ የሰንበት ት/ቤት ትምህርት እና መርሐ-ግብር)\n` +
            `═══════════════════════`;
          await ctx.reply(defaultSchedule, { parse_mode: 'Markdown', ...mainMenuKeyboard });
          return;
        }

        let schedule = `📅 *የሰንበት ትምህርት ቤት ፕሮግራም (Schedule)*\n═══════════════════════\n`;
        classSnap.docs.forEach((doc: any) => {
          const c = doc.data();
          schedule += `• *${c.nameAm || c.name || 'ትምህርት'}*\n  ⏰ ${c.time || '08:00 - 11:00'} | 📍 ${c.room || 'ዋና አዳራሽ'}\n\n`;
        });
        await ctx.reply(schedule, { parse_mode: 'Markdown', ...mainMenuKeyboard });
      } catch (err) {
        console.error('Error fetching schedule:', err);
        await ctx.reply('ፕሮግራሙን ማውጣት አልተቻለም።');
      }
    });

    // 6. ✉️ LEAVE REQUEST WIZARD
    botInstance.hears('✉️ Leave Request', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      userSessions.set(telegramId, {
        action: 'leave',
        step: 'type',
        data: {}
      });

      const leaveTypesKeyboard = {
        reply_markup: {
          keyboard: [
            [{ text: '🏥 Medical (የጤና)' }, { text: '✈️ Travel (የጉዞ)' }],
            [{ text: '📚 Academic (የትምህርት ፈተና)' }, { text: '👨‍👩‍👧 Family (የቤተሰብ)' }],
            [{ text: '❓ Other (ሌላ)' }],
            [{ text: '❌ Cancel (ይቅር)' }]
          ],
          resize_keyboard: true,
        }
      };

      await ctx.reply(
        '✉️ *የፈቃድ መጠየቂያ (Leave Request)*\n\nእባክዎ የፈቃድ አይነት ይምረጡ / Please select the reason for leave:',
        leaveTypesKeyboard
      );
    });

    // 7. 💬 SUPPORT & HELP WIZARD
    botInstance.hears('💬 Support & Help', async (ctx: any) => {
      const telegramId = ctx.from?.id;
      if (!telegramId) return;

      userSessions.set(telegramId, {
        action: 'support',
        step: 'category',
        data: {}
      });

      const supportKeyboard = {
        reply_markup: {
          keyboard: [
            [{ text: '🙏 Prayer Request (የጸሎት ጥያቄ)' }, { text: '🏠 Visitation (የቤት ጥየቃ)' }],
            [{ text: '🤝 Welfare / Aid (የድጋፍ እርዳታ)' }, { text: '🗣 Counseling (ምክር)' }],
            [{ text: '❓ General Inquiry (አጠቃላይ ጥያቄ)' }],
            [{ text: '❌ Cancel (ይቅር)' }]
          ],
          resize_keyboard: true,
        }
      };

      await ctx.reply(
        '💬 *የድጋፍ እና እርዳታ መስጫ (Support Desk)*\n\nእባክዎ የሚፈልጉትን የድጋፍ ዘርፍ ይምረጡ / Please select the category:',
        supportKeyboard
      );
    });

    // GENERIC MESSAGE HANDLER FOR CONVERSATIONAL WIZARDS
    botInstance.on('message', async (ctx: any) => {
      const text = ctx.message?.text?.trim();
      const telegramId = ctx.from?.id;
      if (!text || !telegramId) return;

      // Ignore if user typed a menu button
      const menuKeywords = [
        '📝 Register as Student', '🔍 My Registration', '👤 My QR / Profile',
        '📊 My Attendance', '📅 Class Schedule', '✉️ Leave Request', '💬 Support & Help',
        '❌ Cancel (ይቅር)'
      ];
      if (menuKeywords.includes(text)) return;

      const session = userSessions.get(telegramId);
      if (!session) return;

      // ─── REGISTRATION WIZARD STEPS ───
      if (session.action === 'register') {
        if (session.step === 'name') {
          session.data.name = text;
          session.step = 'phone';
          await ctx.reply(
            '📱 *ስልክ ቁጥርዎን ያስገቡ (Step 2/6):*\nPlease enter your Phone Number:\n(ምሳሌ፡ 0911234567)',
            cancelKeyboard
          );
        } else if (session.step === 'phone') {
          session.data.phone = text;
          session.step = 'gender';
          const genderKeyboard = {
            reply_markup: {
              keyboard: [
                [{ text: 'ወንድ (Male)' }, { text: 'ሴት (Female)' }],
                [{ text: '❌ Cancel (ይቅር)' }]
              ],
              resize_keyboard: true,
            }
          };
          await ctx.reply(
            '👤 *ጾታ ይምረጡ (Step 3/6):*\nPlease select your Gender:',
            genderKeyboard
          );
        } else if (session.step === 'gender') {
          session.data.gender = text.includes('ወንድ') || text.toLowerCase().includes('male') ? 'male' : 'female';
          session.step = 'department';
          const deptKeyboard = {
            reply_markup: {
              keyboard: [
                [{ text: 'ትምህርት (Education)' }, { text: 'መዘምራን (Choir)' }],
                [{ text: 'ኪነ-ጥበብ (Arts)' }, { text: 'አብነት (Abnet)' }],
                [{ text: 'ስነ-ስርዓት (Discipline)' }, { text: 'አጠቃላይ (General)' }],
                [{ text: '❌ Cancel (ይቅር)' }]
              ],
              resize_keyboard: true,
            }
          };
          await ctx.reply(
            '⛪ *የሰንበት ት/ቤት ክፍል ይምረጡ (Step 4/6):*\nSelect your Department:',
            deptKeyboard
          );
        } else if (session.step === 'department') {
          session.data.department = text;
          session.step = 'gradeLevel';
          const gradeKeyboard = {
            reply_markup: {
              keyboard: [
                [{ text: 'ህፃናት (Pre-KG)' }, { text: '1-2ኛ ክፍል (Grade 1-2)' }],
                [{ text: '3-5ኛ ክፍል (Grade 3-5)' }, { text: '6-9ኛ ክፍል (Grade 6-9)' }],
                [{ text: 'ወጣቶች / አመራር (Youth / Leaders)' }],
                [{ text: '❌ Cancel (ይቅር)' }]
              ],
              resize_keyboard: true,
            }
          };
          await ctx.reply(
            '🎓 *የትምህርት ደረጃ ይምረጡ (Step 5/6):*\nSelect your Grade Level:',
            gradeKeyboard
          );
        } else if (session.step === 'gradeLevel') {
          session.data.gradeLevel = text;
          session.step = 'subcity';
          await ctx.reply(
            '📍 *ክፍለ ከተማ / የመኖሪያ አካባቢ ያስገቡ (Step 6/6):*\nPlease enter your Subcity or Residence Area:\n(ምሳሌ፡ ቦሌ / የካ / ቂርቆስ)',
            cancelKeyboard
          );
        } else if (session.step === 'subcity') {
          session.data.subcity = text;

          // Save to Firestore 'registrations' collection
          try {
            await db.collection('registrations').add({
              fullNameAm: session.data.name,
              fullNameEn: session.data.name,
              phone: session.data.phone,
              gender: session.data.gender,
              department: session.data.department,
              gradeLevel: session.data.gradeLevel,
              subcity: session.data.subcity,
              status: 'pending',
              telegramId: telegramId,
              telegramUsername: ctx.from?.username || '',
              submittedAt: new Date().toISOString()
            });

            userSessions.delete(telegramId);

            const successMsg = 
              `🎉 *የምዝገባ ጥያቄዎ በተሳካ ሁኔታ ተልኳል!*\n` +
              `*Registration Submitted Successfully!*\n\n` +
              `📋 *የመረጃ ማጠቃለያ (Summary):*\n` +
              `• *ስም (Name):* ${session.data.name}\n` +
              `• *ስልክ (Phone):* ${session.data.phone}\n` +
              `• *ክፍል (Dept):* ${session.data.department}\n` +
              `• *ደረጃ (Grade):* ${session.data.gradeLevel}\n` +
              `• *ሁኔታ (Status):* ⏳ በመጠባበቅ ላይ (Pending Review)\n\n` +
              `አስተዳዳሪው ማመልከቻዎን አይቶ ሲያፀድቅ የተማሪ መታወቂያ ቁጥር በቦቱ በኩል ይደርስዎታል።`;

            await ctx.reply(successMsg, { parse_mode: 'Markdown', ...mainMenuKeyboard });
          } catch (saveErr) {
            console.error('Failed to save registration:', saveErr);
            await ctx.reply('ምዝገባውን ማስቀመጥ አልተቻለም። እባክዎ እንደገና ይሞክሩ።', mainMenuKeyboard);
          }
        }
        return;
      }

      // ─── SUPPORT TICKET WIZARD STEPS ───
      if (session.action === 'support') {
        if (session.step === 'category') {
          session.data.category = text;
          session.step = 'description';
          await ctx.reply(
            '📝 *የጥያቄዎን ወይም የድጋፍ ፍላጎትዎን ዝርዝር ይጻፉ:*\nPlease describe your request or message in detail:',
            cancelKeyboard
          );
        } else if (session.step === 'description') {
          session.data.description = text;
          const ticketNumber = 'WW-SPT-' + Math.floor(1000 + Math.random() * 9000);

          try {
            await db.collection('support_tickets').add({
              ticketNumber,
              category: session.data.category,
              description: session.data.description,
              requesterName: ctx.from?.first_name || 'Sunday School Member',
              telegramId: telegramId,
              telegramUsername: ctx.from?.username || '',
              status: 'new',
              priority: 'medium',
              createdAt: new Date().toISOString()
            });

            userSessions.delete(telegramId);

            await ctx.reply(
              `✅ *የድጋፍ ጥያቄዎ ተመዝግቧል!*\n` +
              `*Support Ticket Created!*\n\n` +
              `🎫 *Ticket #:* \`${ticketNumber}\`\n` +
              `📂 *Category:* ${session.data.category}\n\n` +
              `የሰንበት ት/ቤት አመራሮች ጥያቄዎን ተመልክተው በአጭር ጊዜ ውስጥ ያነጋግሩዎታል።`,
              { parse_mode: 'Markdown', ...mainMenuKeyboard }
            );
          } catch (err) {
            console.error('Failed to create ticket:', err);
            await ctx.reply('ጥያቄውን ማስተናገድ አልተቻለም። እባክዎ ቆይተው ይሞክሩ።', mainMenuKeyboard);
          }
        }
        return;
      }

      // ─── LEAVE REQUEST WIZARD STEPS ───
      if (session.action === 'leave') {
        if (session.step === 'type') {
          session.data.leaveType = text;
          session.step = 'duration';
          await ctx.reply(
            '📅 *የፈቃድ ጊዜውን ያስገቡ:*\nPlease enter the duration or dates of leave:\n(ምሳሌ፡ ለ 2 ሳምንት / ከጥቅምት 10 እስከ 24)',
            cancelKeyboard
          );
        } else if (session.step === 'duration') {
          session.data.duration = text;
          session.step = 'reason';
          await ctx.reply(
            '📝 *የፈቃዱን ዝርዝር ምክንያት ይግለጹ:*\nPlease provide the detailed reason for your leave:',
            cancelKeyboard
          );
        } else if (session.step === 'reason') {
          session.data.reason = text;
          const requestNumber = 'WW-LV-' + Math.floor(100 + Math.random() * 900);

          try {
            await db.collection('leave_requests').add({
              requestNumber,
              studentName: ctx.from?.first_name || 'Student',
              telegramId: telegramId,
              telegramUsername: ctx.from?.username || '',
              leaveType: session.data.leaveType,
              duration: session.data.duration,
              reason: session.data.reason,
              status: 'pending',
              createdAt: new Date().toISOString()
            });

            userSessions.delete(telegramId);

            await ctx.reply(
              `✅ *የፈቃድ ጥያቄዎ ተመዝግቧል!*\n` +
              `*Leave Request Submitted!*\n\n` +
              `📋 *Request #:* \`${requestNumber}\`\n` +
              `⏳ *Status:* በመጠባበቅ ላይ (Pending Review)\n\n` +
              `የክፍል ኃላፊዎ ጥያቄዎን መርምረው ውሳኔውን ያሳውቁዎታል።`,
              { parse_mode: 'Markdown', ...mainMenuKeyboard }
            );
          } catch (err) {
            console.error('Failed to submit leave request:', err);
            await ctx.reply('የፈቃድ ጥያቄውን ማስገባት አልተቻለም።', mainMenuKeyboard);
          }
        }
        return;
      }
    });

    // Start background polling safely
    botInstance.startPolling().catch((err: any) => {
      console.error('Telegram bot polling error:', err?.message || err);
    });

    console.log('✅ Real interactive Telegram bot polling started successfully.');
  } catch (err) {
    console.error('Failed to initialize Telegram bot:', err);
  }
}

export const bot = botInstance;
